#!/bin/bash
set -euo pipefail
script_root="$(cd "$(dirname "$0")" && pwd)"
exec /bin/bash "$script_root/macos/build-macos.sh" arm64
