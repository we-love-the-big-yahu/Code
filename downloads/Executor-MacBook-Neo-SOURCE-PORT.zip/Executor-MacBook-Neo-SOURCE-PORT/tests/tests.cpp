#include "util.hpp"
#include "session.hpp"
#include "compiler.hpp"
#include "bridge.hpp"
#include <iostream>
#include <fstream>
#include <set>
#include <nlohmann/json.hpp>
using namespace fe;
int main(int argc, char **argv) {
    auto root = fs::temp_directory_path() / (L"FunnyExecutorNativeTests-" + wide(randomHex(8)));
    int passed = 0;
    auto check = [&](bool condition, const char *label) {
        if (!condition)
            throw Error(std::string("FAIL: ") + label);
        ++passed;
        std::cout << "PASS " << label << '\n';
    };
    try {
        fs::create_directories(root);
        std::string unicode = "Lua 😀 Māori 中文";
        check(utf8(wide(unicode)) == unicode, "UTF-8/UTF-16 roundtrip");
        ScriptReader serviceReader{
            [](uint64_t id) { return id == 2 ? std::string("Players") : std::string("renamed-service"); },
            [](uint64_t id) {
                if (id == 6)
                    throw Error("Instance removed during transfer");
                return id == 3   ? std::string("Players")
                       : id == 4 ? std::string("CoreGui")
                                 : std::string("Folder");
            },
            [](uint64_t id) -> std::vector<uint64_t> {
                return id == 1 ? std::vector<uint64_t>{0, 2, 6, 3, 4} : std::vector<uint64_t>{};
            }};
        check(findChildByClass(1, "Players", serviceReader) == 3,
              "renamed Players service resolved by class, ignoring same-name "
              "folder and removed child");
        check(findChildByClass(1, "CoreGui", serviceReader) == 4,
              "renamed CoreGui service resolved by class");
        check(findChildByClass(1, "Lighting", serviceReader) == 0 &&
                  findChildByClass(0, "Players", serviceReader) == 0,
              "missing or unloaded services are reported without a false match");
        ScriptReader scriptReader{[](uint64_t id) {
                                      return id == 1   ? std::string("Ugc")
                                             : id == 2 ? std::string("Folder")
                                                       : std::string("Same/Name");
                                  },
                                  [](uint64_t id) {
                                      return id == 3   ? std::string("LocalScript")
                                             : id == 4 ? std::string("ModuleScript")
                                             : id == 5 ? std::string("Script")
                                                       : std::string("Folder");
                                  },
                                  [](uint64_t id) -> std::vector<uint64_t> {
                                      if (id == 1)
                                          return {2, 5};
                                      if (id == 2)
                                          return {3, 4, 1};
                                      return {};
                                  }};
        auto scan = scanClientScripts(1, 123, scriptReader);
        check(scan.visited == 5 && scan.scripts.size() == 2 && !scan.limited,
              "client scan excludes unsupported scripts and tolerates cycles");
        check(scan.scripts[0].dataModel == 1 && scan.scripts[0].pid == 123 &&
                  scan.scripts[0].path == std::vector<std::string>{"Folder", "Same/Name"},
              "client scan preserves paths and game identity");
        check(scanClientScripts(1, 123, scriptReader, {}, 2).limited,
              "client scan bounds instance traversal");
        ScriptReader priorityReader{
            [](uint64_t id) {
                return id == 2   ? std::string("Workspace")
                       : id == 3 ? std::string("ReplicatedStorage")
                                 : std::string("Module");
            },
            [](uint64_t id) { return id == 4 ? std::string("ModuleScript") : std::string("Folder"); },
            [](uint64_t id) -> std::vector<uint64_t> {
                if (id == 1)
                    return {2, 3};
                if (id == 3)
                    return {4};
                return {};
            }};
        auto priorityScan = scanClientScripts(1, 123, priorityReader, {}, 3);
        check(priorityScan.scripts.size() == 1 && priorityScan.scripts[0].path[0] == "ReplicatedStorage",
              "scan prioritizes game code before large scenes");
        auto coreReader = priorityReader;
        coreReader.name = [](uint64_t id) {
            return id == 3 ? std::string("CorePackages") : std::string("Workspace");
        };
        check(scanClientScripts(1, 123, coreReader).scripts.empty(),
              "game scan excludes Roblox framework and executor runtime containers");
        bool scanCancelled = false;
        try {
            scanClientScripts(1, 123, scriptReader, [] { return true; });
        } catch (const Error &) {
            scanCancelled = true;
        }
        check(scanCancelled, "client scan honours cancellation");
        auto brokenReader = scriptReader;
        brokenReader.className = [](uint64_t id) {
            if (id == 4)
                throw Error("Removed instance");
            return std::string("ModuleScript");
        };
        check(scanClientScripts(1, 123, brokenReader).skipped == 1, "client scan skips removed instances");
        check(scriptExportName(scan.scripts[0], 0) != scriptExportName(scan.scripts[1], 1),
              "export names distinguish duplicate script names");
        auto unsafe = scan.scripts[0];
        unsafe.name = "../CON.exe::$DATA\\name\n";
        check(workspacePath(root, utf8(scriptExportName(unsafe, 0).wstring())).parent_path() == root,
              "export names cannot escape their destination or create streams");
        check(decompilerSource("return 42") == "return 42" &&
                  decompilerSource("{\"source\":\"return 42\"}") == "return 42",
              "decompiler accepts source and structured source responses");
        check(decompilerSource("failureCount = 1") == "failureCount = 1",
              "source identifiers are not mistaken for service failures");
        for (auto response : {"", "<!doctype html><html>error</html>", "fail\nservice down",
                              "{\"error\":\"bad bytecode\"}", "{\"unknown\":42}"}) {
            bool rejected = false;
            try {
                decompilerSource(response);
            } catch (const Error &) {
                rejected = true;
            }
            check(rejected, "decompiler rejects service errors instead of opening them as code");
        }
        int requests = 0;
        Decompiler decompiler(root / L"decompile-cache", [&](std::string_view bytes) {
            ++requests;
            return std::string("return ") + std::string(bytes);
        });
        check(decompiler.decompile("42") == "return 42" && decompiler.decompile("42") == "return 42" &&
                  requests == 1,
              "decompiler caches bytecode results without repeated uploads");
        bool cancelled = false;
        try {
            decompiler.decompile("99", [] { return true; });
        } catch (const Error &) {
            cancelled = true;
        }
        check(cancelled && requests == 1, "cancelled jobs do not upload bytecode");
        auto scripts = scan.scripts;
        auto currentSession = [](const ClientScript &) { return true; };
        auto exported = exportClientScripts(
            scripts, root / L"export", decompiler,
            [](const ClientScript &script) { return script.className == "LocalScript" ? "42" : "43"; },
            currentSession, [] { return false; });
        auto manifest = nlohmann::json::parse(readFile(root / L"export/manifest.json"));
        check(exported.saved == 2 && exported.failed == 0 && manifest["complete"] == true &&
                  manifest["scripts"].size() == 2,
              "bulk decompilation saves scripts and a complete manifest");
        check(readFile(root / L"export" / scriptExportName(scripts[0], 0))
                      .find("-- Path: [\"Folder\",\"Same/Name\"]") != std::string::npos,
              "exported source preserves its original instance path");
        auto partial = exportClientScripts(
            scripts, root / L"partial", decompiler,
            [](const ClientScript &script) -> std::string {
                if (script.className == "ModuleScript")
                    throw Error("No bytecode");
                return "42";
            },
            currentSession, [] { return false; });
        check(partial.saved == 1 && partial.failed == 1 &&
                  nlohmann::json::parse(readFile(root / L"partial/manifest.json"))["scripts"][1].contains(
                      "error"),
              "bulk export records unavailable bytecode while retaining successes");
        bool cancelInTransport = false;
        Decompiler cancelService(root / L"cancel-cache", [&](std::string_view) {
            cancelInTransport = true;
            return std::string("return 1");
        });
        auto cancelExport = exportClientScripts(
            scripts, root / L"cancelled", cancelService, [](const ClientScript &) { return "cancel"; },
            currentSession, [&] { return cancelInTransport; });
        check(cancelExport.saved == 0 && cancelExport.stopReason == "Cancelled",
              "cancellation during a request preserves a partial manifest");
        bool sessionChanged = false;
        Decompiler changeService(root / L"change-cache", [&](std::string_view) {
            sessionChanged = true;
            return std::string("return 1");
        });
        auto staleExport = exportClientScripts(
            scripts, root / L"stale", changeService, [](const ClientScript &) { return "stale"; },
            [&](const ClientScript &) { return !sessionChanged; }, [] { return false; });
        check(staleExport.saved == 0 && staleExport.stopReason == "Game session changed",
              "game changes during decompilation do not produce stale exports");
        auto many = scripts;
        many.insert(many.end(), scripts.begin(), scripts.end());
        int failures = 0;
        Decompiler unavailable(root / L"fail-cache", [&](std::string_view) -> std::string {
            ++failures;
            throw Error("HTTP status 503");
        });
        auto failedExport = exportClientScripts(
            many, root / L"unavailable", unavailable, [](const ClientScript &) { return "bad"; },
            currentSession, [] { return false; });
        check(failures == 3 && failedExport.failed == 3 && !failedExport.stopReason.empty(),
              "bulk export stops after repeated service failures");
        std::string bytes("\0\1\2\xffHello", 9);
        check(base64Decode(base64Encode(bytes)) == bytes, "binary base64 roundtrip");
        check(digest("abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
              "SHA-256 known vector");
        check(base64Decode(digest("The quick brown fox jumps over the lazy dog", "sha256", "key", true))
                      .size() == 32,
              "HMAC produces full digest");
        auto workspace = root / L"workspace";
        fs::create_directories(workspace);
        check(workspacePath(workspace, "folder/script.lua") == workspace / L"folder/script.lua",
              "workspace relative paths");
        for (const auto &path :
             {"../outside", "C:/outside", "/outside", "test.exe::$DATA", "folder/test.txt:stream", "NUL",
              "con.txt", "CON.foo.bar", "folder/file. ", "a/../b"}) {
            bool denied = false;
            try {
                workspacePath(workspace, path);
            } catch (...) {
                denied = true;
            }
            check(denied, ("reject path " + std::string(path)).c_str());
        }
        check(blockedExtension(fs::path(L"script.EXE")) && !blockedExtension(fs::path(L"script.luau")),
              "case-insensitive extension filtering");
        auto sessionPath = root / L"tabs.json";
        auto missing = loadSession(sessionPath);
        check(missing.session.tabs.size() == 1 && missing.recovery.empty(), "fresh session");
        Session session;
        session.nextTab = 9;
        session.active = 1;
        session.tabs = {{"Unicode", unicode}, {"Second", "return 42"}};
        saveSession(sessionPath, session);
        auto valid = loadSession(sessionPath);
        check(valid.session.tabs.size() == 2 && valid.session.tabs[0].content == unicode &&
                  valid.session.active == 1,
              "atomic session roundtrip");
        atomicWrite(sessionPath, "[4,[\"Legacy\",\"print(1)\"]]");
        auto legacy = loadSession(sessionPath);
        check(legacy.session.tabs[0].name == "Legacy" && legacy.session.nextTab == 4,
              "Python legacy session migration");
        for (const auto &invalid :
             std::vector<std::string>{"", std::string(59161, 0), "[1,", "{}", "[]", "[1,[\"name\",42]]"}) {
            atomicWrite(sessionPath, invalid);
            auto recovered = loadSession(sessionPath);
            check(!recovered.recovery.empty() && recovered.saveAllowed && recovered.session.tabs.size() == 1,
                  "corrupt session opens fresh tab");
            check(readFile(sessionPath) == invalid, "corrupt session original preserved");
        }
        auto before = readFile(sessionPath);
        Handle locked(CreateFileW(sessionPath.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING,
                                  FILE_ATTRIBUTE_NORMAL, nullptr));
        check(static_cast<bool>(locked), "lock save target");
        bool saveFailed = false;
        try {
            saveSession(sessionPath, session);
        } catch (...) {
            saveFailed = true;
        }
        check(saveFailed, "locked destination fails safely");
        locked.reset();
        check(readFile(sessionPath) == before, "failed replace preserves previous file");
        size_t temporary = 0;
        for (const auto &entry : fs::directory_iterator(root))
            if (entry.path().filename().wstring().find(L".tmp-") != std::wstring::npos)
                ++temporary;
        check(temporary == 0, "failed save cleans temporary file");
        auto oversized = session;
        oversized.tabs[0].content = std::string(16 * 1024 * 1024, 'x');
        bool sizeRejected = false;
        try {
            saveSession(sessionPath, oversized);
        } catch (...) {
            sizeRejected = true;
        }
        check(sizeRejected && readFile(sessionPath) == before,
              "oversized sessions rejected before replacing saved data");
        if (argc > 1) {
            auto assets = fs::path(wide(argv[1]));
            Compiler compiler(assets / L"luau/compile.exe");
            auto code = compiler.compile("local n = 3; return n + 4", "test");
            check(!code.empty() && code[0] != 0, "bundled compiler compiles valid source");
            if (argc > 2 && std::string_view(argv[2]) == "--decompile-service") {
                Decompiler live(root / L"live-service-cache");
                auto fixture =
                    compiler.compile("local answer = 42; print(answer); return answer", "DecompilerFixture");
                auto result = live.decompile(fixture);
                check(result.find("42") != std::string::npos && !compiler.compile(result).empty(),
                      "live decompiler returns compilable source for our own fixture");
            }
            bool rejected = false;
            try {
                compiler.compile("local =");
            } catch (const std::exception &e) {
                rejected = std::string(e.what()).find("compile error") != std::string::npos;
            }
            check(rejected, "compiler preserves syntax diagnostics");
            check(compiler.compile("return 1", "CON").size() > 0, "reserved chunk names sanitized");
            auto bytecode = Compiler::decrypt(readFile(assets / L"luau/init.bin"));
            check(!bytecode.empty(), "runtime bytecode decrypt/decompress");
            Roblox process(root);
            Bridge bridge(root, assets, compiler, process, 0);
            check(bridge.dispatch("writefile", {"sub/hello.txt", base64Encode(unicode)}) == "ok",
                  "native file RPC write");
            check(base64Decode(bridge.dispatch("readfile", {"sub/hello.txt"})) == unicode,
                  "native file RPC read");
            check(bridge.dispatch("writefile", {"bad.exe", base64Encode("blocked")}) == "blocked",
                  "native file RPC executable extension rejected");
            bool streamDenied = false;
            try {
                bridge.dispatch("writefile", {"bad.exe::$DATA", base64Encode("blocked")});
            } catch (...) {
                streamDenied = true;
            }
            check(streamDenied, "native file RPC stream bypass rejected");
            check(bridge.dispatch("delfolder", {""}) == "fail", "workspace root cannot be deleted");
            check(bridge.publish("first") && !bridge.publish("second"), "one queued bytecode job in flight");
            bridge.cancelExecution();
            check(!bridge.waitingForFetch(), "cancel clears pending execution");
            check(!bridge.dispatch("getinitraw", {}).empty(), "initializer and readiness marker compile");
            check(bridge.bootstrapRequests() == 1, "initializer handshake records bootstrap request");
            check(!compiler.compile(readFile(assets / L"luau/reconnect.luau"), "RuntimeReadiness").empty(),
                  "legacy runtime readiness probe compiles");
            bridge.start();
            SOCKET ownerListener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            sockaddr_in ownerAddress{};
            ownerAddress.sin_family = AF_INET;
            ownerAddress.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
            check(bind(ownerListener, reinterpret_cast<sockaddr *>(&ownerAddress), sizeof(ownerAddress)) ==
                          0 &&
                      listen(ownerListener, 1) == 0,
                  "ownership test loopback listener");
            int ownerLength = sizeof(ownerAddress);
            getsockname(ownerListener, reinterpret_cast<sockaddr *>(&ownerAddress), &ownerLength);
            SOCKET ownerClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            check(connect(ownerClient, reinterpret_cast<sockaddr *>(&ownerAddress), sizeof(ownerAddress)) ==
                      0,
                  "ownership test client connects");
            SOCKET ownerAccepted = accept(ownerListener, nullptr, nullptr);
            check(tcpClientOwnedBy(ownerAccepted, GetCurrentProcessId()),
                  "TCP ownership accepts the matching client PID");
            check(!tcpClientOwnedBy(ownerAccepted, GetCurrentProcessId() + 1),
                  "TCP ownership rejects a different PID");
            closesocket(ownerAccepted);
            closesocket(ownerClient);
            closesocket(ownerListener);
            SOCKET client = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
            sockaddr_in address{};
            address.sin_family = AF_INET;
            address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
            address.sin_port = htons(bridge.port());
            check(connect(client, reinterpret_cast<sockaddr *>(&address), sizeof(address)) == 0,
                  "native bridge listens on loopback");
            char reply[1024]{};
            int received = recv(client, reply, sizeof(reply), 0);
            check(received > 0 &&
                      std::string_view(reply, received).find("403 Forbidden") != std::string_view::npos,
                  "bridge rejects non-Roblox caller");
            closesocket(client);
            bridge.stop();
            check(true, "bridge stops and joins workers");
        }
        std::cout << passed << " checks passed\n";
        std::error_code ec;
        fs::remove_all(root, ec);
        return 0;
    } catch (const std::exception &e) {
        std::cerr << e.what() << '\n';
        std::error_code ec;
        fs::remove_all(root, ec);
        return 1;
    }
}
