#include "util.hpp"
#include <bcrypt.h>
#include <wincrypt.h>
#include <shlobj.h>
#include <algorithm>
#include <fstream>
#include <mutex>
#include <sstream>
#include <iomanip>
#include <set>
#include <iphlpapi.h>

namespace fe {
std::wstring wide(std::string_view text) {
    if (text.empty())
        return {};
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()),
                                nullptr, 0);
    if (!n)
        throw Error("Invalid UTF-8 text");
    std::wstring out(n, 0);
    MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), out.data(), n);
    return out;
}
std::string utf8(std::wstring_view text) {
    if (text.empty())
        return {};
    int n = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(), static_cast<int>(text.size()),
                                nullptr, 0, nullptr, nullptr);
    if (!n)
        throw Error("Invalid Unicode text");
    std::string out(n, 0);
    WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), out.data(), n, nullptr,
                        nullptr);
    return out;
}
std::string winError(std::string_view operation, DWORD code) {
    wchar_t *p = nullptr;
    FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
                       FORMAT_MESSAGE_IGNORE_INSERTS,
                   nullptr, code, 0, reinterpret_cast<LPWSTR>(&p), 0, nullptr);
    std::string result(operation);
    result += ": ";
    if (p) {
        result += utf8(p);
        LocalFree(p);
    } else
        result += std::to_string(code);
    return result;
}
fs::path executableDirectory() {
    std::wstring path(32768, 0);
    DWORD n = GetModuleFileNameW(nullptr, path.data(), static_cast<DWORD>(path.size()));
    if (!n || n == path.size())
        throw Error(winError("Find executable path"));
    path.resize(n);
    return fs::path(path).parent_path();
}
fs::path dataDirectory() {
    PWSTR p = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_RoamingAppData, 0, nullptr, &p)))
        throw Error("Cannot find AppData");
    fs::path path = fs::path(p) / L"FunnyExecutorCpp";
    CoTaskMemFree(p);
    return path;
}
std::string readFile(const fs::path &path, size_t limit) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f)
        throw Error("Cannot read " + utf8(path.wstring()));
    auto n = f.tellg();
    if (n < 0 || static_cast<uint64_t>(n) > limit)
        throw Error("File exceeds size limit");
    std::string bytes(static_cast<size_t>(n), 0);
    f.seekg(0);
    if (!bytes.empty() && !f.read(bytes.data(), n))
        throw Error("File read failed");
    return bytes;
}
void atomicWrite(const fs::path &path, std::string_view bytes) {
    fs::create_directories(path.parent_path());
    auto tmp = path;
    tmp += L".tmp-" + wide(randomHex(8));
    try {
        Handle f(
            CreateFileW(tmp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr));
        if (!f)
            throw Error(winError("Create temporary file"));
        size_t offset = 0;
        while (offset < bytes.size()) {
            DWORD written = 0,
                  amount = static_cast<DWORD>(std::min<size_t>(bytes.size() - offset, 1024 * 1024));
            if (!WriteFile(f.get(), bytes.data() + offset, amount, &written, nullptr) || !written)
                throw Error(winError("Write temporary file"));
            offset += written;
        }
        if (!FlushFileBuffers(f.get()))
            throw Error(winError("Flush saved file"));
        f.reset();
        if (!MoveFileExW(tmp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
            throw Error(winError("Replace saved file"));
    } catch (...) {
        std::error_code ec;
        fs::remove(tmp, ec);
        throw;
    }
}
std::string base64Encode(std::string_view bytes) {
    DWORD n = 0;
    if (!CryptBinaryToStringA(reinterpret_cast<const BYTE *>(bytes.data()), static_cast<DWORD>(bytes.size()),
                              CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, nullptr, &n))
        throw Error("Base64 encoding failed");
    std::string out(n, 0);
    CryptBinaryToStringA(reinterpret_cast<const BYTE *>(bytes.data()), static_cast<DWORD>(bytes.size()),
                         CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, out.data(), &n);
    if (!out.empty() && out.back() == 0)
        out.pop_back();
    return out;
}
std::string base64Decode(std::string_view text) {
    if (text.empty())
        return {};
    DWORD n = 0;
    if (!CryptStringToBinaryA(text.data(), static_cast<DWORD>(text.size()),
                              CRYPT_STRING_BASE64 | CRYPT_STRING_STRICT, nullptr, &n, nullptr, nullptr))
        throw Error("Invalid base64 content");
    std::string out(n, 0);
    if (!CryptStringToBinaryA(text.data(), static_cast<DWORD>(text.size()),
                              CRYPT_STRING_BASE64 | CRYPT_STRING_STRICT, reinterpret_cast<BYTE *>(out.data()),
                              &n, nullptr, nullptr))
        throw Error("Invalid base64 content");
    out.resize(n);
    return out;
}
std::string lower(std::string text) {
    for (auto &c : text)
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return text;
}
std::string digest(std::string_view bytes, std::string algorithm, std::string_view key, bool hmac) {
    algorithm = lower(algorithm);
    algorithm.erase(
        std::remove_if(algorithm.begin(), algorithm.end(), [](char c) { return c == '-' || c == '_'; }),
        algorithm.end());
    const wchar_t *name = nullptr;
    if (algorithm == "sha256")
        name = BCRYPT_SHA256_ALGORITHM;
    else if (algorithm == "sha384")
        name = BCRYPT_SHA384_ALGORITHM;
    else if (algorithm == "sha512")
        name = BCRYPT_SHA512_ALGORITHM;
    else if (algorithm == "sha1")
        name = BCRYPT_SHA1_ALGORITHM;
    else if (algorithm == "md5")
        name = BCRYPT_MD5_ALGORITHM;
    else
        throw Error("Unsupported hash algorithm");
    BCRYPT_ALG_HANDLE provider = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    if (BCryptOpenAlgorithmProvider(&provider, name, nullptr, hmac ? BCRYPT_ALG_HANDLE_HMAC_FLAG : 0) < 0)
        throw Error("Hash provider failed");
    try {
        DWORD objectSize = 0, hashSize = 0, result = 0;
        if (BCryptGetProperty(provider, BCRYPT_OBJECT_LENGTH, reinterpret_cast<BYTE *>(&objectSize),
                              sizeof(objectSize), &result, 0) < 0 ||
            BCryptGetProperty(provider, BCRYPT_HASH_LENGTH, reinterpret_cast<BYTE *>(&hashSize),
                              sizeof(hashSize), &result, 0) < 0)
            throw Error("Hash properties failed");
        std::vector<BYTE> object(objectSize);
        std::string output(hashSize, 0);
        if (BCryptCreateHash(provider, &hash, object.data(), objectSize,
                             hmac ? reinterpret_cast<BYTE *>(const_cast<char *>(key.data())) : nullptr,
                             hmac ? static_cast<ULONG>(key.size()) : 0, 0) < 0 ||
            BCryptHashData(hash, reinterpret_cast<BYTE *>(const_cast<char *>(bytes.data())),
                           static_cast<ULONG>(bytes.size()), 0) < 0 ||
            BCryptFinishHash(hash, reinterpret_cast<BYTE *>(output.data()), hashSize, 0) < 0)
            throw Error("Hash operation failed");
        BCryptDestroyHash(hash);
        hash = nullptr;
        BCryptCloseAlgorithmProvider(provider, 0);
        provider = nullptr;
        if (hmac)
            return base64Encode(output);
        static constexpr char hex[] = "0123456789abcdef";
        std::string encoded;
        encoded.reserve(output.size() * 2);
        for (unsigned char b : output) {
            encoded += hex[b >> 4];
            encoded += hex[b & 15];
        }
        return encoded;
    } catch (...) {
        if (hash)
            BCryptDestroyHash(hash);
        if (provider)
            BCryptCloseAlgorithmProvider(provider, 0);
        throw;
    }
}
std::string randomHex(size_t count) {
    std::vector<unsigned char> bytes(count);
    if (BCryptGenRandom(nullptr, bytes.data(), static_cast<ULONG>(count), BCRYPT_USE_SYSTEM_PREFERRED_RNG) <
        0)
        throw Error("Random generation failed");
    static constexpr char h[] = "0123456789abcdef";
    std::string out;
    for (auto b : bytes) {
        out += h[b >> 4];
        out += h[b & 15];
    }
    return out;
}
fs::path workspacePath(const fs::path &workspace, std::string_view relative) {
    auto text = wide(relative);
    if (text.find(L'\0') != text.npos)
        throw Error("Invalid path");
    fs::path rel(text);
    if (rel.is_absolute() || rel.has_root_name() || rel.has_root_directory())
        throw Error("Path must be relative to workspace");
    for (const auto &item : rel) {
        auto name = item.wstring();
        if (name == L".." || name.find_first_of(L":*?\"<>|") != name.npos)
            throw Error("Invalid workspace path");
        if (name.empty() || name == L".")
            continue;
        if (name.back() == L' ' || name.back() == L'.')
            throw Error("Trailing spaces/dots are not allowed");
        auto filename = lower(utf8(name));
        auto stem = filename.substr(0, filename.find('.'));
        if (stem == "con" || stem == "prn" || stem == "aux" || stem == "nul" ||
            (stem.size() == 4 && (stem.starts_with("com") || stem.starts_with("lpt")) && stem[3] >= '1' &&
             stem[3] <= '9'))
            throw Error("Windows device names are not allowed");
    }
    auto root = fs::weakly_canonical(workspace), target = fs::weakly_canonical(root / rel);
    auto r = root.begin(), t = target.begin();
    for (; r != root.end(); ++r, ++t)
        if (t == target.end() || lower(utf8(r->wstring())) != lower(utf8(t->wstring())))
            throw Error("Path escapes workspace");
    return target;
}
bool blockedExtension(const fs::path &path) {
    static const std::set<std::string> blocked = {
        ".exe", ".scr",    ".bat", ".com", ".csh", ".msi",  ".vb",   ".vbs", ".vbe",  ".ws",
        ".wsf", ".wsh",    ".ps1", ".py",  ".apk", ".pif",  ".cpl",  ".msc", ".jar",  ".cmd",
        ".hta", ".gadget", ".inf", ".ins", ".isp", ".psd1", ".psm1", ".reg", ".scf",  ".shb",
        ".sys", ".js",     ".jse", ".lnk", ".msp", ".zip",  ".rar",  ".7z",  ".tar",  ".gz",
        ".cab", ".iso",    ".img", ".dll", ".ocx", ".drv",  ".vxd",  ".xml", ".ini",  ".cpp",
        ".c",   ".url",    ".uri", ".deb", ".rpm", ".sh",   ".bash", ".zsh", ".fish", ".npm"};
    return blocked.contains(lower(utf8(path.extension().wstring())));
}
std::vector<std::string> split(std::string_view text, char separator) {
    std::vector<std::string> out;
    size_t start = 0;
    for (size_t i = 0; i <= text.size(); ++i)
        if (i == text.size() || text[i] == separator) {
            out.emplace_back(text.substr(start, i - start));
            start = i + 1;
        }
    return out;
}
std::string httpRequest(std::wstring url, std::string_view method, std::string_view body,
                        std::wstring headers, size_t limit) {
    URL_COMPONENTS parts{};
    parts.dwStructSize = sizeof(parts);
    parts.dwHostNameLength = parts.dwUrlPathLength = parts.dwExtraInfoLength = static_cast<DWORD>(-1);
    if (!WinHttpCrackUrl(url.c_str(), 0, 0, &parts) ||
        (parts.nScheme != INTERNET_SCHEME_HTTP && parts.nScheme != INTERNET_SCHEME_HTTPS))
        throw Error("Invalid HTTP URL");
    InternetHandle session(WinHttpOpen(L"FunnyExecutorNative/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                       WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0));
    if (!session)
        throw Error(winError("Open HTTP session"));
    WinHttpSetTimeouts(session.get(), 5000, 5000, 10000, 10000);
    std::wstring host(parts.lpszHostName, parts.dwHostNameLength),
        path(parts.lpszUrlPath, parts.dwUrlPathLength);
    if (parts.dwExtraInfoLength)
        path.append(parts.lpszExtraInfo, parts.dwExtraInfoLength);
    if (path.empty())
        path = L"/";
    InternetHandle connection(WinHttpConnect(session.get(), host.c_str(), parts.nPort, 0));
    if (!connection)
        throw Error(winError("HTTP connect"));
    auto verb = wide(method);
    InternetHandle request(WinHttpOpenRequest(
        connection.get(), verb.c_str(), path.c_str(), nullptr, WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES, parts.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0));
    if (!request)
        throw Error(winError("Open HTTP request"));
    DWORD disable = WINHTTP_DISABLE_COOKIES;
    WinHttpSetOption(request.get(), WINHTTP_OPTION_DISABLE_FEATURE, &disable, sizeof(disable));
    if (!WinHttpSendRequest(request.get(), headers.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : headers.c_str(),
                            static_cast<DWORD>(headers.size()),
                            body.empty() ? WINHTTP_NO_REQUEST_DATA : const_cast<char *>(body.data()),
                            static_cast<DWORD>(body.size()), static_cast<DWORD>(body.size()), 0) ||
        !WinHttpReceiveResponse(request.get(), nullptr))
        throw Error(winError("HTTP request failed"));
    DWORD status = 0, length = sizeof(status);
    WinHttpQueryHeaders(request.get(), WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                        WINHTTP_HEADER_NAME_BY_INDEX, &status, &length, WINHTTP_NO_HEADER_INDEX);
    if (status < 200 || status >= 300)
        throw Error("HTTP status " + std::to_string(status));
    std::string output;
    for (;;) {
        DWORD available = 0;
        if (!WinHttpQueryDataAvailable(request.get(), &available))
            throw Error(winError("Read HTTP response"));
        if (!available)
            break;
        if (output.size() + available > limit)
            throw Error("HTTP response exceeds size limit");
        auto offset = output.size();
        output.resize(offset + available);
        DWORD read = 0;
        if (!WinHttpReadData(request.get(), output.data() + offset, available, &read))
            throw Error(winError("Read HTTP response"));
        output.resize(offset + read);
    }
    return output;
}
void clipboardSet(std::string_view text) {
    auto value = wide(text);
    if (!OpenClipboard(nullptr))
        throw Error(winError("Open clipboard"));
    HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, (value.size() + 1) * sizeof(wchar_t));
    if (!memory) {
        CloseClipboard();
        throw Error("Clipboard allocation failed");
    }
    auto target = GlobalLock(memory);
    if (!target) {
        GlobalFree(memory);
        CloseClipboard();
        throw Error("Clipboard lock failed");
    }
    memcpy(target, value.c_str(), (value.size() + 1) * sizeof(wchar_t));
    GlobalUnlock(memory);
    if (!EmptyClipboard() || !SetClipboardData(CF_UNICODETEXT, memory)) {
        GlobalFree(memory);
        CloseClipboard();
        throw Error("Set clipboard failed");
    }
    CloseClipboard();
}
std::string clipboardGet() {
    if (!OpenClipboard(nullptr))
        throw Error("Open clipboard failed");
    auto memory = GetClipboardData(CF_UNICODETEXT);
    auto p = memory ? static_cast<const wchar_t *>(GlobalLock(memory)) : nullptr;
    std::string result;
    if (p) {
        result = utf8(p);
        GlobalUnlock(memory);
    }
    CloseClipboard();
    return result;
}
bool tcpClientOwnedBy(SOCKET socket, DWORD pid) {
    if (!pid)
        return false;
    sockaddr_in peer{}, local{};
    int len = sizeof(peer);
    if (getpeername(socket, reinterpret_cast<sockaddr *>(&peer), &len))
        return false;
    len = sizeof(local);
    if (getsockname(socket, reinterpret_cast<sockaddr *>(&local), &len))
        return false;
    for (int attempt = 0; attempt < 3; ++attempt) {
        DWORD size = 0;
        if (GetExtendedTcpTable(nullptr, &size, FALSE, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0) !=
                ERROR_INSUFFICIENT_BUFFER ||
            !size)
            return false;
        std::vector<BYTE> buffer(size);
        DWORD result = GetExtendedTcpTable(buffer.data(), &size, FALSE, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0);
        if (result == ERROR_INSUFFICIENT_BUFFER)
            continue;
        if (result != NO_ERROR)
            return false;
        auto table = reinterpret_cast<MIB_TCPTABLE_OWNER_PID *>(buffer.data());
        for (DWORD i = 0; i < table->dwNumEntries; ++i) {
            const auto &row = table->table[i];
            if (row.dwOwningPid == pid && row.dwLocalAddr == peer.sin_addr.s_addr &&
                static_cast<USHORT>(row.dwLocalPort) == peer.sin_port &&
                row.dwRemoteAddr == local.sin_addr.s_addr &&
                static_cast<USHORT>(row.dwRemotePort) == local.sin_port)
                return true;
        }
        return false;
    }
    return false;
}
void log(const fs::path &directory, std::string_view text) {
    static std::mutex mutex;
    std::lock_guard lock(mutex);
    try {
        fs::create_directories(directory);
        std::ofstream f(directory / L"executor.log", std::ios::app);
        f << GetTickCount64() << " " << text << "\n";
    } catch (...) {
        OutputDebugStringW(wide(text).c_str());
    }
}
} // namespace fe
