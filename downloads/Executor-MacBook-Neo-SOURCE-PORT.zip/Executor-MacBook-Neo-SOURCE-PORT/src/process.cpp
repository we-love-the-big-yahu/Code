#include "process.hpp"
#include "compiler.hpp"
#include <tlhelp32.h>
#include <nlohmann/json.hpp>
#include <thread>
#include <set>
namespace fe {
using json = nlohmann::json;
namespace {
struct Target {
    DWORD pid = 0;
    HWND window = nullptr;
};
Target findTarget() {
    Target target;
    EnumWindows(
        [](HWND h, LPARAM param) -> BOOL {
            if (!IsWindowVisible(h) || GetWindow(h, GW_OWNER))
                return TRUE;
            DWORD pid = 0;
            GetWindowThreadProcessId(h, &pid);
            Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid));
            if (!process)
                return TRUE;
            wchar_t path[32768];
            DWORD n = 32768;
            if (QueryFullProcessImageNameW(process.get(), 0, path, &n) &&
                _wcsicmp(fs::path(std::wstring(path, n)).filename().c_str(), L"RobloxPlayerBeta.exe") == 0) {
                auto &found = *reinterpret_cast<Target *>(param);
                found = {pid, h};
                return FALSE;
            }
            return TRUE;
        },
        reinterpret_cast<LPARAM>(&target));
    return target;
}
uint64_t number(const json &j) {
    if (j.is_number_unsigned())
        return j.get<uint64_t>();
    if (j.is_number_integer()) {
        auto value = j.get<int64_t>();
        if (value >= 0)
            return static_cast<uint64_t>(value);
    }
    if (j.is_string())
        return std::stoull(j.get<std::string>(), nullptr, 0);
    throw Error("Invalid offset value");
}
uint64_t valueAt(const json &j, std::initializer_list<const char *> path) {
    const json *current = &j;
    for (auto key : path)
        current = &current->at(key);
    return number(*current);
}
Offsets parseOffsets(const json &j) {
    Offsets o;
    o.fakeDm = number(j.at("fake_datamodel_ptr"));
    o.realDm = number(j.at("real_datamodel_ptr"));
    o.name = number(j.at("ins_name"));
    o.nameContainer = number(j.at("ins_name_container"));
    o.classDescriptor = number(j.at("ins_class_desc"));
    o.className = number(j.at("ins_class_name"));
    o.parent = number(j.at("ins_parent"));
    o.children = number(j.at("ins_children_start"));
    o.childrenEnd = number(j.at("ins_children_end"));
    o.value = number(j.at("value"));
    o.stringLength = number(j.at("string_length"));
    o.enableLoadModule = number(j.at("fflag_enable_load_module"));
    if (j.contains("fflag_task_scheduler_target_fps") && !j["fflag_task_scheduler_target_fps"].is_null())
        o.fps = number(j["fflag_task_scheduler_target_fps"]);
    return o;
}
void escapeKey() {
    INPUT input{};
    input.type = INPUT_KEYBOARD;
    input.ki.wScan = static_cast<WORD>(MapVirtualKeyW(VK_ESCAPE, MAPVK_VK_TO_VSC));
    input.ki.dwFlags = KEYEVENTF_SCANCODE;
    if (SendInput(1, &input, sizeof(INPUT)) != 1)
        throw Error(winError("Send Escape key down"));
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    input.ki.dwFlags |= KEYEVENTF_KEYUP;
    if (SendInput(1, &input, sizeof(INPUT)) != 1)
        throw Error(winError("Send Escape key up"));
}
} // namespace
bool Roblox::available() {
    return findTarget().pid != 0;
}
bool Roblox::attached() const {
    std::lock_guard lock(mutex_);
    return process_ && WaitForSingleObject(process_.get(), 0) == WAIT_TIMEOUT;
}
DWORD Roblox::pid() const {
    std::lock_guard lock(mutex_);
    return attached() ? pid_ : 0;
}
void Roblox::detach() {
    std::lock_guard lock(mutex_);
    process_.reset();
    pid_ = 0;
    base_ = 0;
    window_ = nullptr;
    confirmedDm_ = 0;
}
void Roblox::attach() {
    std::lock_guard lock(mutex_);
    if (attached())
        return;
    detach();
    auto target = findTarget();
    if (!target.pid)
        throw Error("Open Roblox before attaching");
    process_.reset(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_VM_READ | PROCESS_VM_WRITE |
                                   PROCESS_VM_OPERATION | SYNCHRONIZE,
                               FALSE, target.pid));
    if (!process_)
        throw Error(winError("Open Roblox process"));
    pid_ = target.pid;
    window_ = target.window;
    try {
        Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid_));
        if (!snapshot)
            throw Error(winError("Read Roblox modules"));
        MODULEENTRY32W module{};
        module.dwSize = sizeof(module);
        bool found = false;
        if (Module32FirstW(snapshot.get(), &module)) {
            do {
                if (_wcsicmp(module.szModule, L"RobloxPlayerBeta.exe") == 0) {
                    base_ = reinterpret_cast<uintptr_t>(module.modBaseAddr);
                    exe_ = module.szExePath;
                    version_ = utf8(exe_.parent_path().filename().wstring());
                    found = true;
                    break;
                }
            } while (Module32NextW(snapshot.get(), &module));
        }
        if (!found)
            throw Error("Cannot find Roblox module/version");
        loadOffsets();
    } catch (...) {
        detach();
        throw;
    }
}
void Roblox::loadOffsets() {
    auto cache = data_ / L"offset_cache.json";
    json j;
    try {
        j = json::parse(readFile(cache));
        if (j.at("schema") == 2 && j.at("roblox_version") == version_) {
            offsets_ = parseOffsets(j.at("offsets"));
            return;
        }
    } catch (...) {
    }
    auto offsets =
        json::parse(httpRequest(L"https://offsets.imtheo.lol/" + wide(version_) + L"/offsets.json"));
    auto flags = json::parse(httpRequest(L"https://offsets.imtheo.lol/" + wide(version_) + L"/fflags.json"));
    if (offsets.contains("error") || flags.contains("error"))
        throw Error("Offsets are unavailable for " + version_ + ". Try again after the provider updates.");
    json values;
    const auto &source = offsets.at("Offsets");
    const std::pair<const char *, std::pair<const char *, const char *>> fields[] = {
        {"fake_datamodel_ptr", {"FakeDataModel", "Pointer"}},
        {"real_datamodel_ptr", {"FakeDataModel", "RealDataModel"}},
        {"ins_name", {"Instance", "Name"}},
        {"ins_name_container", {"Instance", "NameContainer"}},
        {"ins_class_desc", {"Instance", "ClassDescriptor"}},
        {"ins_class_name", {"Instance", "ClassName"}},
        {"ins_parent", {"Instance", "Parent"}},
        {"ins_children_start", {"Instance", "ChildrenStart"}},
        {"ins_children_end", {"Instance", "ChildrenEnd"}},
        {"value", {"Misc", "Value"}},
        {"string_length", {"Misc", "StringLength"}}};
    for (const auto &[name, path] : fields)
        values[name] = valueAt(source, {path.first, path.second});
    const auto &f = flags.at("FFlagOffsets").at("FFlags");
    values["fflag_enable_load_module"] = number(f.at("EnableLoadModule"));
    if (f.contains("TaskSchedulerTargetFps"))
        values["fflag_task_scheduler_target_fps"] = number(f.at("TaskSchedulerTargetFps"));
    offsets_ = parseOffsets(values);
    atomicWrite(cache, json{{"schema", 2}, {"roblox_version", version_}, {"offsets", values}}.dump(2));
}
uint64_t Roblox::datamodel() {
    std::lock_guard lock(mutex_);
    if (!attached())
        return 0;
    try {
        auto fake = read<uint64_t>(base_ + offsets_.fakeDm);
        return fake ? read<uint64_t>(fake + offsets_.realDm) : 0;
    } catch (...) {
        return 0;
    }
}
std::string Roblox::stringAt(uint64_t address, size_t limit) {
    if (!address)
        return {};
    std::string result;
    result.reserve(64);
    for (size_t i = 0; i < limit; ++i) {
        char c = read<char>(address + i);
        if (!c)
            break;
        result += c;
    }
    return result;
}
std::string Roblox::name(uint64_t address) {
    std::lock_guard lock(mutex_);
    if (!address)
        return {};
    try {
        auto container = read<uint64_t>(address + offsets_.nameContainer);
        auto pointer = container + offsets_.name;
        try {
            return stringAt(read<uint64_t>(pointer));
        } catch (...) {
            return stringAt(pointer);
        }
    } catch (...) {
        return {};
    }
}
uint64_t Roblox::classOf(uint64_t address) {
    auto description = read<uint64_t>(address + offsets_.classDescriptor);
    return read<uint64_t>(description + offsets_.className);
}
std::vector<uint64_t> Roblox::children(uint64_t address) {
    std::lock_guard lock(mutex_);
    std::vector<uint64_t> result;
    auto children = read<uint64_t>(address + offsets_.children);
    if (!children)
        return result;
    auto first = read<uint64_t>(children), last = read<uint64_t>(children + offsets_.childrenEnd);
    if (!first || last < first || (last - first) % 16 || (last - first) / 16 > 100000)
        throw Error("Invalid Roblox child array");
    for (auto ptr = first; ptr < last; ptr += 16) {
        auto child = read<uint64_t>(ptr);
        if (child)
            result.push_back(child);
    }
    return result;
}
uint64_t Roblox::find(uint64_t address, std::initializer_list<std::string_view> path) {
    std::lock_guard lock(mutex_);
    for (auto part : path) {
        if (!address)
            return 0;
        uint64_t next = 0;
        for (auto child : children(address))
            if (name(child) == part) {
                next = child;
                break;
            }
        address = next;
    }
    return address;
}
uint64_t Roblox::service(uint64_t root, std::string_view className) {
    std::lock_guard lock(mutex_);
    return findChildByClass(root, className,
                            {{},
                             [this](uint64_t instance) { return stringAt(classOf(instance)); },
                             [this](uint64_t instance) { return children(instance); }});
}
bool Roblox::ready() {
    std::lock_guard lock(mutex_);
    try {
        auto dm = datamodel();
        if (!dm || name(dm) != "Ugc")
            return false;
        auto marker = find(service(dm, "CoreGui"), {"_funnyexecutor", "ReadyIndicator"});
        return marker && read<bool>(marker + offsets_.value);
    } catch (...) {
        return false;
    }
}
bool Roblox::confirm() {
    std::lock_guard lock(mutex_);
    auto dm = datamodel();
    if (!dm || name(dm) != "Ugc")
        return false;
    confirmedDm_ = dm;
    return true;
}
bool Roblox::runtimePresent() {
    std::lock_guard lock(mutex_);
    try {
        auto dm = datamodel();
        return dm && name(dm) == "Ugc" && find(service(dm, "CoreGui"), {"_funnyexecutor", "UpdateIndicator"});
    } catch (...) {
        return false;
    }
}
void Roblox::inject(const fs::path &binary, std::function<bool()> stopping,
                    std::function<bool()> bootstrapRequested) {
    if (ready())
        return;
    auto dm = datamodel();
    if (!dm || name(dm) != "Ugc")
        throw Error("Join a game before attaching");
    auto players = service(dm, "Players");
    if (!players || children(players).empty())
        throw GameNotReady("Waiting for Roblox's Players service to populate");
    auto module = find(service(dm, "CoreGui"), {"RobloxGui", "Modules", "PlayerList", "PlayerListManager"});
    if (!module)
        throw GameNotReady("Waiting for Roblox's PlayerListManager");
    auto bytes = readFile(binary, 4 * 1024 * 1024);
    if (bytes.empty())
        throw Error("Missing runtime bytecode");
    auto header = read<uint64_t>(module + offsets_.moduleBytecode),
         originalPointer = read<uint64_t>(header + offsets_.bytecodePointer),
         originalSize = read<uint64_t>(header + offsets_.bytecodeSize);
    auto originalState = read<int>(module + 0x160);
    auto originalFlag = read<bool>(base_ + offsets_.enableLoadModule);
    auto memory =
        VirtualAllocEx(process_.get(), nullptr, bytes.size(), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!memory)
        throw Error(winError("Allocate runtime bytecode"));
    bool changed = false;
    auto restore = [&]() {
        try {
            if (changed) {
                write(header + offsets_.bytecodePointer, originalPointer);
                write(header + offsets_.bytecodeSize, originalSize);
                write(module + 0x160, originalState);
                write(base_ + offsets_.enableLoadModule, originalFlag);
            }
            if (memory)
                VirtualFreeEx(process_.get(), memory, 0, MEM_RELEASE);
            memory = nullptr;
        } catch (const std::exception &e) {
            log(data_, e.what());
        }
    };
    HWND previous = GetForegroundWindow();
    bool pressed = false;
    try {
        SIZE_T written = 0;
        if (!WriteProcessMemory(process_.get(), memory, bytes.data(), bytes.size(), &written) ||
            written != bytes.size())
            throw Error(winError("Write runtime bytecode"));
        changed = true;
        write(base_ + offsets_.enableLoadModule, true);
        write(module + 0x160, 0);
        write(header + offsets_.bytecodePointer, reinterpret_cast<uint64_t>(memory));
        write(header + offsets_.bytecodeSize, static_cast<uint64_t>(bytes.size()));
        ShowWindow(window_, SW_RESTORE);
        SetForegroundWindow(window_);
        std::this_thread::sleep_for(std::chrono::milliseconds(80));
        if (GetForegroundWindow() != window_)
            throw Error("Bring Roblox to the foreground, then attach again");
        escapeKey();
        pressed = true;
        for (int i = 0; i < 120 && !stopping() && !bootstrapRequested(); ++i)
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        const bool started = bootstrapRequested();
        log(data_,
            started ? "Runtime bootstrap reached the bridge" : "No runtime bootstrap request received");
        restore();
        changed = false;
        if (pressed)
            escapeKey();
        if (previous && previous != window_)
            SetForegroundWindow(previous);
        auto finish = std::chrono::steady_clock::now() + std::chrono::seconds(15);
        while (!stopping() && std::chrono::steady_clock::now() < finish) {
            if (ready())
                return;
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
        }
        throw Error(started ? "Runtime initialization did not complete. Rejoin the game and retry; see "
                              "executor.log for bridge errors."
                            : "The runtime did not contact the local bridge. Rejoin the game before retrying "
                              "Attach; see executor.log.");
    } catch (...) {
        if (changed)
            restore();
        else
            VirtualFreeEx(process_.get(), memory, 0, MEM_RELEASE);
        if (previous && previous != window_)
            SetForegroundWindow(previous);
        throw;
    }
}
void Roblox::signalExecution(bool requireReady) {
    std::lock_guard lock(mutex_);
    if ((requireReady && !ready()) || (!requireReady && !runtimePresent()))
        throw Error("Attach before executing");
    auto marker = find(service(datamodel(), "CoreGui"), {"_funnyexecutor", "UpdateIndicator"});
    if (!marker)
        throw Error("Execution indicator missing");
    auto address = marker + offsets_.value;
    write(address, !read<bool>(address));
}
std::string Roblox::scriptBytecode(std::string_view holder) {
    std::lock_guard lock(mutex_);
    auto root = find(service(datamodel(), "CoreGui"), {"_funnyexecutor"});
    auto object = find(root, {holder});
    if (!object)
        throw Error("Script holder not found");
    auto script = read<uint64_t>(object + offsets_.value);
    if (!script)
        return {};
    return bytecodeAt(script);
}
std::string Roblox::bytecodeAt(uint64_t script) {
    auto type = stringAt(classOf(script));
    if (type != "LocalScript" && type != "ModuleScript")
        throw Error("This script class has no supported client bytecode reader");
    auto offset = type == "LocalScript" ? offsets_.localBytecode : offsets_.moduleBytecode;
    auto header = read<uint64_t>(script + offset);
    if (!header)
        return {};
    auto pointer = read<uint64_t>(header + offsets_.bytecodePointer),
         size = read<uint64_t>(header + offsets_.bytecodeSize);
    if (!pointer || !size)
        return {};
    if (size > 50 * 1024 * 1024)
        throw Error("Bytecode exceeds limit");
    std::string bytes(static_cast<size_t>(size), 0);
    SIZE_T n = 0;
    if (!ReadProcessMemory(process_.get(), reinterpret_cast<void *>(pointer), bytes.data(), bytes.size(),
                           &n) ||
        n != bytes.size())
        throw Error("Bytecode read failed");
    return bytes;
}
bool Roblox::sameSession(const ClientScript &script) {
    std::lock_guard lock(mutex_);
    return attached() && pid_ == script.pid && script.dataModel && datamodel() == script.dataModel;
}
ScriptScan Roblox::clientScripts(std::function<bool()> cancelled) {
    auto dm = datamodel();
    auto processId = pid();
    if (!dm || !ready())
        throw Error("Attach to a game before scanning scripts");
    ScriptReader reader{[this](uint64_t address) { return name(address); },
                        [this](uint64_t address) {
                            std::lock_guard lock(mutex_);
                            return stringAt(classOf(address));
                        },
                        [this](uint64_t address) { return children(address); }};
    auto result = scanClientScripts(dm, processId, reader, std::move(cancelled));
    if (!sameSession({0, dm, processId}))
        throw Error("The game changed during scanning. Refresh the game script list.");
    return result;
}
std::string Roblox::clientBytecode(const ClientScript &script) {
    std::lock_guard lock(mutex_);
    if (!sameSession(script))
        throw Error("The game changed. Refresh the game script list.");
    if (name(script.address) != script.name || stringAt(classOf(script.address)) != script.className)
        throw Error("The script was removed or changed. Refresh the game script list.");
    auto current = script.address;
    for (auto i = script.path.rbegin(); i != script.path.rend(); ++i) {
        if (!current || current == script.dataModel || name(current) != *i)
            throw Error("The script moved or was removed. Refresh the game script list.");
        current = read<uint64_t>(current + offsets_.parent);
    }
    if (current != script.dataModel)
        throw Error("The script no longer belongs to the scanned game");
    auto bytes = bytecodeAt(script.address);
    if (bytes.empty())
        throw Error("No readable client bytecode for this script");
    try {
        return Compiler::decrypt(bytes);
    } catch (const Error &) {
        return bytes;
    }
}
bool Roblox::setFps(int fps) {
    std::lock_guard lock(mutex_);
    if (!attached() || !offsets_.fps)
        return false;
    write(base_ + offsets_.fps, fps);
    return true;
}
int Roblox::fps() {
    std::lock_guard lock(mutex_);
    if (!attached() || !offsets_.fps)
        throw Error("FPS offset unavailable");
    return read<int>(base_ + offsets_.fps);
}
fs::path Roblox::contentDirectory() const {
    std::lock_guard lock(mutex_);
    if (!attached() || !fs::is_directory(exe_.parent_path() / L"content"))
        throw Error("Roblox content directory unavailable");
    return exe_.parent_path() / L"content";
}
std::string Roblox::version() const {
    std::lock_guard lock(mutex_);
    return version_;
}
} // namespace fe
