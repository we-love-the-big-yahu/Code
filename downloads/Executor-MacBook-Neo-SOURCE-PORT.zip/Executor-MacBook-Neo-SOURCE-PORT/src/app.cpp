#include "app.hpp"
#include <dwmapi.h>
#include <shellapi.h>
#include <richole.h>
#include <tom.h>
#include <set>
#include <functional>
#include <nlohmann/json.hpp>
namespace fe {
namespace {
constexpr UINT workerMessage = WM_APP + 1;
enum Id {
    New = 100,
    CloseTab,
    Attach,
    Execute,
    Import,
    Export,
    Save,
    Clear,
    Topmost,
    Sidebar,
    Refresh,
    OpenData,
    MoveLeft,
    MoveRight,
    Quit,
    BrowserMode,
    ScanGame,
    DecompileSelected,
    DecompileAll,
    CancelDecompile,
    Editor = 1000
};
std::wstring windowText(HWND control) {
    int n = GetWindowTextLengthW(control);
    std::wstring text(n + 1, 0);
    wchar_t name[64]{};
    GetClassNameW(control, name, 64);
    if (_wcsicmp(name, MSFTEDIT_CLASS) == 0) {
        GETTEXTEX options{};
        options.cb = static_cast<DWORD>(text.size() * sizeof(wchar_t));
        options.flags = GT_DEFAULT;
        options.codepage = 1200;
        auto length = SendMessageW(control, EM_GETTEXTEX, reinterpret_cast<WPARAM>(&options),
                                   reinterpret_cast<LPARAM>(text.data()));
        text.resize(static_cast<size_t>(length));
    } else {
        GetWindowTextW(control, text.data(), n + 1);
        text.resize(n);
    }
    return text;
}
void setText(HWND control, std::string_view text) {
    SetWindowTextW(control, wide(text).c_str());
}
void menuItem(HMENU menu, UINT id, const wchar_t *label) {
    AppendMenuW(menu, MF_STRING, id, label);
}
} // namespace
App::App(HINSTANCE instance, fs::path assets, fs::path data, bool smoke)
    : instance_(instance), smoke_(smoke), data_(std::move(data)), assets_(std::move(assets)),
      compiler_(assets_ / L"luau/compile.exe"), roblox_(data_), bridge_(data_, assets_, compiler_, roblox_) {
    fs::create_directories(data_ / L"scripts");
    fs::create_directories(data_ / L"autoexec");
    fs::create_directories(data_ / L"workspace");
    fs::create_directories(data_ / L"decompiled");
    if (!smoke_ && !fs::exists(data_ / L"tabs.json")) {
        auto legacy = data_.parent_path() / L"FunnyExecutor/tabs.json";
        if (fs::exists(legacy)) {
            try {
                auto raw = readFile(legacy, 16 * 1024 * 1024);
                auto value = nlohmann::json::parse(raw);
                if (!value.is_array() || value.empty())
                    throw Error("Legacy session is invalid");
                atomicWrite(data_ / L"tabs.json", raw);
            } catch (const std::exception &e) {
                recovery_ =
                    "The Python app's saved tabs could not be imported. Its file was left untouched.\n\n" +
                    std::string(e.what());
            }
        }
    }
    auto loaded = loadSession(data_ / L"tabs.json");
    if (!loaded.recovery.empty())
        recovery_ = loaded.recovery;
    saveAllowed_ = loaded.saveAllowed;
    nextTab_ = loaded.session.nextTab;
    active_ = loaded.session.active;
    INITCOMMONCONTROLSEX controls{sizeof(controls), ICC_TAB_CLASSES | ICC_TREEVIEW_CLASSES};
    InitCommonControlsEx(&controls);
    if (!LoadLibraryW(L"Msftedit.dll"))
        throw Error("Cannot load Windows Rich Edit");
    WNDCLASSEXW cls{sizeof(cls)};
    cls.hInstance = instance_;
    cls.lpfnWndProc = windowProc;
    cls.lpszClassName = L"FunnyExecutorNativeWindow";
    cls.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    cls.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    RegisterClassExW(&cls);
    WNDCLASSEXW gutter{sizeof(gutter)};
    gutter.hInstance = instance_;
    gutter.lpfnWndProc = gutterProc;
    gutter.lpszClassName = L"FunnyExecutorNativeGutter";
    gutter.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    RegisterClassExW(&gutter);
    window_ = CreateWindowExW(topmost_ ? WS_EX_TOPMOST : 0, cls.lpszClassName, L"Funny Executor — C++",
                              WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 1200, 740, nullptr, nullptr,
                              instance_, this);
    if (!window_)
        throw Error(winError("Create application window"));
    BOOL dark = TRUE;
    DwmSetWindowAttribute(window_, 20, &dark, sizeof(dark));
    createUi();
    size_t selected = active_;
    for (auto &tab : loaded.session.tabs)
        newTab(wide(tab.name), tab.content);
    selectTab(std::min(selected, tabs_.size() - 1));
    refreshTree();
    layout();
    if (smoke_)
        smokeChecks();
    if (!smoke_)
        worker_ = std::jthread([this](std::stop_token stop) { workerLoop(stop); });
    SetTimer(window_, 1, 10000, nullptr);
    SetTimer(window_, 2, 300, nullptr);
    if (smoke_)
        SetTimer(window_, 3, 400, nullptr);
}
App::~App() {
    if (worker_.joinable()) {
        worker_.request_stop();
        commandsCv_.notify_all();
        worker_.join();
    }
    bridge_.stop();
    if (window_ && IsWindow(window_))
        DestroyWindow(window_);
    if (uiFont_)
        DeleteObject(uiFont_);
    if (editorFont_)
        DeleteObject(editorFont_);
    if (headingFont_)
        DeleteObject(headingFont_);
    if (background_)
        DeleteObject(background_);
    if (panel_)
        DeleteObject(panel_);
}
int App::scale(int value) const {
    return MulDiv(value, window_ ? static_cast<int>(GetDpiForWindow(window_)) : 96, 96);
}
void App::createUi() {
    background_ = CreateSolidBrush(RGB(19, 19, 19));
    panel_ = CreateSolidBrush(RGB(15, 15, 15));
    uiFont_ =
        CreateFontW(-scale(14), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                    CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    headingFont_ =
        CreateFontW(-scale(17), 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                    OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    editorFont_ =
        CreateFontW(-scale(15), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                    CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, FIXED_PITCH, L"Consolas");
    auto child = [&](const wchar_t *cls, const wchar_t *text, DWORD style, UINT id) -> HWND {
        HWND h = CreateWindowExW(0, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 10, 10, window_,
                                 reinterpret_cast<HMENU>(static_cast<UINT_PTR>(id)), instance_, nullptr);
        if (!h)
            throw Error(winError("Create control"));
        SendMessageW(h, WM_SETFONT, reinterpret_cast<WPARAM>(uiFont_), TRUE);
        return h;
    };
    auto menu = CreateMenu(), file = CreatePopupMenu(), tabs = CreatePopupMenu(), view = CreatePopupMenu(),
         run = CreatePopupMenu();
    menuItem(file, New, L"New tab\tCtrl+N");
    menuItem(file, Import, L"Open script...\tCtrl+O");
    menuItem(file, Export, L"Export current script...\tCtrl+Shift+S");
    menuItem(file, Save, L"Save tabs\tCtrl+S");
    AppendMenuW(file, MF_SEPARATOR, 0, nullptr);
    menuItem(file, OpenData, L"Open data folder");
    menuItem(file, Quit, L"Exit\tAlt+F4");
    menuItem(tabs, CloseTab, L"Close current tab\tCtrl+W");
    menuItem(tabs, MoveLeft, L"Move tab left");
    menuItem(tabs, MoveRight, L"Move tab right");
    menuItem(tabs, Clear, L"Clear all tabs...");
    menuItem(view, Topmost, L"Always on top");
    menuItem(view, Sidebar, L"Show file browser");
    menuItem(view, Refresh, L"Refresh files\tF5");
    menuItem(run, Attach, L"Attach\tCtrl+I");
    menuItem(run, Execute, L"Execute\tCtrl+Enter");
    menuItem(run, ScanGame, L"Browse game scripts");
    menuItem(run, DecompileSelected, L"Decompile selected game script");
    menuItem(run, DecompileAll, L"Decompile all client scripts...");
    menuItem(run, CancelDecompile, L"Cancel decompilation");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(file), L"File");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(tabs), L"Tabs");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(view), L"View");
    AppendMenuW(menu, MF_POPUP, reinterpret_cast<UINT_PTR>(run), L"Run");
    SetMenu(window_, menu);
    CheckMenuItem(menu, Topmost, MF_BYCOMMAND | MF_CHECKED);
    CheckMenuItem(menu, Sidebar, MF_BYCOMMAND | MF_CHECKED);
    breadcrumb_ = child(L"STATIC", L"FUNNY EXECUTOR", SS_LEFT, 0);
    SendMessageW(breadcrumb_, WM_SETFONT, reinterpret_cast<WPARAM>(headingFont_), TRUE);
    status_ = child(L"STATIC", L"Idle — open Roblox to attach", SS_LEFT, 0);
    newButton_ = child(L"BUTTON", L"+ New", BS_OWNERDRAW, New);
    closeButton_ = child(L"BUTTON", L"Close tab", BS_OWNERDRAW, CloseTab);
    attachButton_ = child(L"BUTTON", L"Attach", BS_OWNERDRAW, Attach);
    executeButton_ = child(L"BUTTON", L"Execute", BS_OWNERDRAW, Execute);
    tabBar_ = child(WC_TABCONTROLW, L"", TCS_TOOLTIPS | TCS_FOCUSNEVER, 0);
    search_ = child(L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, 0);
    browserMode_ = child(L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, BrowserMode);
    SendMessageW(browserMode_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"Local files"));
    SendMessageW(browserMode_, CB_ADDSTRING, 0, reinterpret_cast<LPARAM>(L"Game scripts (client)"));
    SendMessageW(browserMode_, CB_SETCURSEL, 0, 0);
    scanButton_ = child(L"BUTTON", L"Refresh scripts", BS_OWNERDRAW, ScanGame);
    decompileButton_ = child(L"BUTTON", L"Decompile selected", BS_OWNERDRAW, DecompileSelected);
    allButton_ = child(L"BUTTON", L"Decompile all", BS_OWNERDRAW, DecompileAll);
    cancelButton_ = child(L"BUTTON", L"Cancel", BS_OWNERDRAW, CancelDecompile);
    serviceLabel_ =
        child(L"STATIC", L"Sends bytecode to api.lua.expert.\nClient scripts only; output may need edits.",
              SS_LEFT, 0);
    SendMessageW(search_, EM_SETCUEBANNER, TRUE, reinterpret_cast<LPARAM>(L"Search files"));
    tree_ = child(WC_TREEVIEWW, L"",
                  TVS_HASBUTTONS | TVS_HASLINES | TVS_LINESATROOT | TVS_SHOWSELALWAYS | WS_TABSTOP, 0);
    TreeView_SetBkColor(tree_, RGB(19, 19, 19));
    TreeView_SetTextColor(tree_, RGB(175, 175, 175));
    TreeView_SetLineColor(tree_, RGB(42, 42, 42));
    gutter_ = child(L"FunnyExecutorNativeGutter", L"", 0, 0);
    SetWindowLongPtrW(gutter_, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(this));
    updateDecompilerControls();
}
void App::layout() {
    if (!tabBar_)
        return;
    RECT r{};
    GetClientRect(window_, &r);
    int w = r.right, h = r.bottom, side = sidebar_ ? scale(310) : 0, top = scale(64), tab = scale(38),
        footer = scale(30), gutter = scale(48), gap = scale(12);
    MoveWindow(breadcrumb_, gap, scale(16), std::max(scale(100), w - scale(480)), scale(28), TRUE);
    MoveWindow(newButton_, w - scale(438), scale(12), scale(80), scale(34), TRUE);
    MoveWindow(closeButton_, w - scale(348), scale(12), scale(94), scale(34), TRUE);
    MoveWindow(attachButton_, w - scale(240), scale(12), scale(98), scale(34), TRUE);
    MoveWindow(executeButton_, w - scale(130), scale(12), scale(112), scale(34), TRUE);
    ShowWindow(search_, sidebar_ ? SW_SHOW : SW_HIDE);
    ShowWindow(tree_, sidebar_ ? SW_SHOW : SW_HIDE);
    ShowWindow(browserMode_, sidebar_ ? SW_SHOW : SW_HIDE);
    MoveWindow(browserMode_, gap, top + scale(6), side - 2 * gap, scale(200), TRUE);
    MoveWindow(search_, gap, top + scale(42), side - 2 * gap, scale(30), TRUE);
    const bool gameVisible = sidebar_ && gameMode_;
    for (auto control : {scanButton_, decompileButton_, allButton_, cancelButton_, serviceLabel_})
        ShowWindow(control, gameVisible ? SW_SHOW : SW_HIDE);
    MoveWindow(scanButton_, gap, top + scale(80), side - 2 * gap, scale(28), TRUE);
    MoveWindow(decompileButton_, gap, top + scale(114), side - 2 * gap, scale(28), TRUE);
    MoveWindow(allButton_, gap, top + scale(148), scale(188), scale(28), TRUE);
    MoveWindow(cancelButton_, gap + scale(196), top + scale(148), scale(90), scale(28), TRUE);
    MoveWindow(serviceLabel_, gap, top + scale(182), side - 2 * gap, scale(48), TRUE);
    int treeTop = top + scale(gameMode_ ? 238 : 80);
    MoveWindow(tree_, gap, treeTop, side - 2 * gap, std::max(0, h - treeTop - footer), TRUE);
    MoveWindow(tabBar_, side, top, std::max(0, w - side), tab, TRUE);
    MoveWindow(gutter_, side, top + tab, gutter, std::max(0, h - top - tab - footer), TRUE);
    for (auto &t : tabs_)
        MoveWindow(t.editor, side + gutter, top + tab, std::max(0, w - side - gutter),
                   std::max(0, h - top - tab - footer), TRUE);
    MoveWindow(status_, gap, h - footer + scale(6), w - 2 * gap, scale(20), TRUE);
    InvalidateRect(window_, nullptr, TRUE);
    InvalidateRect(gutter_, nullptr, TRUE);
}
void App::newTab(std::wstring name, std::string content) {
    if (tabs_.size() >= 256) {
        showError("The session supports up to 256 tabs.");
        return;
    }
    if (name.empty())
        name = L"Script #" + std::to_wstring(++nextTab_);
    auto editor = CreateWindowExW(0, MSFTEDIT_CLASS, L"",
                                  WS_CHILD | WS_VSCROLL | WS_HSCROLL | WS_TABSTOP | ES_MULTILINE |
                                      ES_AUTOVSCROLL | ES_AUTOHSCROLL | ES_NOHIDESEL,
                                  0, 0, 10, 10, window_,
                                  reinterpret_cast<HMENU>(static_cast<UINT_PTR>(Editor + tabs_.size())),
                                  instance_, nullptr);
    if (!editor)
        throw Error("Cannot create code editor");
    SendMessageW(editor, EM_SETTEXTMODE, TM_RICHTEXT, 0);
    SendMessageW(editor, WM_SETFONT, reinterpret_cast<WPARAM>(editorFont_), FALSE);
    SendMessageW(editor, EM_SETBKGNDCOLOR, 0, RGB(19, 19, 19));
    SendMessageW(editor, EM_EXLIMITTEXT, 0, 16 * 1024 * 1024);
    SendMessageW(editor, EM_SETEVENTMASK, 0, ENM_CHANGE | ENM_SCROLL);
    CHARFORMAT2W format{};
    format.cbSize = sizeof(format);
    format.dwMask = CFM_COLOR;
    format.crTextColor = RGB(208, 208, 208);
    SendMessageW(editor, EM_SETCHARFORMAT, SCF_ALL, reinterpret_cast<LPARAM>(&format));
    setText(editor, content);
    SendMessageW(editor, EM_EMPTYUNDOBUFFER, 0, 0);
    tabs_.push_back({editor, std::move(name)});
    updateTabLabels();
    selectTab(tabs_.size() - 1);
    layout();
}
void App::updateTabLabels() {
    TabCtrl_DeleteAllItems(tabBar_);
    for (size_t i = 0; i < tabs_.size(); ++i) {
        TCITEMW item{};
        item.mask = TCIF_TEXT;
        item.pszText = tabs_[i].name.data();
        TabCtrl_InsertItem(tabBar_, static_cast<int>(i), &item);
    }
    if (!tabs_.empty())
        TabCtrl_SetCurSel(tabBar_, static_cast<int>(active_));
}
void App::selectTab(size_t index) {
    if (index >= tabs_.size())
        return;
    active_ = index;
    for (size_t i = 0; i < tabs_.size(); ++i)
        ShowWindow(tabs_[i].editor, i == index ? SW_SHOW : SW_HIDE);
    TabCtrl_SetCurSel(tabBar_, static_cast<int>(index));
    SetWindowTextW(breadcrumb_, (L"Funny Executor  ›  " + tabs_[index].name).c_str());
    SetFocus(tabs_[index].editor);
    highlightPending_ = true;
    InvalidateRect(gutter_, nullptr, TRUE);
}
void App::closeTab() {
    if (tabs_.empty())
        return;
    DestroyWindow(tabs_[active_].editor);
    tabs_.erase(tabs_.begin() + active_);
    if (tabs_.empty()) {
        active_ = 0;
        newTab();
    } else {
        active_ = std::min(active_, tabs_.size() - 1);
        updateTabLabels();
        selectTab(active_);
    }
    layout();
}
void App::moveTab(int direction) {
    if (tabs_.empty())
        return;
    auto next = static_cast<int>(active_) + direction;
    if (next < 0 || next >= static_cast<int>(tabs_.size()))
        return;
    std::swap(tabs_[active_], tabs_[next]);
    active_ = static_cast<size_t>(next);
    updateTabLabels();
    selectTab(active_);
}
bool App::save(bool show) {
    if (!saveAllowed_)
        return true;
    try {
        Session session;
        session.nextTab = nextTab_;
        session.active = active_;
        session.tabs.clear();
        for (auto &tab : tabs_)
            session.tabs.push_back({utf8(tab.name), utf8(windowText(tab.editor))});
        saveSession(data_ / L"tabs.json", session);
        return true;
    } catch (const std::exception &e) {
        log(data_, e.what());
        if (show)
            showError("Tabs could not be saved. Your previous saved file is unchanged. Export important "
                      "scripts before closing.\n\n" +
                      std::string(e.what()));
        return false;
    }
}
void App::showError(std::string_view text) {
    if (smoke_) {
        log(data_, text);
        return;
    }
    MessageBoxW(window_, wide(text).c_str(), L"Funny Executor", MB_OK | MB_ICONWARNING | MB_TOPMOST);
}
void App::refreshTree() {
    auto query = lower(utf8(windowText(search_)));
    TreeView_DeleteAllItems(tree_);
    treePaths_.clear();
    if (gameMode_) {
        for (size_t i = 0; i < gameScripts_.size(); ++i) {
            const auto &script = gameScripts_[i];
            auto location = scriptLocation(script);
            if (!query.empty() && lower(location + " " + script.className).find(query) == std::string::npos)
                continue;
            auto label = wide(location + " [" + script.className + "]");
            TVINSERTSTRUCTW item{};
            item.hParent = TVI_ROOT;
            item.hInsertAfter = TVI_LAST;
            item.item.mask = TVIF_TEXT | TVIF_PARAM;
            item.item.pszText = label.data();
            item.item.lParam = static_cast<LPARAM>(i + 1);
            TreeView_InsertItem(tree_, &item);
        }
        if (gameScripts_.empty()) {
            TVINSERTSTRUCTW item{};
            item.hParent = TVI_ROOT;
            item.hInsertAfter = TVI_LAST;
            item.item.mask = TVIF_TEXT;
            item.item.pszText = const_cast<wchar_t *>(L"Attach, then click Refresh scripts");
            TreeView_InsertItem(tree_, &item);
        }
        updateDecompilerControls();
        return;
    }
    auto insert = [&](HTREEITEM parent, const fs::path &path, std::wstring label, bool file) -> HTREEITEM {
        TVINSERTSTRUCTW value{};
        value.hParent = parent;
        value.hInsertAfter = TVI_LAST;
        value.item.mask = TVIF_TEXT | TVIF_PARAM;
        value.item.pszText = label.data();
        if (file) {
            treePaths_.push_back(path);
            value.item.lParam = static_cast<LPARAM>(treePaths_.size());
        }
        return TreeView_InsertItem(tree_, &value);
    };
    size_t count = 0;
    std::function<void(HTREEITEM, const fs::path &, int)> visit = [&](HTREEITEM parent, const fs::path &dir,
                                                                      int depth) {
        if (depth > 8 || count > 10000)
            return;
        std::vector<fs::directory_entry> entries;
        std::error_code ec;
        for (auto i = fs::directory_iterator(dir, ec); i != fs::directory_iterator(); i.increment(ec)) {
            if (ec)
                break;
            entries.push_back(*i);
        }
        std::sort(entries.begin(), entries.end(), [](const auto &a, const auto &b) {
            return a.path().filename().wstring() < b.path().filename().wstring();
        });
        for (auto &entry : entries) {
            if (++count > 10000)
                break;
            if (entry.is_symlink(ec))
                continue;
            auto label = entry.path().filename().wstring();
            if (entry.is_directory(ec)) {
                auto folder = insert(parent, entry.path(), label, false);
                visit(folder, entry.path(), depth + 1);
                if (!query.empty() && !TreeView_GetChild(tree_, folder))
                    TreeView_DeleteItem(tree_, folder);
                else if (!query.empty())
                    TreeView_Expand(tree_, folder, TVE_EXPAND);
            } else if (entry.is_regular_file(ec) &&
                       (query.empty() || lower(utf8(label)).find(query) != std::string::npos))
                insert(parent, entry.path(), label, true);
        }
    };
    for (const auto &[label, name] :
         std::vector<std::pair<std::wstring, std::wstring>>{{L"Scripts", L"scripts"},
                                                            {L"Auto-Execute", L"autoexec"},
                                                            {L"Workspace", L"workspace"},
                                                            {L"Decompiled", L"decompiled"}}) {
        auto node = insert(TVI_ROOT, data_ / name, label, false);
        visit(node, data_ / name, 0);
        TreeView_Expand(tree_, node, TVE_EXPAND);
    }
}
void App::updateDecompilerControls() {
    EnableWindow(scanButton_, !decompileBusy_ && !closing_);
    EnableWindow(decompileButton_, !decompileBusy_ && !closing_ && !gameScripts_.empty());
    EnableWindow(allButton_, !decompileBusy_ && !closing_ && !gameScripts_.empty());
    EnableWindow(cancelButton_, decompileBusy_ && !closing_);
    auto menu = GetMenu(window_);
    for (auto id : {ScanGame, DecompileSelected, DecompileAll})
        EnableMenuItem(menu, id, MF_BYCOMMAND | (decompileBusy_ || closing_ ? MF_GRAYED : MF_ENABLED));
    EnableMenuItem(menu, CancelDecompile, MF_BYCOMMAND | (decompileBusy_ ? MF_ENABLED : MF_GRAYED));
}
void App::requestScan() {
    if (decompileBusy_)
        return;
    gameMode_ = true;
    sidebar_ = true;
    CheckMenuItem(GetMenu(window_), Sidebar, MF_BYCOMMAND | MF_CHECKED);
    SendMessageW(browserMode_, CB_SETCURSEL, 1, 0);
    setText(search_, "");
    SendMessageW(search_, EM_SETCUEBANNER, TRUE, reinterpret_cast<LPARAM>(L"Search script path or class"));
    refreshTree();
    layout();
    cancelDecompile_ = false;
    if (enqueue({Command::Action::Scan})) {
        decompileBusy_ = true;
        setText(status_, "Scanning client-visible scripts...");
        updateDecompilerControls();
    }
}
void App::requestDecompile(bool all) {
    if (decompileBusy_)
        return;
    if (!gameMode_ || gameScripts_.empty()) {
        requestScan();
        return;
    }
    Command command;
    command.action = all ? Command::Action::ExportAll : Command::Action::Decompile;
    if (all)
        command.scripts = gameScripts_;
    else {
        TVITEMW item{};
        item.mask = TVIF_PARAM;
        item.hItem = TreeView_GetSelection(tree_);
        if (!TreeView_GetItem(tree_, &item) || item.lParam <= 0 ||
            static_cast<size_t>(item.lParam) > gameScripts_.size()) {
            showError("Select a game script to decompile.");
            return;
        }
        command.scripts.push_back(gameScripts_[static_cast<size_t>(item.lParam) - 1]);
    }
    cancelDecompile_ = false;
    if (enqueue(std::move(command))) {
        decompileBusy_ = true;
        setText(status_,
                all ? "Decompiling client scripts to a folder..." : "Decompiling selected script...");
        updateDecompilerControls();
    }
}
void App::decompileCommand(const Command &command, std::stop_token stop) {
    auto cancelled = [&] { return stop.stop_requested() || cancelDecompile_.load(); };
    if (command.scripts.empty())
        throw Error("Refresh the game script list first");
    if (cancelled())
        throw Error("Decompilation cancelled");
    if (!roblox_.sameSession(command.scripts.front()))
        throw Error("The game changed. Refresh the game script list.");
    Decompiler decompiler(data_ / L"cache/decompiled");
    if (command.action == Command::Action::Decompile) {
        const auto &script = command.scripts.front();
        auto source = decompiler.decompile(roblox_.clientBytecode(script), cancelled);
        if (!roblox_.sameSession(script))
            throw Error("The game changed during decompilation. Refresh scripts.");
        Event event{"Decompiled " + scriptLocation(script)};
        event.tabName = script.name + ".decompiled.luau";
        event.source = "-- Decompiled client script. Results may need correction.\n-- Path: " +
                       nlohmann::json(script.path).dump() + "\n\n" + source;
        event.jobFinished = true;
        notify(std::move(event));
        return;
    }
    auto folder = data_ / L"decompiled" / (L"game-" + wide(randomHex(8)));
    auto result = exportClientScripts(
        command.scripts, folder, decompiler,
        [this](const ClientScript &script) { return roblox_.clientBytecode(script); },
        [this](const ClientScript &script) { return roblox_.sameSession(script); }, cancelled,
        [&](size_t i, const ClientScript &script) {
            notify({"Decompiling " + std::to_string(i + 1) + "/" + std::to_string(command.scripts.size()) +
                    " — " + script.name});
        });
    const auto &reason = result.stopReason;
    const auto success = result.saved, failed = result.failed;
    Event event{(reason.empty() ? "Export finished" : reason) + ": " + std::to_string(success) + " saved, " +
                std::to_string(failed) + " failed. See manifest.json."};
    event.folder = folder;
    event.jobFinished = true;
    notify(std::move(event));
}
void App::openFile(const fs::path &path) {
    try {
        newTab(path.filename().wstring(), readFile(path, 16 * 1024 * 1024));
    } catch (const std::exception &e) {
        showError(e.what());
    }
}
void App::importFile() {
    wchar_t path[32768]{};
    OPENFILENAMEW dialog{};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = window_;
    dialog.lpstrFile = path;
    dialog.nMaxFile = 32768;
    dialog.lpstrFilter = L"Luau scripts\0*.lua;*.luau\0All files\0*.*\0\0";
    dialog.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
    if (GetOpenFileNameW(&dialog))
        openFile(path);
}
void App::exportFile() {
    if (tabs_.empty())
        return;
    wchar_t path[32768]{};
    auto name = tabs_[active_].name;
    if (name.find(L'.') == name.npos)
        name += L".luau";
    wcsncpy_s(path, name.c_str(), _TRUNCATE);
    OPENFILENAMEW dialog{};
    dialog.lStructSize = sizeof(dialog);
    dialog.hwndOwner = window_;
    dialog.lpstrFile = path;
    dialog.nMaxFile = 32768;
    dialog.lpstrDefExt = L"luau";
    dialog.lpstrFilter = L"Luau scripts\0*.lua;*.luau\0All files\0*.*\0\0";
    dialog.Flags = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
    if (GetSaveFileNameW(&dialog)) {
        try {
            atomicWrite(path, utf8(windowText(tabs_[active_].editor)));
            refreshTree();
        } catch (const std::exception &e) {
            showError(e.what());
        }
    }
}
void App::highlight() {
    highlightPending_ = false;
    if (tabs_.empty() || formatting_)
        return;
    HWND editor = tabs_[active_].editor;
    auto text = windowText(editor);
    if (text.size() > 200000)
        return;
    formatting_ = true;
    CHARRANGE selection{};
    SendMessageW(editor, EM_EXGETSEL, 0, reinterpret_cast<LPARAM>(&selection));
    POINT scroll{};
    SendMessageW(editor, EM_GETSCROLLPOS, 0, reinterpret_cast<LPARAM>(&scroll));
    BOOL dirty = static_cast<BOOL>(SendMessageW(editor, EM_GETMODIFY, 0, 0));
    IRichEditOle *ole = nullptr;
    ITextDocument *document = nullptr;
    if (SendMessageW(editor, EM_GETOLEINTERFACE, 0, reinterpret_cast<LPARAM>(&ole)) && ole) {
        if (SUCCEEDED(ole->QueryInterface(__uuidof(ITextDocument), reinterpret_cast<void **>(&document))))
            document->Undo(tomSuspend, nullptr);
    }
    SendMessageW(editor, WM_SETREDRAW, FALSE, 0);
    auto color = [&](size_t start, size_t length, COLORREF rgb) {
        CHARRANGE range{static_cast<LONG>(start), static_cast<LONG>(start + length)};
        SendMessageW(editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&range));
        CHARFORMAT2W format{};
        format.cbSize = sizeof(format);
        format.dwMask = CFM_COLOR;
        format.crTextColor = rgb;
        SendMessageW(editor, EM_SETCHARFORMAT, SCF_SELECTION, reinterpret_cast<LPARAM>(&format));
    };
    color(0, text.size(), RGB(208, 208, 208));
    static const std::set<std::wstring> keywords = {
        L"and",  L"break", L"do",    L"else",     L"elseif", L"end", L"for",    L"function",
        L"if",   L"in",    L"local", L"nil",      L"not",    L"or",  L"repeat", L"return",
        L"then", L"until", L"while", L"continue", L"export", L"type"};
    static const std::set<std::wstring> globals = {
        L"print",   L"warn",     L"math",   L"string",     L"table",   L"game",    L"workspace",
        L"task",    L"Instance", L"Enum",   L"loadstring", L"getgenv", L"getrenv", L"Vector3",
        L"Vector2", L"CFrame",   L"Color3", L"Drawing",    L"crypt",   L"request", L"pairs",
        L"ipairs",  L"next",     L"pcall",  L"assert",     L"error",   L"true",    L"false"};
    for (size_t i = 0; i < text.size();) {
        size_t start = i;
        if (i + 1 < text.size() && text[i] == '-' && text[i + 1] == '-') {
            i += 2;
            if (i + 1 < text.size() && text[i] == '[' && text[i + 1] == '[') {
                auto end = text.find(L"]]", i + 2);
                i = end == text.npos ? text.size() : end + 2;
            } else {
                while (i < text.size() && text[i] != '\r' && text[i] != '\n')
                    ++i;
            }
            color(start, i - start, RGB(105, 105, 105));
        } else if (text[i] == '\'' || text[i] == '"') {
            auto quote = text[i++];
            while (i < text.size()) {
                if (text[i] == '\\') {
                    i = std::min(i + 2, text.size());
                    continue;
                }
                if (text[i++] == quote)
                    break;
            }
            color(start, i - start, RGB(171, 212, 180));
        } else if (iswdigit(text[i])) {
            while (i < text.size() && (iswalnum(text[i]) || text[i] == '.' || text[i] == '_'))
                ++i;
            color(start, i - start, RGB(214, 204, 97));
        } else if (iswalpha(text[i]) || text[i] == '_') {
            while (i < text.size() && (iswalnum(text[i]) || text[i] == '_'))
                ++i;
            auto token = text.substr(start, i - start);
            if (keywords.contains(token))
                color(start, i - start, RGB(142, 154, 230));
            else if (globals.contains(token))
                color(start, i - start, RGB(214, 204, 97));
        } else
            ++i;
    }
    SendMessageW(editor, EM_EXSETSEL, 0, reinterpret_cast<LPARAM>(&selection));
    SendMessageW(editor, EM_SETSCROLLPOS, 0, reinterpret_cast<LPARAM>(&scroll));
    SendMessageW(editor, EM_SETMODIFY, dirty, 0);
    if (document) {
        document->Undo(tomResume, nullptr);
        document->Release();
    }
    if (ole)
        ole->Release();
    SendMessageW(editor, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(editor, nullptr, FALSE);
    formatting_ = false;
    highlightPending_ = false;
}
void App::drawGutter(HDC dc) {
    RECT r{};
    GetClientRect(gutter_, &r);
    FillRect(dc, &r, background_);
    SelectObject(dc, editorFont_);
    SetTextColor(dc, RGB(80, 80, 80));
    SetBkMode(dc, TRANSPARENT);
    if (tabs_.empty())
        return;
    auto editor = tabs_[active_].editor;
    LONG first = static_cast<LONG>(SendMessageW(editor, EM_GETFIRSTVISIBLELINE, 0, 0)),
         total = static_cast<LONG>(SendMessageW(editor, EM_GETLINECOUNT, 0, 0));
    TEXTMETRICW metrics{};
    GetTextMetricsW(dc, &metrics);
    int height = metrics.tmHeight;
    for (LONG line = first; line < total; ++line) {
        auto index = static_cast<LONG>(SendMessageW(editor, EM_LINEINDEX, line, 0));
        POINT point{};
        SendMessageW(editor, EM_POSFROMCHAR, reinterpret_cast<WPARAM>(&point), index);
        if (point.y > r.bottom)
            break;
        RECT area{0, point.y, r.right - scale(9), point.y + height};
        auto number = std::to_wstring(line + 1);
        DrawTextW(dc, number.c_str(), -1, &area, DT_RIGHT | DT_SINGLELINE | DT_NOPREFIX);
    }
}
void App::smokeChecks() {
    auto normalized = [](std::wstring text) {
        std::wstring out;
        for (size_t i = 0; i < text.size(); ++i) {
            if (text[i] == '\r') {
                out += '\n';
                if (i + 1 < text.size() && text[i + 1] == '\n')
                    ++i;
            } else
                out += text[i];
        }
        return out;
    };
    const std::string source = "local message = \"Native 😀 Māori\"\nprint(message)\n";
    newTab(L"Unicode smoke test", source);
    auto editor = tabs_[active_].editor;
    auto original = windowText(editor);
    if (utf8(normalized(original)) != source)
        throw Error("Native editor Unicode roundtrip failed");
    SendMessageW(editor, EM_SETSEL, 0, 5);
    highlight();
    CHARFORMAT2W format{};
    format.cbSize = sizeof(format);
    SendMessageW(editor, EM_GETCHARFORMAT, SCF_SELECTION, reinterpret_cast<LPARAM>(&format));
    if (format.crTextColor != RGB(142, 154, 230))
        throw Error("Native syntax highlighting failed");
    if (windowText(editor) != original)
        throw Error("Syntax formatting altered source text");
    SendMessageW(editor, EM_SETSEL, static_cast<WPARAM>(-1), static_cast<LPARAM>(-1));
    SendMessageW(editor, EM_REPLACESEL, TRUE, reinterpret_cast<LPARAM>(L"-- appended"));
    highlight();
    SendMessageW(editor, EM_UNDO, 0, 0);
    if (windowText(editor) != original)
        throw Error("Syntax highlighting changed undo behavior");
    selectTab(0);
    moveTab(1);
    closeTab();
    if (tabs_.size() != 1 || tabs_[0].name != L"Unicode smoke test")
        throw Error("Native tab movement/close failed");
    if (!save(false))
        throw Error("Native session save failed");
    auto loaded = loadSession(data_ / L"tabs.json");
    if (!loaded.recovery.empty() || loaded.session.tabs.size() != 1 ||
        wide(loaded.session.tabs[0].content) != original)
        throw Error("Native session restore failed");
    gameScripts_ = {{3, 1, 123, "Controller", "LocalScript", {"Players", "Controller"}},
                    {4, 1, 123, "Settings", "ModuleScript", {"ReplicatedStorage", "Settings"}}};
    gameMode_ = true;
    SendMessageW(browserMode_, CB_SETCURSEL, 1, 0);
    refreshTree();
    layout();
    if (TreeView_GetCount(tree_) != 2 || !IsWindowEnabled(allButton_))
        throw Error("Game script browser population failed");
    setText(search_, "LocalScript");
    refreshTree();
    if (TreeView_GetCount(tree_) != 1)
        throw Error("Game script browser filtering failed");
    decompileBusy_ = true;
    updateDecompilerControls();
    if (IsWindowEnabled(scanButton_) || IsWindowEnabled(allButton_) || !IsWindowEnabled(cancelButton_))
        throw Error("Decompiler busy/cancel controls failed");
    auto event = new Event{"Decompiled fixture"};
    event->jobFinished = true;
    event->tabName = "Controller.decompiled.luau";
    event->source = "return 42";
    SendMessageW(window_, workerMessage, 0, reinterpret_cast<LPARAM>(event));
    if (decompileBusy_ || tabs_.size() != 2 || utf8(windowText(tabs_[active_].editor)) != "return 42")
        throw Error("Decompiled source did not open in an editor tab");
    closeTab();
    gameScripts_.clear();
    gameMode_ = false;
    SendMessageW(browserMode_, CB_SETCURSEL, 0, 0);
    setText(search_, "");
    refreshTree();
    layout();
}
bool App::enqueue(Command command) {
    if (smoke_ || closing_)
        return false;
    {
        std::lock_guard lock(commandsMutex_);
        if (commands_.size() >= 64) {
            showError("Execution queue is full.");
            return false;
        }
        commands_.push_back(std::move(command));
    }
    commandsCv_.notify_one();
    return true;
}
void App::notify(Event event) {
    if (!window_)
        return;
    auto pointer = new Event(std::move(event));
    if (!PostMessageW(window_, workerMessage, 0, reinterpret_cast<LPARAM>(pointer)))
        delete pointer;
}
void App::workerLoop(std::stop_token stop) {
    bool bridgeReady = false, attachQueued = false;
    std::deque<std::string> compiled;
    auto retry = std::chrono::steady_clock::now();
    auto attachStarted = retry;
    auto fetchStarted = retry;
    bool fetchInFlight = false;
    std::string lastStatus;
    auto status = [&](std::string text, bool ready = false) {
        if (text != lastStatus) {
            lastStatus = text;
            notify({std::move(text), false, false, ready});
        }
    };
    try {
        bridge_.start();
        bridgeReady = true;
    } catch (const std::exception &e) {
        notify({e.what(), true});
    }
    while (!stop.stop_requested()) {
        Command command;
        bool hasCommand = false;
        {
            std::unique_lock lock(commandsMutex_);
            commandsCv_.wait_for(lock, std::chrono::milliseconds(100),
                                 [&] { return stop.stop_requested() || !commands_.empty(); });
            if (stop.stop_requested())
                break;
            if (!commands_.empty()) {
                command = std::move(commands_.front());
                commands_.pop_front();
                hasCommand = true;
            }
        }
        if (hasCommand) {
            if (command.action == Command::Action::Attach) {
                if (!bridgeReady) {
                    notify({"Close any other executor using port 9475, then restart this app.", true});
                    continue;
                }
                attachQueued = true;
                retry = std::chrono::steady_clock::now();
                attachStarted = retry;
            } else if (command.action == Command::Action::Scan ||
                       command.action == Command::Action::Decompile ||
                       command.action == Command::Action::ExportAll) {
                try {
                    if (command.action == Command::Action::Scan) {
                        auto scan = roblox_.clientScripts(
                            [&] { return stop.stop_requested() || cancelDecompile_.load(); });
                        Event event{std::to_string(scan.scripts.size()) + " client scripts found" +
                                    (scan.limited ? " (scan limit reached; list is partial)" : "") +
                                    (scan.skipped ? "; " + std::to_string(scan.skipped) +
                                                        " unreadable instances skipped"
                                                  : "")};
                        event.scan = std::move(scan);
                        event.jobFinished = true;
                        notify(std::move(event));
                    } else
                        decompileCommand(command, stop);
                } catch (const std::exception &e) {
                    Event event{e.what(), !cancelDecompile_.load() && !stop.stop_requested()};
                    event.jobFinished = true;
                    notify(std::move(event));
                }
            } else {
                try {
                    if (!roblox_.ready())
                        throw Error("Attach before executing");
                    compiled.push_back(compiler_.compile(command.source));
                    status("Script queued", true);
                } catch (const std::exception &e) {
                    notify({e.what(), true});
                }
            }
        }
        if (attachQueued && std::chrono::steady_clock::now() >= retry) {
            retry = std::chrono::steady_clock::now() + std::chrono::seconds(1);
            try {
                status("Attaching...");
                roblox_.attach();
                auto dm = roblox_.datamodel();
                if (!dm || roblox_.name(dm) != "Ugc") {
                    status("Queued — join a game");
                    continue;
                }
                if (!roblox_.ready() && roblox_.runtimePresent()) {
                    status("Reconnecting to the existing runtime...");
                    auto probe =
                        compiler_.compile(readFile(assets_ / L"luau/reconnect.luau"), "RuntimeReadiness");
                    bridge_.cancelExecution();
                    if (!bridge_.publish(std::move(probe)))
                        throw Error("Runtime probe could not be queued");
                    roblox_.signalExecution(false);
                    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(15);
                    while (!stop.stop_requested() && std::chrono::steady_clock::now() < deadline &&
                           !roblox_.ready())
                        std::this_thread::sleep_for(std::chrono::milliseconds(50));
                    if (stop.stop_requested())
                        break;
                    if (!roblox_.ready()) {
                        bool fetched = !bridge_.waitingForFetch();
                        bridge_.cancelExecution();
                        throw Error(fetched ? "The existing runtime fetched the readiness check but did not "
                                              "finish it. Rejoin the game, then Attach again."
                                            : "The existing runtime is no longer responding. Rejoin the "
                                              "game, then Attach again.");
                    }
                    log(data_, "Existing runtime passed its execution/readiness check");
                } else {
                    auto before = bridge_.bootstrapRequests();
                    roblox_.inject(
                        assets_ / L"luau/init.bin", [&] { return stop.stop_requested(); },
                        [&] { return bridge_.bootstrapRequests() > before; });
                }
                attachQueued = false;
                status("Ready — " + roblox_.version(), true);
                for (const auto &entry : fs::directory_iterator(data_ / L"autoexec")) {
                    auto ext = lower(utf8(entry.path().extension().wstring()));
                    if (entry.is_regular_file() && (ext == ".lua" || ext == ".luau")) {
                        try {
                            compiled.push_back(compiler_.compile(readFile(entry.path(), 16 * 1024 * 1024)));
                        } catch (const std::exception &e) {
                            notify(
                                {"Auto-execute " + utf8(entry.path().filename().wstring()) + ": " + e.what(),
                                 true});
                        }
                    }
                }
            } catch (const GameNotReady &e) {
                if (std::chrono::steady_clock::now() - attachStarted < std::chrono::seconds(30)) {
                    status(std::string(e.what()) + " — retrying");
                } else {
                    attachQueued = false;
                    roblox_.detach();
                    notify({std::string(e.what()) + ". Roblox did not become ready within "
                                                    "30 seconds. See executor.log.",
                            true});
                }
            } catch (const std::exception &e) {
                attachQueued = false;
                roblox_.detach();
                notify({e.what(), true});
            }
        }
        if (fetchInFlight && !bridge_.waitingForFetch()) {
            fetchInFlight = false;
            status("Executed", true);
        }
        if (fetchInFlight && std::chrono::steady_clock::now() - fetchStarted > std::chrono::seconds(15)) {
            bridge_.cancelExecution();
            fetchInFlight = false;
            compiled.clear();
            notify({"The runtime did not fetch the queued script. Attach again before retrying.", true});
        }
        if (!compiled.empty() && !fetchInFlight) {
            try {
                if (!roblox_.ready())
                    throw Error("Roblox session ended before execution");
                if (bridge_.publish(std::move(compiled.front()))) {
                    compiled.pop_front();
                    roblox_.signalExecution();
                    fetchInFlight = true;
                    fetchStarted = std::chrono::steady_clock::now();
                }
            } catch (const std::exception &e) {
                compiled.clear();
                bridge_.cancelExecution();
                notify({e.what(), true});
            }
        }
        if (roblox_.attached()) {
            if (!roblox_.ready() && !attachQueued) {
                status("Session changed — attach to continue");
                bridge_.cancelExecution();
                fetchInFlight = false;
                compiled.clear();
            }
        } else if (!attachQueued) {
            status(Roblox::available() ? "Roblox is open — attach to continue"
                                       : "Idle — open Roblox to attach");
        }
    }
    bridge_.stop();
    roblox_.detach();
    notify({"Stopped", false, true});
}
LRESULT App::message(UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_GETMINMAXINFO: {
        auto info = reinterpret_cast<MINMAXINFO *>(lParam);
        info->ptMinTrackSize = {scale(860), scale(500)};
        return 0;
    }
    case WM_SIZE:
        layout();
        return 0;
    case WM_DPICHANGED: {
        auto r = reinterpret_cast<RECT *>(lParam);
        SetWindowPos(window_, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top,
                     SWP_NOZORDER | SWP_NOACTIVATE);
        layout();
        return 0;
    }
    case WM_ERASEBKGND: {
        RECT r{};
        GetClientRect(window_, &r);
        FillRect(reinterpret_cast<HDC>(wParam), &r,
                 background_ ? background_ : static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)));
        return 1;
    }
    case WM_CTLCOLORSTATIC:
    case WM_CTLCOLOREDIT: {
        auto dc = reinterpret_cast<HDC>(wParam);
        SetTextColor(dc, RGB(185, 185, 185));
        SetBkColor(dc, RGB(19, 19, 19));
        return reinterpret_cast<LRESULT>(background_);
    }
    case WM_DRAWITEM: {
        auto item = reinterpret_cast<DRAWITEMSTRUCT *>(lParam);
        if (item->CtlType != ODT_BUTTON)
            break;
        bool execute = item->CtlID == Execute;
        HBRUSH brush = CreateSolidBrush(execute ? RGB(43, 76, 52) : RGB(32, 32, 32));
        FillRect(item->hDC, &item->rcItem, brush);
        DeleteObject(brush);
        SetBkMode(item->hDC, TRANSPARENT);
        SetTextColor(item->hDC, item->itemState & ODS_DISABLED ? RGB(80, 80, 80)
                                : execute                      ? RGB(190, 240, 203)
                                                               : RGB(220, 220, 220));
        SelectObject(item->hDC, uiFont_);
        auto text = windowText(item->hwndItem);
        DrawTextW(item->hDC, text.c_str(), -1, &item->rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        if (item->itemState & ODS_FOCUS)
            DrawFocusRect(item->hDC, &item->rcItem);
        return TRUE;
    }
    case WM_COMMAND: {
        UINT id = LOWORD(wParam);
        auto control = reinterpret_cast<HWND>(lParam);
        if (HIWORD(wParam) == EN_CHANGE) {
            if (control == search_)
                refreshTree();
            else if (!formatting_)
                highlightPending_ = true;
            InvalidateRect(gutter_, nullptr, TRUE);
            return 0;
        }
        if (HIWORD(wParam) == EN_VSCROLL) {
            InvalidateRect(gutter_, nullptr, TRUE);
            return 0;
        }
        if (closing_)
            return 0;
        switch (id) {
        case BrowserMode:
            if (HIWORD(wParam) == CBN_SELCHANGE) {
                gameMode_ = SendMessageW(browserMode_, CB_GETCURSEL, 0, 0) == 1;
                setText(search_, "");
                SendMessageW(
                    search_, EM_SETCUEBANNER, TRUE,
                    reinterpret_cast<LPARAM>(gameMode_ ? L"Search script path or class" : L"Search files"));
                refreshTree();
                layout();
                if (gameMode_ && gameScripts_.empty())
                    requestScan();
            }
            break;
        case ScanGame:
            requestScan();
            break;
        case DecompileSelected:
            requestDecompile(false);
            break;
        case DecompileAll:
            requestDecompile(true);
            break;
        case CancelDecompile:
            cancelDecompile_ = true;
            setText(status_, "Cancelling — waiting for the current request to finish...");
            break;
        case New:
            newTab();
            break;
        case CloseTab:
            closeTab();
            break;
        case Attach:
            enqueue({Command::Action::Attach});
            break;
        case Execute:
            if (!tabs_.empty())
                enqueue({Command::Action::Execute, utf8(windowText(tabs_[active_].editor))});
            break;
        case Import:
            importFile();
            break;
        case Export:
            exportFile();
            break;
        case Save:
            save();
            break;
        case Refresh:
            if (gameMode_)
                requestScan();
            else
                refreshTree();
            break;
        case MoveLeft:
            moveTab(-1);
            break;
        case MoveRight:
            moveTab(1);
            break;
        case Clear:
            if (MessageBoxW(window_, L"Clear every tab? Export important scripts first.", L"Clear tabs",
                            MB_YESNO | MB_ICONQUESTION) == IDYES) {
                for (auto &tab : tabs_)
                    DestroyWindow(tab.editor);
                tabs_.clear();
                active_ = 0;
                nextTab_ = 0;
                newTab();
                save();
            }
            break;
        case Topmost:
            topmost_ = !topmost_;
            SetWindowPos(window_, topmost_ ? HWND_TOPMOST : HWND_NOTOPMOST, 0, 0, 0, 0,
                         SWP_NOMOVE | SWP_NOSIZE);
            CheckMenuItem(GetMenu(window_), Topmost, MF_BYCOMMAND | (topmost_ ? MF_CHECKED : MF_UNCHECKED));
            break;
        case Sidebar:
            sidebar_ = !sidebar_;
            CheckMenuItem(GetMenu(window_), Sidebar, MF_BYCOMMAND | (sidebar_ ? MF_CHECKED : MF_UNCHECKED));
            layout();
            break;
        case OpenData:
            ShellExecuteW(window_, L"open", data_.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
            break;
        case Quit:
            PostMessageW(window_, WM_CLOSE, 0, 0);
            break;
        }
        return 0;
    }
    case WM_NOTIFY: {
        auto hdr = reinterpret_cast<NMHDR *>(lParam);
        if (hdr->hwndFrom == tabBar_ && hdr->code == TCN_SELCHANGE) {
            int selected = TabCtrl_GetCurSel(tabBar_);
            if (selected >= 0)
                selectTab(static_cast<size_t>(selected));
        } else if (hdr->hwndFrom == tree_ && hdr->code == NM_DBLCLK) {
            if (gameMode_) {
                requestDecompile(false);
                return 0;
            }
            TVITEMW item{};
            item.mask = TVIF_PARAM;
            item.hItem = TreeView_GetSelection(tree_);
            if (TreeView_GetItem(tree_, &item) && item.lParam > 0 &&
                static_cast<size_t>(item.lParam) <= treePaths_.size())
                openFile(treePaths_[static_cast<size_t>(item.lParam) - 1]);
        }
        return 0;
    }
    case WM_TIMER:
        if (wParam == 1)
            save(false);
        else if (wParam == 2 && highlightPending_)
            highlight();
        else if (wParam == 3) {
            KillTimer(window_, 3);
            PostMessageW(window_, WM_CLOSE, 0, 0);
        } else if (wParam == 4) {
            KillTimer(window_, 4);
            if (!recovery_.empty())
                showError(recovery_);
        }
        return 0;
    case workerMessage: {
        std::unique_ptr<Event> event(reinterpret_cast<Event *>(lParam));
        if (event->stopped) {
            DestroyWindow(window_);
            return 0;
        }
        if (event->jobFinished) {
            decompileBusy_ = false;
            updateDecompilerControls();
        }
        if (event->scan && !closing_) {
            gameScripts_ = std::move(event->scan->scripts);
            if (gameMode_)
                refreshTree();
        }
        if (!event->tabName.empty() && !closing_)
            newTab(wide(event->tabName), std::move(event->source));
        if (!event->folder.empty() && !closing_) {
            log(data_, "Decompiled script export: " + utf8(event->folder.wstring()));
            ShellExecuteW(window_, L"open", event->folder.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        }
        setText(status_, event->text);
        log(data_, event->text);
        if (event->error && !closing_)
            showError(event->text);
        return 0;
    }
    case WM_CLOSE:
        if (closing_)
            return 0;
        if (!save())
            return 0;
        if (!smoke_ && MessageBoxW(window_, L"Close Funny Executor? Your tabs have been saved.", L"Exit",
                                   MB_YESNO | MB_ICONQUESTION) != IDYES)
            return 0;
        closing_ = true;
        cancelDecompile_ = true;
        updateDecompilerControls();
        KillTimer(window_, 1);
        KillTimer(window_, 2);
        EnableWindow(attachButton_, FALSE);
        EnableWindow(executeButton_, FALSE);
        setText(status_, "Closing — finishing background work...");
        if (worker_.joinable()) {
            worker_.request_stop();
            commandsCv_.notify_all();
        } else
            DestroyWindow(window_);
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(window_, message, wParam, lParam);
}
LRESULT CALLBACK App::windowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    App *self = reinterpret_cast<App *>(GetWindowLongPtrW(window, GWLP_USERDATA));
    if (message == WM_NCCREATE) {
        self = static_cast<App *>(reinterpret_cast<CREATESTRUCTW *>(lParam)->lpCreateParams);
        self->window_ = window;
        SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(self));
    }
    if (self) {
        try {
            return self->message(message, wParam, lParam);
        } catch (const std::exception &e) {
            self->showError(e.what());
            return 0;
        }
    }
    return DefWindowProcW(window, message, wParam, lParam);
}
LRESULT CALLBACK App::gutterProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    auto self = reinterpret_cast<App *>(GetWindowLongPtrW(window, GWLP_USERDATA));
    if (message == WM_PAINT && self) {
        PAINTSTRUCT paint{};
        auto dc = BeginPaint(window, &paint);
        self->drawGutter(dc);
        EndPaint(window, &paint);
        return 0;
    }
    return DefWindowProcW(window, message, wParam, lParam);
}
int App::run(int show) {
    ShowWindow(window_, show);
    UpdateWindow(window_);
    if (!recovery_.empty())
        SetTimer(window_, 4, 150, nullptr);
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        if (message.message == WM_KEYDOWN) {
            bool ctrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0,
                 shift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
            UINT command = 0;
            if (ctrl) {
                switch (message.wParam) {
                case 'N':
                    command = New;
                    break;
                case 'O':
                    command = Import;
                    break;
                case 'S':
                    command = shift ? Export : Save;
                    break;
                case 'W':
                    command = CloseTab;
                    break;
                case 'I':
                    command = Attach;
                    break;
                case VK_RETURN:
                    command = Execute;
                    break;
                case VK_TAB:
                    if (!tabs_.empty())
                        selectTab((active_ + (shift ? tabs_.size() - 1 : 1)) % tabs_.size());
                    continue;
                }
            } else if (message.wParam == VK_F5)
                command = Refresh;
            if (command) {
                SendMessageW(window_, WM_COMMAND, command, 0);
                continue;
            }
            if (!ctrl && message.wParam == VK_TAB && !tabs_.empty() &&
                message.hwnd == tabs_[active_].editor) {
                SendMessageW(message.hwnd, EM_REPLACESEL, TRUE, reinterpret_cast<LPARAM>(L"    "));
                continue;
            }
        }
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    if (worker_.joinable())
        worker_.join();
    return static_cast<int>(message.wParam);
}
} // namespace fe
