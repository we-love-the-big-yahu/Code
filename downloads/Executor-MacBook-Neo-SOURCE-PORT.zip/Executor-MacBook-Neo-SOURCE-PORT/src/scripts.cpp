#include "scripts.hpp"
#include <nlohmann/json.hpp>
#include <set>
#include <chrono>
#include <thread>
namespace fe {
uint64_t findChildByClass(uint64_t parent, std::string_view className, const ScriptReader &reader) {
    if (!parent || className.empty())
        return 0;
    for (auto child : reader.children(parent)) {
        if (!child)
            continue;
        try {
            if (reader.className(child) == className)
                return child;
        } catch (const std::exception &) {
            // A service can disappear while Roblox changes sessions.
        }
    }
    return 0;
}
ScriptScan scanClientScripts(uint64_t root, DWORD pid, const ScriptReader &reader,
                             std::function<bool()> cancelled, size_t nodeLimit, size_t scriptLimit) {
    if (!root || !pid)
        throw Error("Attach to a game before scanning scripts");
    ScriptScan result;
    struct Node {
        uint64_t address;
        std::vector<std::string> path;
    };
    std::vector<Node> pending{{root, {}}};
    std::set<uint64_t> seen;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(15);
    while (!pending.empty()) {
        if (cancelled && cancelled())
            throw Error("Script scan cancelled");
        if (result.visited >= nodeLimit || result.scripts.size() >= scriptLimit ||
            std::chrono::steady_clock::now() >= deadline) {
            result.limited = true;
            break;
        }
        auto node = std::move(pending.back());
        pending.pop_back();
        if (!seen.insert(node.address).second)
            continue;
        ++result.visited;
        if (node.path.size() >= 128) {
            result.limited = true;
            continue;
        }
        try {
            auto name = reader.name(node.address);
            auto type = reader.className(node.address);
            if (node.address != root)
                node.path.push_back(name);
            if (type == "LocalScript" || type == "ModuleScript")
                result.scripts.push_back({node.address, root, pid, name, type, node.path});
            auto children = reader.children(node.address);
            if (children.size() > nodeLimit || pending.size() + children.size() > nodeLimit) {
                result.limited = true;
                continue;
            }
            if (node.address == root) {
                // Find game code before spending the scan budget on large scenes or Roblox UI.
                std::vector<std::pair<int, uint64_t>> ordered;
                for (auto child : children) {
                    if (!child)
                        continue;
                    int rank = 6;
                    try {
                        auto service = reader.name(child);
                        // These contain Roblox's UI/framework code and the executor runtime,
                        // rather than the game's replicated scripts.
                        if (service == "CoreGui" || service == "CorePackages")
                            continue;
                        const std::vector<std::string> priorities{
                            "ReplicatedStorage", "ReplicatedFirst", "Players", "StarterPlayer",
                            "StarterGui",        "Workspace",       "CoreGui", "CorePackages"};
                        auto i = std::find(priorities.begin(), priorities.end(), service);
                        if (i != priorities.end())
                            rank = static_cast<int>(i - priorities.begin());
                    } catch (const std::exception &) {
                    }
                    ordered.emplace_back(rank, child);
                }
                std::stable_sort(ordered.begin(), ordered.end(),
                                 [](auto a, auto b) { return a.first < b.first; });
                for (auto i = ordered.rbegin(); i != ordered.rend(); ++i)
                    pending.push_back({i->second, node.path});
            } else {
                for (auto child : children)
                    if (child)
                        pending.push_back({child, node.path});
            }
        } catch (const std::exception &) {
            ++result.skipped;
        }
    }
    std::sort(result.scripts.begin(), result.scripts.end(), [](const auto &a, const auto &b) {
        return a.path == b.path ? a.address < b.address : a.path < b.path;
    });
    return result;
}
std::string scriptLocation(const ClientScript &script) {
    std::string result = "game";
    for (const auto &name : script.path)
        result += "." + name;
    return result;
}
fs::path scriptExportName(const ClientScript &script, size_t index) {
    auto name = wide(script.name);
    if (name.size() > 60)
        name.resize(60);
    for (auto &c : name)
        if (c < 32 || std::wstring_view(L"\\/:*?\"<>|").find(c) != std::wstring_view::npos)
            c = L'_';
    while (!name.empty() && (name.back() == L'.' || name.back() == L' '))
        name.pop_back();
    if (name.empty())
        name = L"script";
    return std::to_wstring(index + 1) + L"-" + name + L".luau";
}
std::string decompilerSource(std::string response) {
    auto first = response.find_first_not_of(" \t\r\n");
    if (first == std::string::npos || response.size() > 8 * 1024 * 1024 ||
        response.find('\0') != response.npos)
        throw Error("Decompiler returned empty, invalid or oversized source");
    auto prefix = lower(response.substr(first, 80));
    if (prefix.starts_with("<!doctype") || prefix.starts_with("<html") || prefix == "fail" ||
        prefix.starts_with("fail\n") || prefix.starts_with("fail\r") || prefix == "nil" ||
        prefix.starts_with("nil\n") || prefix.starts_with("nil\r") || prefix.starts_with("error:"))
        throw Error("Decompiler service did not return source: " + response.substr(first, 180));
    if (response[first] == '{' || response[first] == '[' || response[first] == '"') {
        auto value = nlohmann::json::parse(response, nullptr, false);
        if (value.is_object()) {
            if (value.contains("error") && !value["error"].is_null())
                throw Error("Decompiler service error: " + value["error"].dump().substr(0, 180));
            for (auto key : {"source", "script", "result"})
                if (value.contains(key) && value[key].is_string())
                    return decompilerSource(value[key].get<std::string>());
        } else if (value.is_string())
            return decompilerSource(value.get<std::string>());
        if (!value.is_discarded())
            throw Error("Decompiler returned an unsupported JSON response");
    }
    return response;
}
Decompiler::Decompiler(fs::path cache, std::function<std::string(std::string_view)> transport)
    : cache_(std::move(cache)), transport_(std::move(transport)) {
    if (!transport_)
        transport_ = [](std::string_view bytes) {
            return httpRequest(L"https://api.lua.expert/decompile", "POST",
                               nlohmann::json{{"script", base64Encode(bytes)}}.dump(),
                               L"Content-Type: application/json\r\n", 8 * 1024 * 1024);
        };
}
std::string Decompiler::decompile(std::string_view bytecode, std::function<bool()> cancelled) {
    if (bytecode.empty() || bytecode.size() > 16 * 1024 * 1024)
        throw Error("No readable client bytecode, or bytecode exceeds 16 MiB");
    if (cancelled && cancelled())
        throw Error("Decompilation cancelled");
    auto path = cache_ / (wide(digest(bytecode)) + L".luau");
    try {
        if (fs::exists(path))
            return decompilerSource(readFile(path, 8 * 1024 * 1024));
    } catch (const std::exception &) {
    }
    auto source = decompilerSource(transport_(bytecode));
    if (cancelled && cancelled())
        throw Error("Decompilation cancelled");
    // Cache failure must not discard a successful result.
    try {
        fs::create_directories(cache_);
        atomicWrite(path, source);
    } catch (const std::exception &) {
    }
    return source;
}
ScriptExport exportClientScripts(const std::vector<ClientScript> &scripts, const fs::path &folder,
                                 Decompiler &decompiler,
                                 std::function<std::string(const ClientScript &)> readBytecode,
                                 std::function<bool(const ClientScript &)> sameSession,
                                 std::function<bool()> cancelled,
                                 std::function<void(size_t, const ClientScript &)> progress) {
    fs::create_directories(folder);
    nlohmann::json report{{"scope", "Client-visible LocalScripts and ModuleScripts; not a Studio project"},
                          {"service", "https://api.lua.expert/decompile"},
                          {"requested", scripts.size()},
                          {"complete", false},
                          {"scripts", nlohmann::json::array()}};
    auto writeReport = [&] { atomicWrite(folder / L"manifest.json", report.dump(2)); };
    writeReport();
    size_t success = 0, failed = 0, bytesWritten = 0, serviceFailures = 0;
    std::string reason;
    for (size_t i = 0; i < scripts.size(); ++i) {
        if (cancelled()) {
            reason = "Cancelled";
            break;
        }
        const auto &script = scripts[i];
        if (!sameSession(script)) {
            reason = "Game session changed";
            break;
        }
        if (progress)
            progress(i, script);
        nlohmann::json entry{{"path", script.path}, {"class", script.className}};
        std::string bytecode;
        try {
            bytecode = readBytecode(script);
        } catch (const std::exception &e) {
            entry["error"] = e.what();
            ++failed;
            report["scripts"].push_back(entry);
            writeReport();
            continue;
        }
        std::string source;
        try {
            source = decompiler.decompile(bytecode, cancelled);
            serviceFailures = 0;
        } catch (const std::exception &e) {
            entry["error"] = e.what();
            ++failed;
            ++serviceFailures;
            report["scripts"].push_back(entry);
            writeReport();
            if (cancelled()) {
                reason = "Cancelled";
                break;
            }
            if (serviceFailures >= 3) {
                reason = "Decompiler service failed three consecutive requests";
                break;
            }
            continue;
        }
        if (cancelled() || !sameSession(script)) {
            reason = cancelled() ? "Cancelled" : "Game session changed";
            break;
        }
        source = "-- Decompiled client script. Results may need correction.\n-- Path: " +
                 nlohmann::json(script.path).dump() + "\n\n" + source;
        if (bytesWritten + source.size() > 256 * 1024 * 1024) {
            reason = "Export reached its 256 MiB limit";
            break;
        }
        auto filename = scriptExportName(script, i);
        atomicWrite(folder / filename, source);
        bytesWritten += source.size();
        ++success;
        entry["file"] = utf8(filename.wstring());
        report["scripts"].push_back(entry);
        writeReport();
        // Keep batch requests modest and allow cancellation between scripts.
        for (int tick = 0; tick < 5 && !cancelled(); ++tick)
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
    }
    report["complete"] = reason.empty();
    report["saved"] = success;
    report["failed"] = failed;
    report["stopReason"] = reason;
    writeReport();
    return {success, failed, reason};
}
} // namespace fe
