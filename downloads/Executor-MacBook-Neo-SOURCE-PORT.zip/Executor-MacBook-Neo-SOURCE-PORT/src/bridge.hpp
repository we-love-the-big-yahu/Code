#pragma once
#include "util.hpp"
#include "compiler.hpp"
#include "process.hpp"
#include <atomic>
#include <thread>
#include <mutex>
#include <deque>
#include <map>
#include <set>
#include <condition_variable>
#include <memory>
#include <nlohmann/json.hpp>
namespace fe {
class Bridge {
    struct WebSocket {
        std::mutex mutex;
        std::mutex joinMutex;
        std::atomic<bool> closed = false;
        std::string status = "connecting";
        HINTERNET socket = nullptr;
        std::deque<std::string> pending;
        std::deque<nlohmann::json> events;
        std::jthread worker;
    };
    fs::path data_, assets_;
    Compiler &compiler_;
    Roblox &roblox_;
    SOCKET listener_ = INVALID_SOCKET;
    uint16_t port_ = 9475;
    std::atomic<bool> running_ = false;
    std::jthread acceptThread_;
    std::vector<std::jthread> workers_;
    std::mutex connectionMutex_;
    std::condition_variable connectionCv_;
    std::deque<SOCKET> pendingConnections_;
    std::set<SOCKET> activeConnections_;
    std::mutex sourceMutex_;
    std::string source_;
    bool waiting_ = false;
    std::atomic<uint64_t> bootstrapRequests_ = 0;
    std::mutex wsMutex_;
    std::map<int, std::shared_ptr<WebSocket>> sockets_;
    int nextSocket_ = 0;
    std::mutex assetsMutex_;
    std::vector<fs::path> customAssets_;
    std::mutex cacheMutex_;
    std::set<uint64_t> notifiedSessions_;
    void acceptLoop(std::stop_token stop);
    void workerLoop(std::stop_token stop);
    void handleConnection(SOCKET socket);
    bool trustedPeer(SOCKET socket);
    void websocketWorker(const std::shared_ptr<WebSocket> &entry, std::string url, std::stop_token stop);
    int websocketConnect(std::string url);
    std::string websocketPoll(int id);
    void cleanupAssets();

  public:
    Bridge(fs::path data, fs::path assets, Compiler &compiler, Roblox &roblox, uint16_t port = 9475);
    ~Bridge();
    void start();
    void stop();
    uint16_t port() const {
        return port_;
    }
    bool publish(std::string bytes);
    bool waitingForFetch();
    void cancelExecution();
    uint64_t bootstrapRequests() const {
        return bootstrapRequests_.load();
    }
    std::string dispatch(std::string_view method, const std::vector<std::string> &args);
};
} // namespace fe
