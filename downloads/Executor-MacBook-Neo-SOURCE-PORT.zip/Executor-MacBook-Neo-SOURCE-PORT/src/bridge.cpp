#include "bridge.hpp"
#include <iphlpapi.h>
#include <shlobj.h>
#include <charconv>
#include <sstream>
#include <fstream>
#include <chrono>
namespace fe {
using json = nlohmann::json;
namespace {
constexpr size_t maxBody = 24 * 1024 * 1024;
int integer(std::string_view value) {
    int n = 0;
    auto result = std::from_chars(value.data(), value.data() + value.size(), n);
    if (result.ec != std::errc() || result.ptr != value.data() + value.size())
        throw Error("Invalid integer argument");
    return n;
}
void sendAll(SOCKET socket, std::string_view bytes) {
    size_t sent = 0;
    while (sent < bytes.size()) {
        int n = send(socket, bytes.data() + sent,
                     static_cast<int>(std::min<size_t>(bytes.size() - sent, 65536)), 0);
        if (n <= 0)
            throw Error("Bridge client disconnected");
        sent += n;
    }
}
void reply(SOCKET socket, int status, std::string_view body) {
    std::string header = "HTTP/1.1 " + std::to_string(status) +
                         (status == 200   ? " OK"
                          : status == 403 ? " Forbidden"
                                          : " Error") +
                         "\r\nContent-Type: text/plain\r\nContent-Length: " + std::to_string(body.size()) +
                         "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
    sendAll(socket, header);
    sendAll(socket, body);
}
std::string trim(std::string value) {
    while (!value.empty() && (value.front() == ' ' || value.front() == '\t'))
        value.erase(value.begin());
    while (!value.empty() && (value.back() == '\r' || value.back() == ' ' || value.back() == '\t'))
        value.pop_back();
    return value;
}
std::wstring fileDialog(bool save, bool multi, const json &options) {
    std::vector<wchar_t> buffer(32768, 0);
    if (options.contains("defaultPath") && options["defaultPath"].is_string()) {
        auto value = wide(options["defaultPath"].get<std::string>());
        if (value.size() < buffer.size())
            std::copy(value.begin(), value.end(), buffer.begin());
    }
    std::wstring filters = L"All files (*.*)";
    filters.push_back(0);
    filters += L"*.*";
    filters.push_back(0);
    filters.push_back(0);
    OPENFILENAMEW dialog{};
    dialog.lStructSize = sizeof(dialog);
    dialog.lpstrFilter = filters.c_str();
    dialog.lpstrFile = buffer.data();
    dialog.nMaxFile = static_cast<DWORD>(buffer.size());
    dialog.Flags = OFN_EXPLORER | OFN_NOCHANGEDIR | (save ? OFN_OVERWRITEPROMPT : OFN_FILEMUSTEXIST) |
                   (multi ? OFN_ALLOWMULTISELECT : 0);
    auto title = wide(options.value("title", save ? std::string("Save file") : std::string("Open file")));
    dialog.lpstrTitle = title.c_str();
    if (!(save ? GetSaveFileNameW(&dialog) : GetOpenFileNameW(&dialog)))
        return {};
    std::wstring first(buffer.data()), result;
    auto next = buffer.data() + first.size() + 1;
    if (!multi || !*next)
        return first;
    for (auto p = next; *p; p += wcslen(p) + 1) {
        if (!result.empty())
            result += L"\n";
        result += (fs::path(first) / p).wstring();
    }
    return result;
}
std::wstring folderDialog(const json &options) {
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    if (FAILED(init))
        throw Error("Folder dialog COM initialization failed");
    std::wstring result;
    IFileDialog *dialog = nullptr;
    if (SUCCEEDED(
            CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&dialog)))) {
        DWORD flags = 0;
        dialog->GetOptions(&flags);
        dialog->SetOptions(flags | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        auto title = wide(options.value("title", std::string("Select folder")));
        dialog->SetTitle(title.c_str());
        if (SUCCEEDED(dialog->Show(nullptr))) {
            IShellItem *item = nullptr;
            if (SUCCEEDED(dialog->GetResult(&item))) {
                PWSTR path = nullptr;
                if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path))) {
                    result = path;
                    CoTaskMemFree(path);
                }
                item->Release();
            }
        }
        dialog->Release();
    }
    CoUninitialize();
    return result;
}
WORD virtualKey(std::string key) {
    key = lower(key);
    if (key.size() == 1) {
        SHORT code = VkKeyScanA(key[0]);
        if (code != -1)
            return LOBYTE(code);
    }
    static const std::map<std::string, int> keys = {
        {"esc", VK_ESCAPE},   {"escape", VK_ESCAPE},  {"enter", VK_RETURN},  {"space", VK_SPACE},
        {"tab", VK_TAB},      {"backspace", VK_BACK}, {"delete", VK_DELETE}, {"shift", VK_SHIFT},
        {"ctrl", VK_CONTROL}, {"alt", VK_MENU},       {"up", VK_UP},         {"down", VK_DOWN},
        {"left", VK_LEFT},    {"right", VK_RIGHT},    {"home", VK_HOME},     {"end", VK_END},
        {"pageup", VK_PRIOR}, {"pagedown", VK_NEXT}};
    if (auto i = keys.find(key); i != keys.end())
        return static_cast<WORD>(i->second);
    if (key.size() > 1 && key[0] == 'f') {
        int n = integer(key.substr(1));
        if (n >= 1 && n <= 24)
            return static_cast<WORD>(VK_F1 + n - 1);
    }
    throw Error("Unsupported key name");
}
void keyboard(WORD key, bool release) {
    INPUT i{};
    i.type = INPUT_KEYBOARD;
    i.ki.wVk = key;
    i.ki.dwFlags = release ? KEYEVENTF_KEYUP : 0;
    if (SendInput(1, &i, sizeof(i)) != 1)
        throw Error("Input failed");
}
void mouse(DWORD flags, LONG x = 0, LONG y = 0, DWORD data = 0) {
    INPUT i{};
    i.type = INPUT_MOUSE;
    i.mi.dwFlags = flags;
    i.mi.dx = x;
    i.mi.dy = y;
    i.mi.mouseData = data;
    if (SendInput(1, &i, sizeof(i)) != 1)
        throw Error("Mouse input failed");
}
} // namespace
Bridge::Bridge(fs::path data, fs::path assets, Compiler &compiler, Roblox &roblox, uint16_t port)
    : data_(std::move(data)), assets_(std::move(assets)), compiler_(compiler), roblox_(roblox), port_(port) {
    fs::create_directories(data_ / L"workspace");
}
Bridge::~Bridge() {
    stop();
    cleanupAssets();
}
void Bridge::start() {
    if (running_)
        return;
    WSADATA data{};
    if (WSAStartup(MAKEWORD(2, 2), &data))
        throw Error("Winsock initialization failed");
    listener_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listener_ == INVALID_SOCKET) {
        WSACleanup();
        throw Error("Cannot create bridge socket");
    }
    BOOL exclusive = TRUE;
    setsockopt(listener_, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, reinterpret_cast<const char *>(&exclusive),
               sizeof(exclusive));
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    address.sin_port = htons(port_);
    if (bind(listener_, reinterpret_cast<sockaddr *>(&address), sizeof(address)) || listen(listener_, 16)) {
        closesocket(listener_);
        listener_ = INVALID_SOCKET;
        WSACleanup();
        throw Error("Port 9475 is already in use. Close the Python executor before attaching.");
    }
    int addressLength = sizeof(address);
    if (getsockname(listener_, reinterpret_cast<sockaddr *>(&address), &addressLength) == 0)
        port_ = ntohs(address.sin_port);
    running_ = true;
    for (int i = 0; i < 6; ++i)
        workers_.emplace_back([this](std::stop_token stop) { workerLoop(stop); });
    acceptThread_ = std::jthread([this](std::stop_token stop) { acceptLoop(stop); });
}
void Bridge::stop() {
    if (!running_.exchange(false))
        return;
    acceptThread_.request_stop();
    if (listener_ != INVALID_SOCKET) {
        shutdown(listener_, SD_BOTH);
        closesocket(listener_);
        listener_ = INVALID_SOCKET;
    }
    connectionCv_.notify_all();
    if (acceptThread_.joinable())
        acceptThread_.join();
    {
        std::lock_guard lock(connectionMutex_);
        for (auto s : pendingConnections_)
            closesocket(s);
        pendingConnections_.clear();
        for (auto s : activeConnections_)
            shutdown(s, SD_BOTH);
    }
    for (auto &worker : workers_) {
        worker.request_stop();
        CancelSynchronousIo(worker.native_handle());
        EnumThreadWindows(
            GetThreadId(worker.native_handle()),
            [](HWND window, LPARAM) -> BOOL {
                PostMessageW(window, WM_CLOSE, 0, 0);
                return TRUE;
            },
            0);
    }
    connectionCv_.notify_all();
    workers_.clear();
    std::map<int, std::shared_ptr<WebSocket>> sockets;
    {
        std::lock_guard lock(wsMutex_);
        sockets.swap(sockets_);
    }
    for (auto &[id, entry] : sockets) {
        entry->closed = true;
        entry->worker.request_stop();
    }
    for (auto &[id, entry] : sockets) {
        std::lock_guard joinLock(entry->joinMutex);
        if (entry->worker.joinable())
            entry->worker.join();
    }
    WSACleanup();
}
void Bridge::acceptLoop(std::stop_token stop) {
    while (!stop.stop_requested() && running_) {
        SOCKET client = accept(listener_, nullptr, nullptr);
        if (client == INVALID_SOCKET)
            break;
        DWORD timeout = 3000;
        setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&timeout),
                   sizeof(timeout));
        setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, reinterpret_cast<const char *>(&timeout),
                   sizeof(timeout));
        {
            std::lock_guard lock(connectionMutex_);
            if (pendingConnections_.size() >= 32) {
                closesocket(client);
                continue;
            }
            pendingConnections_.push_back(client);
        }
        connectionCv_.notify_one();
    }
}
void Bridge::workerLoop(std::stop_token stop) {
    while (!stop.stop_requested()) {
        SOCKET client;
        {
            std::unique_lock lock(connectionMutex_);
            connectionCv_.wait(
                lock, [&] { return stop.stop_requested() || !running_ || !pendingConnections_.empty(); });
            if (stop.stop_requested() || !running_)
                return;
            client = pendingConnections_.front();
            pendingConnections_.pop_front();
            activeConnections_.insert(client);
        }
        try {
            handleConnection(client);
        } catch (const std::exception &e) {
            log(data_, e.what());
        }
        {
            std::lock_guard lock(connectionMutex_);
            activeConnections_.erase(client);
        }
        shutdown(client, SD_BOTH);
        closesocket(client);
    }
}
bool Bridge::trustedPeer(SOCKET socket) {
    return tcpClientOwnedBy(socket, roblox_.pid());
}
void Bridge::handleConnection(SOCKET socket) {
    if (!trustedPeer(socket)) {
        log(data_, "Bridge rejected a caller outside the attached Roblox process (expected PID " +
                       std::to_string(roblox_.pid()) + ")");
        reply(socket, 403, "Forbidden");
        return;
    }
    std::string bytes;
    char buffer[8192];
    size_t end = std::string::npos;
    while ((end = bytes.find("\r\n\r\n")) == std::string::npos) {
        int n = recv(socket, buffer, sizeof(buffer), 0);
        if (n <= 0)
            return;
        bytes.append(buffer, n);
        if (bytes.size() > 32768) {
            reply(socket, 400, "Headers too large");
            return;
        }
    }
    auto lines = split(std::string_view(bytes).substr(0, end), '\n');
    if (lines.empty())
        return;
    auto first = split(trim(lines[0]), ' ');
    if (first.size() != 3 || first[1] != "/" || (first[0] != "GET" && first[0] != "POST")) {
        reply(socket, 400, "Bad request");
        return;
    }
    std::map<std::string, std::string> headers;
    for (size_t i = 1; i < lines.size(); ++i) {
        auto pos = lines[i].find(':');
        if (pos == lines[i].npos)
            continue;
        auto name = lower(trim(lines[i].substr(0, pos)));
        if (headers.contains(name)) {
            reply(socket, 400, "Duplicate header");
            return;
        }
        headers[name] = trim(lines[i].substr(pos + 1));
    }
    if (headers.contains("origin") || headers.contains("transfer-encoding") || !headers.contains("host") ||
        (headers["host"] != "localhost:9475" && headers["host"] != "127.0.0.1:9475")) {
        log(data_,
            "Bridge rejected request headers: host=" + headers["host"] +
                ", origin=" + (headers.contains("origin") ? "present" : "absent") +
                ", transfer-encoding=" + (headers.contains("transfer-encoding") ? "present" : "absent"));
        reply(socket, 403, "Forbidden");
        return;
    }
    if (first[0] == "GET") {
        std::string source;
        {
            std::lock_guard lock(sourceMutex_);
            source = source_;
            waiting_ = false;
            source_.clear();
        }
        log(data_, "Runtime fetched " + std::to_string(source.size()) + " bytecode bytes");
        reply(socket, 200, source);
        return;
    }
    size_t length = 0;
    if (auto i = headers.find("content-length"); i != headers.end()) {
        auto r = std::from_chars(i->second.data(), i->second.data() + i->second.size(), length);
        if (r.ec != std::errc() || r.ptr != i->second.data() + i->second.size() || length > maxBody) {
            reply(socket, 400, "Invalid body length");
            return;
        }
    }
    auto body = bytes.substr(end + 4);
    while (body.size() < length) {
        int n =
            recv(socket, buffer, static_cast<int>(std::min<size_t>(sizeof(buffer), length - body.size())), 0);
        if (n <= 0)
            return;
        body.append(buffer, n);
    }
    body.resize(length);
    auto args = split(body, '\n');
    if (args.empty()) {
        reply(socket, 400, "Bad request");
        return;
    }
    auto method = args.front();
    args.erase(args.begin());
    std::string response;
    try {
        response = dispatch(method, args);
    } catch (const std::exception &e) {
        log(data_, method + ": " + e.what());
        response = "fail\n" + std::string(e.what());
    }
    reply(socket, 200, response);
}
bool Bridge::publish(std::string bytes) {
    std::lock_guard lock(sourceMutex_);
    if (waiting_)
        return false;
    source_ = std::move(bytes);
    waiting_ = true;
    return true;
}
bool Bridge::waitingForFetch() {
    std::lock_guard lock(sourceMutex_);
    return waiting_;
}
void Bridge::cancelExecution() {
    std::lock_guard lock(sourceMutex_);
    source_.clear();
    waiting_ = false;
}
std::string Bridge::dispatch(std::string_view method, const std::vector<std::string> &args) {
    auto arg = [&](size_t i) -> const std::string & {
        if (i >= args.size())
            throw Error("Missing method argument");
        return args[i];
    };
    if (method == "compile")
        return base64Encode(
            compiler_.compile(base64Decode(arg(0)), args.size() > 1 ? base64Decode(arg(1)) : ""));
    if (method == "getinit" || method == "getinitraw") {
        ++bootstrapRequests_;
        log(data_, "Runtime requested initializer: " + std::string(method));
        auto source = readFile(assets_ / L"luau/init.luau");
        source += "\nlocal ready = Instance.new('BoolValue')\nready.Name = 'ReadyIndicator'\nready.Value = "
                  "true\nready.Parent = folder\n";
        auto bytes = compiler_.compile(source, "FunnyExecutorInit");
        return method == "getinit" ? base64Encode(bytes) : bytes;
    }
    if (method == "client_init") {
        log(data_, "Runtime reported client initialization");
        if (!roblox_.confirm())
            return "silent";
        auto dm = roblox_.datamodel();
        std::lock_guard lock(cacheMutex_);
        return notifiedSessions_.insert(dm).second ? "notify" : "silent";
    }
    if (method == "setclipboard") {
        clipboardSet(base64Decode(arg(0)));
        return "ok";
    }
    if (method == "getclipboard")
        return clipboardGet();
    if (method == "hash")
        return digest(base64Decode(arg(1)), arg(0));
    if (method == "hmac")
        return digest(base64Decode(arg(2)), arg(0), base64Decode(arg(1)), true);
    if (method == "setfpscap") {
        int fps = integer(arg(0));
        if (fps < 0 || fps > 9999)
            return "fail";
        return roblox_.setFps(fps == 0 ? 9999 : fps) ? "ok" : "fail";
    }
    if (method == "getfpscap")
        return std::to_string(roblox_.fps());
    if (method == "getscriptbytecode" || method == "getscripthash") {
        auto bytes = roblox_.scriptBytecode(arg(0));
        if (bytes.empty())
            return "nil";
        try {
            bytes = Compiler::decrypt(bytes);
        } catch (const Error &) {
        }
        return method == "getscriptbytecode" ? base64Encode(bytes) : digest(bytes);
    }
    if (method == "decompile") {
        Decompiler decompiler(data_ / L"cache/decompiled");
        return decompiler.decompile(base64Decode(arg(0)));
    }
    if (method == "getsynsaveinstance") {
        std::lock_guard lock(cacheMutex_);
        auto path = data_ / L"cache/saveinstance.luau";
        std::string source;
        try {
            if (fs::exists(path) &&
                fs::file_time_type::clock::now() - fs::last_write_time(path) < std::chrono::hours(24 * 7))
                source = readFile(path);
        } catch (...) {
        }
        if (source.empty()) {
            try {
                source = httpRequest(
                    L"https://raw.githubusercontent.com/luau/SynSaveInstance/main/saveinstance.luau");
                atomicWrite(path, source);
            } catch (...) {
                if (fs::exists(path))
                    source = readFile(path);
                else
                    throw;
            }
        }
        return base64Encode(source);
    }
    if (method == "websocket_connect")
        return std::to_string(websocketConnect(base64Decode(arg(0))));
    if (method == "websocket_poll")
        return websocketPoll(integer(arg(0)));
    if (method == "websocket_send" || method == "websocket_close") {
        std::shared_ptr<WebSocket> entry;
        {
            std::lock_guard lock(wsMutex_);
            auto i = sockets_.find(integer(arg(0)));
            if (i == sockets_.end())
                return "fail";
            entry = i->second;
        }
        if (method == "websocket_close") {
            entry->closed = true;
            return "ok";
        }
        auto bytes = base64Decode(arg(1));
        std::lock_guard lock(entry->mutex);
        if (entry->closed)
            return "fail";
        if (entry->status == "connecting") {
            if (entry->pending.size() >= 64)
                return "fail";
            entry->pending.push_back(std::move(bytes));
            return "ok";
        }
        if (!entry->socket)
            return "fail";
        auto status = WinHttpWebSocketSend(entry->socket, WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE,
                                           bytes.data(), static_cast<DWORD>(bytes.size()));
        return status == NO_ERROR ? "ok" : "fail";
    }
    if (method == "messagebox")
        return std::to_string(
            MessageBoxW(nullptr, wide(base64Decode(arg(0))).c_str(),
                        wide(args.size() > 1 ? base64Decode(arg(1)) : "FunnyExecutor").c_str(),
                        args.size() > 2 ? static_cast<UINT>(integer(arg(2))) : MB_OK));
    if (method == "openfiledialog" || method == "openfilesdialog" || method == "savefiledialog" ||
        method == "openfolderdialog") {
        json options = json::object();
        if (!args.empty() && !args[0].empty())
            options = json::parse(base64Decode(args[0]));
        if (!options.is_object())
            throw Error("Dialog options must be an object");
        auto selected = method == "openfolderdialog"
                            ? folderDialog(options)
                            : fileDialog(method == "savefiledialog", method == "openfilesdialog", options);
        return base64Encode(utf8(selected));
    }
    if (method.starts_with("rconsole")) {
        static std::mutex consoleMutex;
        std::lock_guard lock(consoleMutex);
        if (!GetConsoleWindow())
            AllocConsole();
        auto out = GetStdHandle(STD_OUTPUT_HANDLE);
        if (method == "rconsoleinput") {
            auto input = GetStdHandle(STD_INPUT_HANDLE);
            std::wstring text;
            while (running_ && text.size() < 4095) {
                if (WaitForSingleObject(input, 100) != WAIT_OBJECT_0)
                    continue;
                INPUT_RECORD event{};
                DWORD count = 0;
                if (!ReadConsoleInputW(input, &event, 1, &count) || !count)
                    continue;
                if (event.EventType != KEY_EVENT || !event.Event.KeyEvent.bKeyDown)
                    continue;
                auto key = event.Event.KeyEvent;
                if (key.wVirtualKeyCode == VK_RETURN)
                    break;
                if (key.wVirtualKeyCode == VK_BACK) {
                    if (!text.empty())
                        text.pop_back();
                    continue;
                }
                if (key.uChar.UnicodeChar) {
                    text += key.uChar.UnicodeChar;
                    DWORD written = 0;
                    WriteConsoleW(out, &key.uChar.UnicodeChar, 1, &written, nullptr);
                }
            }
            return base64Encode(utf8(text));
        }
        if (method == "rconsolename")
            SetConsoleTitleW(wide(base64Decode(arg(0))).c_str());
        else if (method == "rconsoleshow" || method == "rconsolehide")
            ShowWindow(GetConsoleWindow(), method == "rconsoleshow" ? SW_SHOW : SW_HIDE);
        else if (method == "rconsoleclear") {
            CONSOLE_SCREEN_BUFFER_INFO info{};
            if (GetConsoleScreenBufferInfo(out, &info)) {
                DWORD n = 0;
                COORD zero{};
                FillConsoleOutputCharacterW(out, L' ', static_cast<DWORD>(info.dwSize.X) * info.dwSize.Y,
                                            zero, &n);
                SetConsoleCursorPosition(out, zero);
            }
        } else {
            WORD color = method == "rconsolewarn"   ? 14
                         : method == "rconsoleerr"  ? 12
                         : method == "rconsoleinfo" ? 10
                                                    : 7;
            SetConsoleTextAttribute(out, color);
            auto text = wide(base64Decode(arg(0))) + L"\r\n";
            DWORD n = 0;
            WriteConsoleW(out, text.data(), static_cast<DWORD>(text.size()), &n, nullptr);
        }
        return "ok";
    }
    if (method == "getmousepos") {
        POINT p{};
        GetCursorPos(&p);
        return std::to_string(p.x) + "," + std::to_string(p.y);
    }
    if (method == "iswindowactive") {
        DWORD pid = 0;
        GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        return pid && pid == roblox_.pid() ? "true" : "false";
    }
    if (method == "keyclick" || method == "keydown" || method == "keyup" || method == "keypress" ||
        method == "keyrelease") {
        auto key = virtualKey(arg(0));
        keyboard(key, method == "keyup" || method == "keyrelease");
        if (method == "keyclick")
            keyboard(key, true);
        return "ok";
    }
    if (method == "movemouse" || method == "mousemoveabs") {
        if (!SetCursorPos(integer(arg(0)), integer(arg(1))))
            return "fail";
        return "ok";
    }
    if (method == "movemouserel" || method == "mousemoverel") {
        mouse(MOUSEEVENTF_MOVE, integer(arg(0)), integer(arg(1)));
        return "ok";
    }
    if (method == "mousescroll") {
        mouse(MOUSEEVENTF_WHEEL, 0, 0, static_cast<DWORD>(integer(arg(0)) * WHEEL_DELTA));
        return "ok";
    }
    if (method.starts_with("mouse1") || method.starts_with("mouse2") || method.starts_with("middle")) {
        DWORD down = method.starts_with("mouse1")   ? MOUSEEVENTF_LEFTDOWN
                     : method.starts_with("mouse2") ? MOUSEEVENTF_RIGHTDOWN
                                                    : MOUSEEVENTF_MIDDLEDOWN;
        DWORD up = method.starts_with("mouse1")   ? MOUSEEVENTF_LEFTUP
                   : method.starts_with("mouse2") ? MOUSEEVENTF_RIGHTUP
                                                  : MOUSEEVENTF_MIDDLEUP;
        if (method.ends_with("up"))
            mouse(up);
        else {
            mouse(down);
            if (method.ends_with("click"))
                mouse(up);
        }
        return "ok";
    }
    auto root = data_ / L"workspace";
    auto path = workspacePath(root, args.empty() ? "" : arg(0));
    if (method == "writefile" || method == "appendfile") {
        if (blockedExtension(path))
            return "blocked";
        auto bytes = base64Decode(arg(1));
        if (method == "appendfile" && fs::is_regular_file(path))
            bytes = readFile(path) + bytes;
        atomicWrite(path, bytes);
        return "ok";
    }
    if (method == "readfile")
        return base64Encode(readFile(path));
    if (method == "isfile")
        return fs::is_regular_file(path) ? "true" : "false";
    if (method == "isfolder")
        return fs::is_directory(path) ? "true" : "false";
    if (method == "delfile") {
        if (!fs::is_regular_file(path))
            return "fail";
        return fs::remove(path) ? "ok" : "fail";
    }
    if (method == "delfolder") {
        if (path == fs::weakly_canonical(root) || !fs::is_directory(path))
            return "fail";
        fs::remove_all(path);
        return "ok";
    }
    if (method == "makefolder") {
        fs::create_directories(path);
        return "ok";
    }
    if (method == "listfiles") {
        if (!fs::is_directory(path))
            return "fail";
        std::vector<std::string> names;
        for (const auto &item : fs::directory_iterator(path))
            names.push_back(utf8(item.path().lexically_relative(fs::weakly_canonical(root)).wstring()));
        std::sort(names.begin(), names.end());
        std::string result;
        for (auto &name : names) {
            if (!result.empty())
                result += '\n';
            result += name;
        }
        return result;
    }
    if (method == "getcustomasset") {
        auto bytes = readFile(path);
        auto name = digest(bytes, "sha1") + utf8(path.extension().wstring());
        auto target = roblox_.contentDirectory() / wide(name);
        std::lock_guard lock(assetsMutex_);
        if (!fs::exists(target)) {
            atomicWrite(target, bytes);
            customAssets_.push_back(target);
        }
        return "rbxasset://" + name;
    }
    return "bad request";
}
int Bridge::websocketConnect(std::string url) {
    if (!url.starts_with("ws://") && !url.starts_with("wss://"))
        throw Error("Invalid WebSocket URL");
    auto entry = std::make_shared<WebSocket>();
    int id;
    {
        std::lock_guard lock(wsMutex_);
        if (sockets_.size() >= 64)
            throw Error("Too many WebSocket connections");
        id = ++nextSocket_;
        sockets_[id] = entry;
    }
    entry->worker = std::jthread(
        [this, entry, url = std::move(url)](std::stop_token stop) { websocketWorker(entry, url, stop); });
    return id;
}
void Bridge::websocketWorker(const std::shared_ptr<WebSocket> &entry, std::string url, std::stop_token stop) {
    try {
        bool secure = url.starts_with("wss://");
        url.replace(0, secure ? 6 : 5, secure ? "https://" : "http://");
        auto wideUrl = wide(url);
        URL_COMPONENTS parts{};
        parts.dwStructSize = sizeof(parts);
        parts.dwHostNameLength = parts.dwUrlPathLength = parts.dwExtraInfoLength = static_cast<DWORD>(-1);
        if (!WinHttpCrackUrl(wideUrl.c_str(), 0, 0, &parts))
            throw Error("Invalid WebSocket URL");
        auto host = std::wstring(parts.lpszHostName, parts.dwHostNameLength),
             path = std::wstring(parts.lpszUrlPath, parts.dwUrlPathLength);
        if (parts.dwExtraInfoLength)
            path.append(parts.lpszExtraInfo, parts.dwExtraInfoLength);
        if (path.empty())
            path = L"/";
        InternetHandle session(WinHttpOpen(L"FunnyExecutorNative/1.0", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                                           WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0));
        if (!session)
            throw Error("WebSocket session failed");
        WinHttpSetTimeouts(session.get(), 3000, 3000, 3000, 1000);
        InternetHandle connect(WinHttpConnect(session.get(), host.c_str(), parts.nPort, 0));
        InternetHandle request(WinHttpOpenRequest(connect.get(), L"GET", path.c_str(), nullptr,
                                                  WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                                  secure ? WINHTTP_FLAG_SECURE : 0));
        if (!request || !WinHttpSetOption(request.get(), WINHTTP_OPTION_UPGRADE_TO_WEB_SOCKET, nullptr, 0) ||
            !WinHttpSendRequest(request.get(), WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0,
                                0, 0) ||
            !WinHttpReceiveResponse(request.get(), nullptr))
            throw Error("WebSocket handshake failed");
        InternetHandle socket(WinHttpWebSocketCompleteUpgrade(request.get(), 0));
        if (!socket)
            throw Error("WebSocket upgrade failed");
        request.reset();
        DWORD timeout = 1000;
        WinHttpSetOption(socket.get(), WINHTTP_OPTION_RECEIVE_TIMEOUT, &timeout, sizeof(timeout));
        {
            std::lock_guard lock(entry->mutex);
            if (entry->closed || stop.stop_requested())
                return;
            entry->socket = socket.get();
            entry->status = "open";
            for (auto &bytes : entry->pending)
                WinHttpWebSocketSend(socket.get(), WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE, bytes.data(),
                                     static_cast<DWORD>(bytes.size()));
            entry->pending.clear();
            entry->events.push_back({{"t", "open"}});
        }
        std::string message;
        char buffer[8192];
        while (!entry->closed && !stop.stop_requested()) {
            DWORD n = 0;
            WINHTTP_WEB_SOCKET_BUFFER_TYPE type;
            auto status = WinHttpWebSocketReceive(socket.get(), buffer, sizeof(buffer), &n, &type);
            if (status == ERROR_WINHTTP_TIMEOUT)
                continue;
            if (status != NO_ERROR)
                throw Error("WebSocket receive failed");
            if (type == WINHTTP_WEB_SOCKET_CLOSE_BUFFER_TYPE)
                break;
            if (message.size() + n > 8 * 1024 * 1024)
                throw Error("WebSocket message too large");
            message.append(buffer, n);
            if (type == WINHTTP_WEB_SOCKET_UTF8_MESSAGE_BUFFER_TYPE ||
                type == WINHTTP_WEB_SOCKET_BINARY_MESSAGE_BUFFER_TYPE) {
                std::lock_guard lock(entry->mutex);
                if (entry->events.size() >= 512)
                    throw Error("WebSocket event queue full");
                entry->events.push_back({{"t", "message"}, {"d", base64Encode(message)}});
                message.clear();
            }
        }
        {
            std::lock_guard lock(entry->mutex);
            entry->socket = nullptr;
            entry->status = "closed";
            entry->closed = true;
            entry->events.push_back({{"t", "close"}, {"c", 1000}, {"r", ""}});
        }
    } catch (const std::exception &e) {
        std::lock_guard lock(entry->mutex);
        entry->socket = nullptr;
        entry->status = "closed";
        entry->closed = true;
        entry->events.push_back({{"t", "close"}, {"c", 1006}, {"r", e.what()}});
    }
}
std::string Bridge::websocketPoll(int id) {
    std::shared_ptr<WebSocket> entry;
    {
        std::lock_guard lock(wsMutex_);
        auto i = sockets_.find(id);
        if (i == sockets_.end())
            return "[]";
        entry = i->second;
    }
    json events = json::array();
    bool done = false;
    {
        std::lock_guard lock(entry->mutex);
        for (auto &event : entry->events)
            events.push_back(event);
        entry->events.clear();
        done = entry->closed;
    }
    if (done) {
        std::lock_guard joinLock(entry->joinMutex);
        if (entry->worker.joinable())
            entry->worker.join();
        std::lock_guard lock(wsMutex_);
        sockets_.erase(id);
    }
    return events.dump();
}
void Bridge::cleanupAssets() {
    std::lock_guard lock(assetsMutex_);
    for (const auto &path : customAssets_) {
        std::error_code error;
        fs::remove(path, error);
    }
    customAssets_.clear();
}
} // namespace fe
