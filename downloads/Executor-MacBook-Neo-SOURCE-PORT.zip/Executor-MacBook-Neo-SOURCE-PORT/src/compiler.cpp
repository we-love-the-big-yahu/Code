#include "compiler.hpp"
#include <zstd.h>
#include <algorithm>
namespace fe {
std::string Compiler::compile(std::string_view source, std::string_view chunkName) {
    if (source.size() > 16 * 1024 * 1024)
        throw Error("Source exceeds 16 MiB limit");
    std::lock_guard lock(mutex_);
    std::string key = std::string(source) + std::string(1, '\0') + std::string(chunkName);
    if (auto i = cache_.find(key); i != cache_.end())
        return i->second;
    if (!fs::is_regular_file(executable_))
        throw Error("Missing assets/luau/compile.exe");
    std::wstring name = chunkName.empty() ? L"chunk.luau" : wide(chunkName);
    for (auto &c : name)
        if (c < 32 || std::wstring_view(L"\\/:*?\"<>|").find(c) != std::wstring_view::npos)
            c = L'_';
    while (!name.empty() && (name.back() == L'.' || name.back() == L' '))
        name.pop_back();
    if (name.empty() || name.front() == L'-')
        name = L"chunk-" + name;
    if (name.size() > 100)
        name.resize(100);
    auto filename = lower(utf8(name));
    auto stem = filename.substr(0, filename.find('.'));
    if (stem == "con" || stem == "prn" || stem == "aux" || stem == "nul" ||
        (stem.size() == 4 && (stem.starts_with("com") || stem.starts_with("lpt")) && stem[3] >= '1' &&
         stem[3] <= '9'))
        name = L"_" + name;
    auto dir = fs::temp_directory_path() / (L"FunnyExecutorNative-" + wide(randomHex(8)));
    fs::create_directories(dir);
    try {
        auto path = workspacePath(dir, utf8(name));
        atomicWrite(path, source);
        auto out = dir / L"stdout.bin", err = dir / L"stderr.txt";
        SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
        Handle outHandle(CreateFileW(out.c_str(), GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS,
                                     FILE_ATTRIBUTE_NORMAL, nullptr));
        Handle errHandle(CreateFileW(err.c_str(), GENERIC_WRITE, FILE_SHARE_READ, &sa, CREATE_ALWAYS,
                                     FILE_ATTRIBUTE_NORMAL, nullptr));
        Handle inHandle(CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                                    OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
        if (!outHandle || !errHandle || !inHandle)
            throw Error("Cannot create compiler output files");
        std::wstring command = L"\"" + executable_.wstring() + L"\" \"" + path.wstring() + L"\" --binary";
        STARTUPINFOW startup{};
        startup.cb = sizeof(startup);
        startup.dwFlags = STARTF_USESTDHANDLES;
        startup.hStdOutput = outHandle.get();
        startup.hStdError = errHandle.get();
        startup.hStdInput = inHandle.get();
        PROCESS_INFORMATION info{};
        if (!CreateProcessW(executable_.c_str(), command.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW,
                            nullptr, dir.c_str(), &startup, &info))
            throw Error(winError("Start Luau compiler"));
        Handle process(info.hProcess), thread(info.hThread);
        DWORD wait = WaitForSingleObject(process.get(), 15000);
        if (wait != WAIT_OBJECT_0) {
            TerminateProcess(process.get(), 1);
            WaitForSingleObject(process.get(), 2000);
            throw Error("Luau compilation timed out");
        }
        DWORD code = 0;
        GetExitCodeProcess(process.get(), &code);
        outHandle.reset();
        errHandle.reset();
        inHandle.reset();
        auto diagnostic = readFile(err, 1024 * 1024);
        auto bytes = readFile(out, 32 * 1024 * 1024);
        if (code != 0 || bytes.empty() || bytes[0] == 0)
            throw Error("Luau compile error: " + diagnostic +
                        (bytes.size() > 1 && bytes[0] == 0 ? bytes.substr(1) : ""));
        std::error_code ec;
        fs::remove_all(dir, ec);
        if (cache_.size() >= 128)
            cache_.clear();
        cache_[std::move(key)] = bytes;
        return bytes;
    } catch (...) {
        std::error_code ec;
        fs::remove_all(dir, ec);
        throw;
    }
}
std::string Compiler::decrypt(std::string_view encrypted) {
    if (encrypted.size() < 8)
        throw Error("Bytecode too short");
    std::string bytes(encrypted);
    const unsigned char signature[] = {'R', 'S', 'B', '1'};
    unsigned char key[4];
    for (size_t i = 0; i < 4; ++i)
        key[i] = static_cast<unsigned char>((static_cast<unsigned char>(bytes[i]) ^ signature[i]) - i * 41);
    for (size_t i = 0; i < bytes.size(); ++i)
        bytes[i] = static_cast<char>(static_cast<unsigned char>(bytes[i]) ^
                                     static_cast<unsigned char>(key[i % 4] + i * 41));
    uint32_t size = 0;
    memcpy(&size, bytes.data() + 4, 4);
    if (bytes.substr(0, 4) != "RSB1" || size == 0 || size > 50 * 1024 * 1024)
        throw Error("Invalid encrypted bytecode");
    std::string output(size, 0);
    size_t n = ZSTD_decompress(output.data(), output.size(), bytes.data() + 8, bytes.size() - 8);
    if (ZSTD_isError(n) || n != size)
        throw Error("Bytecode decompression failed");
    return output;
}
} // namespace fe
