#pragma once
#include "util.hpp"
#include <cstdint>
namespace fe {
struct ClientScript {
    uint64_t address = 0, dataModel = 0;
    DWORD pid = 0;
    std::string name, className;
    std::vector<std::string> path;
};
struct ScriptScan {
    std::vector<ClientScript> scripts;
    size_t visited = 0, skipped = 0;
    bool limited = false;
};
struct ScriptReader {
    std::function<std::string(uint64_t)> name, className;
    std::function<std::vector<uint64_t>(uint64_t)> children;
};
uint64_t findChildByClass(uint64_t parent, std::string_view className, const ScriptReader &reader);
ScriptScan scanClientScripts(uint64_t root, DWORD pid, const ScriptReader &reader,
                             std::function<bool()> cancelled = {}, size_t nodeLimit = 250000,
                             size_t scriptLimit = 5000);
std::string scriptLocation(const ClientScript &script);
fs::path scriptExportName(const ClientScript &script, size_t index);
std::string decompilerSource(std::string response);
class Decompiler {
    fs::path cache_;
    std::function<std::string(std::string_view)> transport_;

  public:
    explicit Decompiler(fs::path cache, std::function<std::string(std::string_view)> transport = {});
    std::string decompile(std::string_view bytecode, std::function<bool()> cancelled = {});
};
struct ScriptExport {
    size_t saved = 0, failed = 0;
    std::string stopReason;
};
ScriptExport exportClientScripts(const std::vector<ClientScript> &scripts, const fs::path &folder,
                                 Decompiler &decompiler,
                                 std::function<std::string(const ClientScript &)> readBytecode,
                                 std::function<bool(const ClientScript &)> sameSession,
                                 std::function<bool()> cancelled,
                                 std::function<void(size_t, const ClientScript &)> progress = {});
} // namespace fe
