#include "app.hpp"
#include <shellapi.h>
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, LPWSTR, int show) {
    try {
        SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        int count = 0;
        auto args = CommandLineToArgvW(GetCommandLineW(), &count);
        bool smoke = false;
        for (int i = 1; i < count; ++i)
            if (std::wstring_view(args[i]) == L"--smoke-test")
                smoke = true;
        LocalFree(args);
        auto assets = fe::executableDirectory() / L"assets";
        auto data =
            smoke ? fe::fs::temp_directory_path() / (L"FunnyExecutor-Smoke-" + fe::wide(fe::randomHex(8)))
                  : fe::dataDirectory();
        int result = 0;
        {
            fe::App app(instance, assets, data, smoke);
            result = app.run(smoke ? SW_HIDE : show);
        }
        if (smoke) {
            std::error_code ec;
            fe::fs::remove_all(data, ec);
        }
        return result;
    } catch (const std::exception &e) {
        MessageBoxW(nullptr, fe::wide(e.what()).c_str(), L"Funny Executor could not start",
                    MB_OK | MB_ICONERROR);
        return 1;
    }
}
