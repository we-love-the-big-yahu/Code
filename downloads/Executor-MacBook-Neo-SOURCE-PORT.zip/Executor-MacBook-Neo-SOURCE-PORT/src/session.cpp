#include "session.hpp"
#include <nlohmann/json.hpp>
namespace fe {
using json = nlohmann::json;
LoadedSession loadSession(const fs::path &path) {
    LoadedSession result;
    if (!fs::exists(path))
        return result;
    bool parsed = false;
    try {
        auto j = json::parse(readFile(path, 16 * 1024 * 1024));
        Session s;
        s.tabs.clear();
        if (j.is_array()) {
            if (j.empty() || !j[0].is_number_integer())
                throw Error("Invalid legacy session counter");
            s.nextTab = j[0].get<int>();
            for (size_t i = 1; i < j.size(); ++i) {
                if (!j[i].is_array() || j[i].size() != 2 || !j[i][0].is_string() || !j[i][1].is_string())
                    throw Error("Invalid legacy tab");
                s.tabs.push_back({j[i][0].get<std::string>(), j[i][1].get<std::string>()});
            }
        } else {
            if (!j.is_object() || j.at("schema") != 1 || !j.at("nextTab").is_number_integer() ||
                !j.at("active").is_number_unsigned() || !j.at("tabs").is_array())
                throw Error("Invalid session schema");
            s.nextTab = j.at("nextTab").get<int>();
            s.active = j.at("active").get<size_t>();
            for (const auto &t : j.at("tabs")) {
                if (!t.at("name").is_string() || !t.at("content").is_string())
                    throw Error("Invalid tab content");
                s.tabs.push_back({t.at("name").get<std::string>(), t.at("content").get<std::string>()});
            }
        }
        if (s.nextTab < 0 || s.nextTab > 1000000 || s.tabs.size() > 256)
            throw Error("Invalid session limits");
        if (s.tabs.empty()) {
            s.tabs.push_back({"Script #" + std::to_string(++s.nextTab), ""});
            s.active = 0;
        }
        s.active = std::min(s.active, s.tabs.size() - 1);
        result.session = std::move(s);
        parsed = true;
    } catch (const std::exception &e) {
        result.recovery = "Saved tabs could not be loaded: " + std::string(e.what());
    }
    if (!parsed) {
        try {
            auto backup = path;
            backup += L".corrupt-" + wide(randomHex(8));
            fs::copy_file(path, backup, fs::copy_options::none);
            result.recovery += "\n\nThe original was preserved at:\n" + utf8(backup.wstring()) +
                               "\n\nA fresh tab has been opened.";
        } catch (const std::exception &e) {
            result.saveAllowed = false;
            result.recovery += "\n\nBackup failed. Tab saving is disabled to protect the original file.\n" +
                               std::string(e.what());
        }
    }
    return result;
}
void saveSession(const fs::path &path, const Session &session) {
    json tabs = json::array();
    for (const auto &tab : session.tabs)
        tabs.push_back({{"name", tab.name}, {"content", tab.content}});
    auto bytes =
        json{{"schema", 1}, {"nextTab", session.nextTab}, {"active", session.active}, {"tabs", tabs}}.dump(2);
    if (bytes.size() > 16 * 1024 * 1024)
        throw Error(
            "The tab session exceeds 16 MiB. Export large scripts and close unused tabs before saving.");
    atomicWrite(path, bytes);
}
} // namespace fe
