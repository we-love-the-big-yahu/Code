#pragma once
#include "util.hpp"
#include "scripts.hpp"
#include <mutex>
#include <atomic>
#include <condition_variable>
namespace fe {
struct Offsets {
    uint64_t fakeDm = 0, realDm = 0, name = 0, nameContainer = 0, classDescriptor = 0, className = 0,
             parent = 0, children = 0, childrenEnd = 0;
    uint64_t moduleBytecode = 0x128, localBytecode = 0x180, bytecodePointer = 0x18, bytecodeSize = 0x28,
             value = 0, stringLength = 0, enableLoadModule = 0;
    uint64_t fps = 0;
};
class Roblox {
    mutable std::recursive_mutex mutex_;
    Handle process_;
    DWORD pid_ = 0;
    uintptr_t base_ = 0;
    HWND window_ = nullptr;
    std::string version_;
    fs::path exe_;
    Offsets offsets_;
    fs::path data_;
    std::atomic<uint64_t> confirmedDm_ = 0;
    void loadOffsets();
    uint64_t service(uint64_t root, std::string_view className);
    std::string stringAt(uint64_t address, size_t limit = 1024);
    uint64_t classOf(uint64_t address);
    std::string bytecodeAt(uint64_t script);
    template <typename T> T read(uint64_t address) const {
        T result{};
        SIZE_T n = 0;
        if (!ReadProcessMemory(process_.get(), reinterpret_cast<LPCVOID>(address), &result, sizeof(result),
                               &n) ||
            n != sizeof(result))
            throw Error(winError("Read Roblox memory"));
        return result;
    }
    template <typename T> void write(uint64_t address, const T &value) {
        SIZE_T n = 0;
        if (!WriteProcessMemory(process_.get(), reinterpret_cast<LPVOID>(address), &value, sizeof(value),
                                &n) ||
            n != sizeof(value))
            throw Error(winError("Write Roblox memory"));
    }

  public:
    explicit Roblox(fs::path data) : data_(std::move(data)) {}
    static bool available();
    bool attached() const;
    void attach();
    void detach();
    DWORD pid() const;
    uint64_t datamodel();
    std::string name(uint64_t address);
    std::vector<uint64_t> children(uint64_t address);
    uint64_t find(uint64_t address, std::initializer_list<std::string_view> path);
    bool ready();
    bool runtimePresent();
    bool confirm();
    void inject(const fs::path &binary, std::function<bool()> stopping,
                std::function<bool()> bootstrapRequested);
    void signalExecution(bool requireReady = true);
    std::string scriptBytecode(std::string_view holder);
    ScriptScan clientScripts(std::function<bool()> cancelled);
    std::string clientBytecode(const ClientScript &script);
    bool sameSession(const ClientScript &script);
    bool setFps(int fps);
    int fps();
    fs::path contentDirectory() const;
    std::string version() const;
};
} // namespace fe
