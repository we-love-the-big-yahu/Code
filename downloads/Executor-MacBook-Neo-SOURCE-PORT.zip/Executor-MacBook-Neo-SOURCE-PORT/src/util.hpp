#pragma once
#include <winsock2.h>
#include <windows.h>
#include <winhttp.h>
#include <commdlg.h>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>
#include <stdexcept>
#include <functional>

namespace fe {
namespace fs = std::filesystem;
class Error : public std::runtime_error {
  public:
    using std::runtime_error::runtime_error;
};
class GameNotReady : public Error {
  public:
    using Error::Error;
};
class Handle {
    HANDLE h_ = nullptr;

  public:
    Handle() = default;
    explicit Handle(HANDLE h) : h_(h) {}
    ~Handle() {
        reset();
    }
    Handle(const Handle &) = delete;
    Handle &operator=(const Handle &) = delete;
    Handle(Handle &&other) noexcept : h_(other.release()) {}
    Handle &operator=(Handle &&other) noexcept {
        if (this != &other)
            reset(other.release());
        return *this;
    }
    HANDLE get() const {
        return h_;
    }
    explicit operator bool() const {
        return h_ && h_ != INVALID_HANDLE_VALUE;
    }
    HANDLE release() {
        auto h = h_;
        h_ = nullptr;
        return h;
    }
    void reset(HANDLE h = nullptr) {
        if (*this)
            CloseHandle(h_);
        h_ = h;
    }
};
class InternetHandle {
    HINTERNET h_ = nullptr;

  public:
    InternetHandle() = default;
    explicit InternetHandle(HINTERNET h) : h_(h) {}
    ~InternetHandle() {
        reset();
    }
    InternetHandle(const InternetHandle &) = delete;
    InternetHandle &operator=(const InternetHandle &) = delete;
    InternetHandle(InternetHandle &&other) noexcept : h_(other.release()) {}
    InternetHandle &operator=(InternetHandle &&other) noexcept {
        if (this != &other)
            reset(other.release());
        return *this;
    }
    HINTERNET get() const {
        return h_;
    }
    explicit operator bool() const {
        return h_ != nullptr;
    }
    HINTERNET release() {
        auto h = h_;
        h_ = nullptr;
        return h;
    }
    void reset(HINTERNET h = nullptr) {
        if (h_)
            WinHttpCloseHandle(h_);
        h_ = h;
    }
};
std::wstring wide(std::string_view text);
std::string utf8(std::wstring_view text);
std::string winError(std::string_view operation, DWORD code = GetLastError());
fs::path executableDirectory();
fs::path dataDirectory();
std::string readFile(const fs::path &path, size_t limit = 64 * 1024 * 1024);
void atomicWrite(const fs::path &path, std::string_view bytes);
std::string base64Encode(std::string_view bytes);
std::string base64Decode(std::string_view text);
std::string digest(std::string_view bytes, std::string algorithm = "sha256", std::string_view key = {},
                   bool hmac = false);
std::string randomHex(size_t byteCount = 16);
fs::path workspacePath(const fs::path &root, std::string_view relative);
bool blockedExtension(const fs::path &path);
std::string httpRequest(std::wstring url, std::string_view method = "GET", std::string_view body = {},
                        std::wstring headers = L"", size_t limit = 32 * 1024 * 1024);
std::vector<std::string> split(std::string_view text, char separator);
std::string lower(std::string text);
void clipboardSet(std::string_view text);
std::string clipboardGet();
bool tcpClientOwnedBy(SOCKET socket, DWORD pid);
void log(const fs::path &directory, std::string_view text);
} // namespace fe
