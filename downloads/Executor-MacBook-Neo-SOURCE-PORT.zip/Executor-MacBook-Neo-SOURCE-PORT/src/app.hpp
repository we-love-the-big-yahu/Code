#pragma once
#include "session.hpp"
#include "compiler.hpp"
#include "process.hpp"
#include "bridge.hpp"
#include <commctrl.h>
#include <richedit.h>
#include <thread>
#include <deque>
#include <mutex>
#include <condition_variable>
#include <optional>
namespace fe {
class App {
    struct EditorTab {
        HWND editor = nullptr;
        std::wstring name;
    };
    struct Command {
        enum class Action { Execute, Attach, Scan, Decompile, ExportAll };
        Action action = Action::Execute;
        std::string source;
        std::vector<ClientScript> scripts;
    };
    struct Event {
        std::string text;
        bool error = false;
        bool stopped = false;
        bool ready = false;
        std::optional<ScriptScan> scan;
        std::string tabName, source;
        bool jobFinished = false;
        fs::path folder;
    };
    HINSTANCE instance_;
    HWND window_ = nullptr, tabBar_ = nullptr, tree_ = nullptr, search_ = nullptr, status_ = nullptr,
         breadcrumb_ = nullptr, gutter_ = nullptr;
    HWND newButton_ = nullptr, closeButton_ = nullptr, attachButton_ = nullptr, executeButton_ = nullptr;
    HWND browserMode_ = nullptr, scanButton_ = nullptr, decompileButton_ = nullptr, allButton_ = nullptr,
         cancelButton_ = nullptr, serviceLabel_ = nullptr;
    HFONT uiFont_ = nullptr, editorFont_ = nullptr, headingFont_ = nullptr;
    HBRUSH background_ = nullptr, panel_ = nullptr;
    std::vector<EditorTab> tabs_;
    std::vector<fs::path> treePaths_;
    std::vector<ClientScript> gameScripts_;
    size_t active_ = 0;
    int nextTab_ = 1;
    bool topmost_ = true, sidebar_ = true, formatting_ = false, highlightPending_ = false, closing_ = false,
         saveAllowed_ = true, smoke_ = false;
    bool gameMode_ = false, decompileBusy_ = false;
    std::atomic<bool> cancelDecompile_ = false;
    fs::path data_, assets_;
    std::string recovery_;
    Compiler compiler_;
    Roblox roblox_;
    Bridge bridge_;
    std::jthread worker_;
    std::mutex commandsMutex_;
    std::condition_variable commandsCv_;
    std::deque<Command> commands_;
    int scale(int value) const;
    void createUi();
    void layout();
    void newTab(std::wstring name = {}, std::string content = "print(\"Hello, World!\")");
    void selectTab(size_t index);
    void closeTab();
    void moveTab(int direction);
    void updateTabLabels();
    bool save(bool showError = true);
    void refreshTree();
    void requestScan();
    void requestDecompile(bool all);
    void updateDecompilerControls();
    void decompileCommand(const Command &command, std::stop_token stop);
    void openFile(const fs::path &path);
    void importFile();
    void exportFile();
    void highlight();
    bool enqueue(Command command);
    void workerLoop(std::stop_token stop);
    void notify(Event event);
    void showError(std::string_view message);
    LRESULT message(UINT message, WPARAM wParam, LPARAM lParam);
    void drawGutter(HDC dc);
    void smokeChecks();
    static LRESULT CALLBACK windowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam);
    static LRESULT CALLBACK gutterProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam);

  public:
    App(HINSTANCE instance, fs::path assets, fs::path data, bool smoke);
    ~App();
    int run(int show);
};
} // namespace fe
