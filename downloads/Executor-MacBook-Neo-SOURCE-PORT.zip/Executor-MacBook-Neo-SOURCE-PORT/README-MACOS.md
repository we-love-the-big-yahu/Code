# Funny Executor — partial macOS source port

**This is source code, not a finished Mac executor. Roblox attachment and execution
inside Roblox are not implemented.** The original archive supplies a Windows process
backend and Windows RPC bridge; those cannot be reused directly on macOS.
The Mac UI marks Attach and Execute unavailable. A successful build or compilation
check does not establish in-game compatibility.

## Architecture-specific files

- `Build-MacBook-Neo.command`: targets Apple silicon (`arm64`).
- `Build-Intel-MacBook.command`: targets Intel (`x86_64`).

“MacBook Neo” is treated as the requested Apple silicon target. Check the chip in
Apple menu → About This Mac. Both builds target macOS 13 or later. These files are
build commands; they are not converted Windows executables or prebuilt Mac apps.

## What was ported

- Native AppKit desktop interface, replacing the Win32/Rich Edit entry point and UI.
- Script tabs with editing/undo, native file import/export, local script browsing,
  search, session autosave, saved-session import, and damaged-session preservation.
- Embedded native Luau compiler built from vendored source; no `compile.exe`, Wine,
  or Rosetta is needed for compilation. The UI checks compilation only.
- POSIX atomic replacement using same-directory exclusive temporary files, file
  flushing, and cleanup; Mac data under `~/Library/Application Support/FunnyExecutorMac`.
- Native CommonCrypto/Security crypto on macOS; verified TLS HTTP through libcurl.
- Reused portable traversal/export/decompiler logic with Windows types removed,
  UTF-8 filesystem paths, and protection against overwriting earlier export files.
  These library functions do not provide access to a live game without a backend.
- Portable regression tests, an Apple-only GUI smoke test, architecture-specific
  build/package scripts, and an unexecuted macOS CI workflow.

The original `src/`, Windows build commands, runtime assets, and retained dependency
licenses are included for reference. Windows executable releases and the Windows
compiler binary are excluded from these source packages. The original Windows
README below `README.md` describes the original project, not the Mac port's readiness.

## Build on a Mac

Requirements: macOS 13+, Apple's Xcode Command Line Tools, and CMake 3.24+.
Install Apple's tools with `xcode-select --install`. Install CMake from cmake.org
or with `brew install cmake` if you use Homebrew. No dependencies are downloaded
by CMake: Luau, JSON, and Zstandard source are included.

From Terminal in the extracted package, run the appropriate command:

```sh
bash Build-MacBook-Neo.command
# OR, for Intel:
bash Build-Intel-MacBook.command
```

The architecture-specific ZIP downloads contain just `Build.command` for their target:

```sh
bash Build.command
```

The build runs core tests and the desktop smoke test when the target matches the
current shell's architecture. Cross-built target tests are explicitly reported as
unrun. To test a cross build, run its `ctest --test-dir build-macos-ARCH
--output-on-failure` command on the matching architecture.

After a successful build, the app is at
`dist-macos-ARCH/FunnyExecutorMac.app`. A local ad-hoc signature is applied and
verified, and an app ZIP is produced. That is not Apple notarization or a Developer
ID signature. No instructions disable Gatekeeper, SIP, code signing, or other OS
protections. Mac build/sign/startup tests have not been run by this Linux-hosted task.

## Validation performed here

The portable C++ core was configured and built in Release mode on Linux using GCC.
Its regression suite exercises Unicode paths, atomic replacement and failure cleanup,
base64 validation, known SHA/HMAC vectors, secure identifiers, symlink/traversal
rejection, normal/legacy/corrupt session handling, real Luau compilation and VM
execution of `return 6*7`, compiler diagnostics, fixture-based script traversal,
decompiler caching, non-overwriting exports, cancellation, and explicit unavailable
backend status. Additional HTTP tests use a local fixture server, never game data.

The test results are in `validation/linux-core-tests.txt`. Core tests using OpenSSL
on Linux do not test the CommonCrypto/Security branch on Mac. AppKit code, signing,
Intel/Apple silicon binaries, macOS startup, and live Roblox behavior are untested.
The included GitHub workflow is a proposed validation route, not evidence it ran.

## Remaining work for the requested in-Roblox executor

1. Implement and validate a real macOS client/process integration backend for the
   intended Roblox client build and architecture. The current backend capability
   explicitly returns unavailable; it does not pretend to attach.
2. Port the original runtime RPC bridge and its caller validation, WebSockets,
   clipboard/input/file-dialog/custom-asset behavior. No unauthenticated replacement
   listener is started by the Mac app.
3. Validate the original initializer and opaque `init.bin`, plus compiler/runtime
   compatibility, with that backend. The compiler vendored here is official Luau;
   compatibility with the uploaded Windows compiler or a live client is not claimed.
4. Restore the game explorer/decompilation UI, queued execution and autoexec only
   after a working Mac backend exists. They have not been silently redirected to a
   standalone interpreter.
5. Build and test on both Mac architectures; perform any desired Developer ID
   signing/notarization on a Mac with your own credentials.

The missing backend and Mac test environment remain blockers for full feature parity.
Do not describe this partial source port as a working Roblox executor.
