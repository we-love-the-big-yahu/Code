@echo off
if exist "%~dp0dist\FunnyExecutor.exe" (
  start "Funny Executor" "%~dp0dist\FunnyExecutor.exe"
) else if exist "%~dp0build\FunnyExecutor.exe" (
  start "Funny Executor" "%~dp0build\FunnyExecutor.exe"
) else (
  echo Run build.cmd first.
  pause
)
