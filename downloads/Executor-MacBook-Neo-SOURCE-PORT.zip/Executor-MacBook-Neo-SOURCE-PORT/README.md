> **macOS source packages:** Read [README-MACOS.md](README-MACOS.md) first. This is a partial source port; Roblox execution is not implemented on Mac. No Mac app binary is included.

# Funny Executor — native C++ remake

A Windows x64 C++20 remake of the Python FunnyExecutor desktop app. The application UI and backend are native C++; the scripting runtime remains Luau. Python, PySide6 and Qt are not required.

## Run

Open `dist/FunnyExecutor.exe`, or double-click `launch.cmd`. The prepared release includes `dist/assets`; keep that folder alongside the executable.

Close the Python executor before attaching: both use loopback port 9475. Open Roblox, join a game, click **Attach**, then use **Execute** or **Ctrl+Enter**. Attaching can briefly bring the Roblox window forward and use the Escape key, as in the original implementation.

If that game already has the Python runtime loaded, the native app runs a small readiness probe through it before reconnecting. It does not treat the folder's existence alone as success. An incomplete or unresponsive runtime requires rejoining the game. Fresh initialization waits for a bootstrap request and completion marker, with a bounded timeout. `executor.log` records rejected bridge callers/headers and initializer/source fetches.

**Live Roblox attachment/injection has not been validated in this environment.** The native release builds, its regression tests pass, and its desktop startup/shutdown is tested. Roblox memory offsets and the reused runtime are version-dependent. This project does not claim current compatibility or undetected operation.

## Build

Install Visual Studio or Build Tools with **Desktop development with C++**, the Windows 10/11 SDK, CMake 3.24+ and Ninja. Run:

```bat
build.cmd
```

This configures a Release build, builds the executable, runs tests, and stages `dist/`. All library source is vendored; configuring the build requires no downloads.

From an x64 Visual Studio Developer Command Prompt, the individual steps are:

```bat
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 4
ctest --test-dir build --output-on-failure
cmake --install build --prefix dist
```

## Features

- Native dark editor with Luau syntax colors, line numbers and Unicode support.
- Multiple tabs; close, move left/right, and switch with Ctrl+Tab.
- Searchable file browser for Scripts, Auto-Execute, Workspace and Decompiled exports.
- Searchable client script explorer, decompile selected scripts into tabs, and bulk decompile to a folder with progress and cancellation.
- Open/export scripts, session autosave, recoverable damaged-session files and atomic replacement.
- A background worker for process attachment and compilation; the GUI stays responsive during those operations.
- Queued execution with one source fetch in flight, rather than overwriting a shared pending script.
- Native loopback bridge for file operations, clipboard, input, hashing/HMAC, dialogs, console, WebSockets, FPS, script bytecode/hash, decompilation and custom assets.
- Automatic execution of `.lua`/`.luau` files from the new app's `autoexec` folder after a successful attachment.
- CSPRNG-backed temporary filenames and bounded compiler/network operations.

The Luau initializer and its public API are retained from the original. This is not a complete rewrite of the Luau VM. Existing limitations of that runtime remain, including APIs implemented as compatibility approximations. `assets/fvm/FunnyVM.luau` is retained with its license, while the shipped `assets/luau/init.bin` is the original Roblox-built runtime bytecode. Editing that VM source does not rebuild the binary; rebuild it in an authorized Roblox Studio test place using the original workflow.

## Browse and decompile game scripts

1. Join a game and click **Attach**.
2. Choose **Game scripts (client)** in the sidebar, or **Run → Browse game scripts**. Click **Refresh scripts** to scan again.
3. Search by script path or class. Select a script and click **Decompile selected**, or double-click it, to open reconstructed Luau in a new editor tab.
4. Click **Decompile all** to export the entire scanned list, including entries hidden by the search filter. The results folder opens when the job finishes or is cancelled.

Decompilation sends available bytecode to **https://api.lua.expert/decompile**. Results are cached locally by bytecode hash, so unchanged scripts do not need another upload. Cancel stops after the current bounded network request finishes; closing the app also cancels the job. Three consecutive service failures stop a batch, preserving its successful results.

Exports are stored under `%APPDATA%/FunnyExecutorCpp/decompiled/game-<id>/`. Each script gets a unique safe filename, and `manifest.json` maps files to their original instance paths and lists failures and any reason for stopping. Previously exported files are not overwritten. Open them from **Local files → Decompiled**, or use **File → Open data folder**.

This lists client-visible **LocalScripts and ModuleScripts**, excluding Roblox's CoreGui/CorePackages and the executor runtime. It cannot retrieve server-only source or recreate an original Studio project, map, comments, or formatting. Some modules have no readable bytecode; `Script` instances with a client RunContext are not supported by the current bytecode reader. Decompiler output may need correction and is never executed automatically. Refresh after changing games or after a script is moved/deleted. Scanning prioritizes ReplicatedStorage, ReplicatedFirst and player/starter services before large Workspace scenes. Roblox UI/framework containers are excluded. A scan stops at 15 seconds, 250,000 instances or 5,000 scripts and labels a partial list; a batch caps exported source at 256 MiB.

The service was tested with our own small compiled fixture, which returned compilable Luau. The desktop explorer, batch export, cache, errors, cancellation, and session changes have regression coverage. A read-only live-client check enumerated scripts and read bytecode from both LocalScripts and ModuleScripts. No game bytecode was uploaded during that check; full live-game decompilation still needs a user-driven check.

## Data and recovery

The native app uses `%APPDATA%/FunnyExecutorCpp/`, separate from the Python app's `%APPDATA%/FunnyExecutor/`.

On first launch it imports a valid legacy tab session if one is present. A damaged legacy session is left untouched. A damaged native session is copied to `tabs.json.corrupt-<id>` before a fresh tab opens. If that backup fails, saving is disabled to protect the original file.

Session writes use a same-directory temporary file, `FlushFileBuffers`, and `MoveFileExW` with replacement/write-through. A failed write leaves the previous session intact. Logs are in `executor.log`. Use **File → Open data folder** to access scripts, workspace and logs.

## Bridge boundary

The listener binds IPv4 loopback, caps request sizes and connection queues, rejects browser Origin headers and unexpected Host headers, and checks the connecting TCP client's owning PID against the currently attached Roblox process. Connections from unrelated local processes are rejected. This preserves the existing Luau wire protocol without exposing the original unauthenticated local command dispatcher. Code running inside the attached Roblox process can still call its scripting APIs; this check is not a sandbox between scripts in that process.

Workspace paths reject traversal, absolute paths, stream selectors, Windows device names and trailing dots/spaces. Executable extensions are blocked, and deleting the workspace root is rejected.

## Keyboard shortcuts

| Shortcut | Action |
| --- | --- |
| Ctrl+N | New tab |
| Ctrl+W | Close current tab |
| Ctrl+Tab / Ctrl+Shift+Tab | Next / previous tab |
| Ctrl+O | Open script |
| Ctrl+S | Save session |
| Ctrl+Shift+S | Export current script |
| Ctrl+I | Attach |
| Ctrl+Enter | Execute |
| F5 | Refresh file browser |

## Validation

`executor_tests` covers Unicode/base64/hash handling, Windows path rejection, legacy and corrupt sessions, atomic-write failure, compiler diagnostics, encrypted runtime bytecode decoding, file RPCs, queued execution, rejection of an unrelated bridge caller, client script traversal, safe export names, decompiler errors/cache, and partial exports after cancellation or a game change. It uses temporary files and never attaches to Roblox. Add `--decompile-service` after the assets argument to opt into a service test that uploads only a fixture compiled by the test itself.

`FunnyExecutor.exe --smoke-test` starts the GUI with a temporary data directory and no bridge/Roblox worker, checks editor/tab operations, script browser filtering, busy/cancel controls and opening decompiled source in a tab, then exits automatically.

Dependencies and retained licenses are listed in [THIRD_PARTY.md](THIRD_PARTY.md). API references: [Windows TCP ownership](https://learn.microsoft.com/en-us/windows/win32/api/tcpmib/ns-tcpmib-mib_tcptable_owner_pid), [WinHTTP WebSocket upgrade](https://learn.microsoft.com/en-us/windows/win32/api/winhttp/nf-winhttp-winhttpwebsocketcompleteupgrade), [nlohmann/json](https://github.com/nlohmann/json), [Zstandard](https://github.com/facebook/zstd).
