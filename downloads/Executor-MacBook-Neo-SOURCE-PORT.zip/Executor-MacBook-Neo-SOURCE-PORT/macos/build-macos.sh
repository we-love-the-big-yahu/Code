#!/bin/bash
set -euo pipefail
source_root="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$(uname -s)" != Darwin ]]; then
  echo "This builds a macOS source port and requires a Mac with Xcode Command Line Tools." >&2
  exit 1
fi
build_arch="${1:-$(uname -m)}"
case "$build_arch" in arm64|x86_64) ;; *) echo "Choose arm64 or x86_64." >&2; exit 1;; esac
if ! command -v cmake >/dev/null 2>&1; then
  echo "CMake 3.24+ is required. Install it from cmake.org, or use: brew install cmake" >&2
  exit 1
fi
if ! xcrun --find clang++ >/dev/null 2>&1; then
  echo "Install Apple's development tools using xcode-select --install, then run this again." >&2
  exit 1
fi
build_dir="$source_root/build-macos-$build_arch"
stage_dir="$source_root/dist-macos-$build_arch"
cmake -S "$source_root" -B "$build_dir" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES="$build_arch" \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=13.0
cmake --build "$build_dir" --target FunnyExecutorMac mac_port_tests --parallel 3
if [[ "$build_arch" == "$(uname -m)" ]]; then
  ctest --test-dir "$build_dir" --output-on-failure
else
  echo "Built for $build_arch; tests were NOT run because this shell is running $(uname -m)."
  echo "Run ctest --test-dir \"$build_dir\" --output-on-failure on the matching architecture."
fi
cmake --install "$build_dir" --prefix "$stage_dir"
app_path="$stage_dir/FunnyExecutorMac.app"
/usr/bin/codesign --force --deep --sign - "$app_path"
/usr/bin/codesign --verify --deep --strict "$app_path"
/usr/bin/lipo -verify_arch "$build_arch" "$app_path/Contents/MacOS/FunnyExecutorMac"
/usr/bin/ditto -c -k --sequesterRsrc --keepParent "$app_path" "$source_root/FunnyExecutorMac-$build_arch-SOURCE-PORT.app.zip"
echo "Built: $app_path"
echo "Partial source port only: Roblox attachment and in-game execution are NOT implemented."
echo "Local ad-hoc signature only; this is not a notarized distribution."
