#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>
#include <stdexcept>
#include <functional>
#include <algorithm>
namespace fe {
namespace fs=std::filesystem;
class Error: public std::runtime_error { public: using std::runtime_error::runtime_error; };
class GameNotReady: public Error { public: using Error::Error; };
std::wstring wide(std::string_view text);
std::string utf8(std::wstring_view text);
fs::path dataDirectory();
std::string readFile(const fs::path&,size_t limit=64*1024*1024);
void atomicWrite(const fs::path&,std::string_view);
std::string base64Encode(std::string_view);
std::string base64Decode(std::string_view);
std::string digest(std::string_view,std::string algorithm="sha256",std::string_view key={},bool hmac=false);
std::string randomHex(size_t count=16);
fs::path workspacePath(const fs::path&,std::string_view);
bool blockedExtension(const fs::path&);
std::string httpRequest(std::wstring,std::string_view method="GET",std::string_view body={},std::wstring headers=L"",size_t limit=32*1024*1024);
std::vector<std::string> split(std::string_view,char);
std::string lower(std::string);
void log(const fs::path&,std::string_view);
}
