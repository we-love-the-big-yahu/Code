#include "util.hpp"
#include <codecvt>
#include <locale>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <mutex>
#include <set>
#include <memory>
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <curl/curl.h>
#ifdef __APPLE__
#include <CommonCrypto/CommonDigest.h>
#include <CommonCrypto/CommonHMAC.h>
#include <Security/SecRandom.h>
#else
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#endif
namespace fe {
std::wstring wide(std::string_view value) {
    return std::wstring_convert<std::codecvt_utf8<wchar_t>>{}.from_bytes(value.data(),value.data()+value.size());
}
std::string utf8(std::wstring_view value) {
    return std::wstring_convert<std::codecvt_utf8<wchar_t>>{}.to_bytes(value.data(),value.data()+value.size());
}
std::string lower(std::string value) { for(auto& c:value) c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));return value; }
fs::path dataDirectory() {
    const char* home=std::getenv("HOME");
    if(!home || !*home) throw Error("No user home directory available");
#ifdef __APPLE__
    return fs::path(home)/"Library/Application Support/FunnyExecutorMac";
#else
    return fs::path(home)/".local/share/FunnyExecutorMac";
#endif
}
std::string readFile(const fs::path& path,size_t limit) {
    std::ifstream file(path,std::ios::binary);
    if(!file) throw Error("Cannot read "+path.string());
    std::string output; char buffer[8192];
    while(file) {
        file.read(buffer,sizeof(buffer)); auto count=static_cast<size_t>(file.gcount());
        if(output.size()+count>limit) throw Error("File exceeds size limit");
        output.append(buffer,count);
    }
    if(!file.eof()) throw Error("File read failed");
    return output;
}
std::string randomHex(size_t count) {
    if(count>1024*1024) throw Error("Random request too large");
    std::string bytes(count,'\0');
#ifdef __APPLE__
    if(SecRandomCopyBytes(kSecRandomDefault,count,reinterpret_cast<uint8_t*>(bytes.data()))!=errSecSuccess) throw Error("Secure random failed");
#else
    if(count && RAND_bytes(reinterpret_cast<unsigned char*>(bytes.data()),static_cast<int>(count))!=1) throw Error("Secure random failed");
#endif
    static constexpr char h[]="0123456789abcdef";
    std::string result;result.reserve(count*2);
    for(unsigned char c:bytes) {result+=h[c>>4];result+=h[c&15];} return result;
}
void atomicWrite(const fs::path& path,std::string_view bytes) {
    auto parent=path.parent_path(); if(parent.empty()) parent=".";
    fs::create_directories(parent);
    auto temp=parent/("."+path.filename().string()+".tmp-"+randomHex(16));
    int descriptor=::open(temp.c_str(),O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC,0600);
    if(descriptor<0) throw Error("Cannot create temporary save file");
    try {
        size_t offset=0;
        while(offset<bytes.size()) {
            auto count=::write(descriptor,bytes.data()+offset,bytes.size()-offset);
            if(count<0 && errno==EINTR) continue;
            if(count<=0) throw Error("Cannot write save file");
            offset+=static_cast<size_t>(count);
        }
        if(::fsync(descriptor)!=0) throw Error("Cannot flush save file");
        int closing=descriptor;descriptor=-1;
        if(::close(closing)!=0) throw Error("Cannot close save file");
        if(::rename(temp.c_str(),path.c_str())!=0) throw Error("Cannot replace save file");
        int dir=::open(parent.c_str(),O_RDONLY|O_CLOEXEC);
        if(dir>=0) {::fsync(dir);::close(dir);}
    } catch(...) { if(descriptor>=0) ::close(descriptor); std::error_code error;fs::remove(temp,error);throw; }
}
std::string base64Encode(std::string_view bytes) {
    static constexpr char alphabet[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;
    for(size_t i=0;i<bytes.size();i+=3) {
        unsigned a=static_cast<unsigned char>(bytes[i]);
        unsigned b=i+1<bytes.size()?static_cast<unsigned char>(bytes[i+1]):0;
        unsigned c=i+2<bytes.size()?static_cast<unsigned char>(bytes[i+2]):0;
        result+=alphabet[a>>2];result+=alphabet[((a&3)<<4)|(b>>4)];
        result+=i+1<bytes.size()?alphabet[((b&15)<<2)|(c>>6)]:'=';
        result+=i+2<bytes.size()?alphabet[c&63]:'=';
    } return result;
}
std::string base64Decode(std::string_view text) {
    if(text.size()%4) throw Error("Invalid base64 length");
    auto value=[](char c)->unsigned {
        if(c>='A'&&c<='Z') return c-'A';if(c>='a'&&c<='z') return c-'a'+26;
        if(c>='0'&&c<='9') return c-'0'+52;if(c=='+') return 62;if(c=='/') return 63;
        throw Error("Invalid base64 character");
    };
    std::string result;
    for(size_t i=0;i<text.size();i+=4) {
        bool pad2=text[i+2]=='=',pad3=text[i+3]=='=';
        if((pad2&&!pad3)||((pad2||pad3)&&i+4!=text.size())) throw Error("Invalid base64 padding");
        unsigned a=value(text[i]),b=value(text[i+1]),c=pad2?0:value(text[i+2]),d=pad3?0:value(text[i+3]);
        if((pad2&&(b&15))||(!pad2&&pad3&&(c&3))) throw Error("Noncanonical base64");
        result+=static_cast<char>((a<<2)|(b>>4));
        if(!pad2) result+=static_cast<char>((b<<4)|(c>>2));
        if(!pad3) result+=static_cast<char>((c<<6)|d);
    }return result;
}
std::string digest(std::string_view bytes,std::string algorithm,std::string_view key,bool hmac) {
    algorithm=lower(algorithm);std::string output;
#ifdef __APPLE__
    CCHmacAlgorithm kind;size_t length;
    if(algorithm=="sha256") {kind=kCCHmacAlgSHA256;length=CC_SHA256_DIGEST_LENGTH;}
    else if(algorithm=="sha384") {kind=kCCHmacAlgSHA384;length=CC_SHA384_DIGEST_LENGTH;}
    else if(algorithm=="sha512") {kind=kCCHmacAlgSHA512;length=CC_SHA512_DIGEST_LENGTH;}
    else if(algorithm=="sha1") {kind=kCCHmacAlgSHA1;length=CC_SHA1_DIGEST_LENGTH;}
    else if(algorithm=="md5") {kind=kCCHmacAlgMD5;length=CC_MD5_DIGEST_LENGTH;}
    else throw Error("Unsupported digest");
    if(bytes.size()>UINT32_MAX) throw Error("Digest input too large");
    output.resize(length);
    if(hmac) CCHmac(kind,key.data(),key.size(),bytes.data(),bytes.size(),output.data());
    else if(algorithm=="sha256") CC_SHA256(bytes.data(),static_cast<CC_LONG>(bytes.size()),reinterpret_cast<unsigned char*>(output.data()));
    else if(algorithm=="sha384") CC_SHA384(bytes.data(),static_cast<CC_LONG>(bytes.size()),reinterpret_cast<unsigned char*>(output.data()));
    else if(algorithm=="sha512") CC_SHA512(bytes.data(),static_cast<CC_LONG>(bytes.size()),reinterpret_cast<unsigned char*>(output.data()));
    else if(algorithm=="sha1") CC_SHA1(bytes.data(),static_cast<CC_LONG>(bytes.size()),reinterpret_cast<unsigned char*>(output.data()));
    else CC_MD5(bytes.data(),static_cast<CC_LONG>(bytes.size()),reinterpret_cast<unsigned char*>(output.data()));
#else
    const EVP_MD* md=EVP_get_digestbyname(algorithm.c_str());if(!md) throw Error("Unsupported digest");
    output.resize(EVP_MAX_MD_SIZE);unsigned length=0;
    if(hmac) {
        if(key.size()>INT32_MAX || !HMAC(md,key.data(),static_cast<int>(key.size()),reinterpret_cast<const unsigned char*>(bytes.data()),bytes.size(),reinterpret_cast<unsigned char*>(output.data()),&length)) throw Error("HMAC failed");
    } else {
        auto ctx=std::unique_ptr<EVP_MD_CTX,decltype(&EVP_MD_CTX_free)>(EVP_MD_CTX_new(),EVP_MD_CTX_free);
        if(!ctx || !EVP_DigestInit_ex(ctx.get(),md,nullptr) || !EVP_DigestUpdate(ctx.get(),bytes.data(),bytes.size()) || !EVP_DigestFinal_ex(ctx.get(),reinterpret_cast<unsigned char*>(output.data()),&length)) throw Error("Digest failed");
    }output.resize(length);
#endif
    if(hmac) return base64Encode(output);
    std::ostringstream result;result<<std::hex<<std::setfill('0');for(unsigned char c:output) result<<std::setw(2)<<unsigned(c);return result.str();
}
fs::path workspacePath(const fs::path& workspace,std::string_view relative) {
    if(relative.find('\0')!=relative.npos || relative.find('\\')!=relative.npos) throw Error("Invalid workspace path");
    fs::path rel(relative);
    if(rel.is_absolute()) throw Error("Workspace path must be relative");
    for(const auto& part:rel) if(part==".." || part.string().find(':')!=std::string::npos) throw Error("Workspace traversal rejected");
    auto root=fs::weakly_canonical(workspace),target=fs::weakly_canonical(root/rel);
    auto t=target.begin();
    for(auto r=root.begin();r!=root.end();++r,++t) if(t==target.end()||*r!=*t) throw Error("Path escapes workspace");
    return target;
}
bool blockedExtension(const fs::path& path) {
    static const std::set<std::string> blocked={".exe",".dll",".dylib",".so",".app",".command",".sh",".bash",".zsh",".py",".js",".bat",".cmd",".ps1",".pkg",".dmg"};
    return blocked.contains(lower(path.extension().string()));
}
std::vector<std::string> split(std::string_view text,char delimiter) {
    std::vector<std::string> out;size_t start=0;
    for(size_t i=0;i<=text.size();++i) if(i==text.size()||text[i]==delimiter) {out.emplace_back(text.substr(start,i-start));start=i+1;}
    return out;
}
std::string httpRequest(std::wstring wideUrl,std::string_view method,std::string_view body,std::wstring wideHeaders,size_t limit) {
    static std::once_flag initialized;
    std::call_once(initialized,[]{if(curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK) throw Error("HTTP initialization failed");});
    auto curl=std::unique_ptr<CURL,decltype(&curl_easy_cleanup)>(curl_easy_init(),curl_easy_cleanup);
    if(!curl) throw Error("Cannot create HTTP request");
    auto url=utf8(wideUrl),verb=std::string(method),headers=utf8(wideHeaders);
    if(!url.starts_with("https://")&&!url.starts_with("http://")) throw Error("Invalid HTTP URL");
    struct Result {std::string data;size_t limit;bool overflow=false;} result{{},limit};
    curl_easy_setopt(curl.get(),CURLOPT_URL,url.c_str());
    curl_easy_setopt(curl.get(),CURLOPT_CUSTOMREQUEST,verb.c_str());
#if LIBCURL_VERSION_NUM >= 0x075500
    curl_easy_setopt(curl.get(),CURLOPT_PROTOCOLS_STR,"http,https");
#else
    curl_easy_setopt(curl.get(),CURLOPT_PROTOCOLS,CURLPROTO_HTTP|CURLPROTO_HTTPS);
#endif
    curl_easy_setopt(curl.get(),CURLOPT_SSL_VERIFYPEER,1L);curl_easy_setopt(curl.get(),CURLOPT_SSL_VERIFYHOST,2L);
    curl_easy_setopt(curl.get(),CURLOPT_CONNECTTIMEOUT,5L);curl_easy_setopt(curl.get(),CURLOPT_TIMEOUT,20L);
    curl_easy_setopt(curl.get(),CURLOPT_NOSIGNAL,1L);curl_easy_setopt(curl.get(),CURLOPT_FOLLOWLOCATION,0L);
    curl_easy_setopt(curl.get(),CURLOPT_USERAGENT,"FunnyExecutorMac-source-port/0.1");
    curl_easy_setopt(curl.get(),CURLOPT_WRITEFUNCTION,+[](char* bytes,size_t size,size_t count,void* ptr)->size_t {
        auto& output=*static_cast<Result*>(ptr);
        if(size && count>SIZE_MAX/size) return 0;
        auto amount=size*count;if(amount>output.limit-output.data.size()) {output.overflow=true;return 0;}
        try {output.data.append(bytes,amount);} catch(...) {return 0;}return amount;
    });
    curl_easy_setopt(curl.get(),CURLOPT_WRITEDATA,&result);
    if(!body.empty() || verb=="POST") {
        curl_easy_setopt(curl.get(),CURLOPT_POSTFIELDS,body.data());curl_easy_setopt(curl.get(),CURLOPT_POSTFIELDSIZE_LARGE,static_cast<curl_off_t>(body.size()));
    }
    curl_slist* rawHeaders=nullptr;
    for(auto line:split(headers,'\n')) {
        if(!line.empty()&&line.back()=='\r') line.pop_back();if(line.empty()) continue;
        auto* next=curl_slist_append(rawHeaders,line.c_str());
        if(!next) {curl_slist_free_all(rawHeaders);throw Error("HTTP headers allocation failed");}rawHeaders=next;
    }
    auto list=std::unique_ptr<curl_slist,decltype(&curl_slist_free_all)>(rawHeaders,curl_slist_free_all);
    if(rawHeaders) curl_easy_setopt(curl.get(),CURLOPT_HTTPHEADER,rawHeaders);
    auto status=curl_easy_perform(curl.get());long code=0;curl_easy_getinfo(curl.get(),CURLINFO_RESPONSE_CODE,&code);
    if(status!=CURLE_OK) throw Error(result.overflow?"HTTP response too large":std::string("HTTP request failed: ")+curl_easy_strerror(status));
    if(code<200||code>=300) throw Error("HTTP status "+std::to_string(code));
    return result.data;
}
void log(const fs::path& directory,std::string_view text) {
    static std::mutex mutex;std::lock_guard guard(mutex);
    try {fs::create_directories(directory);std::ofstream f(directory/"executor.log",std::ios::app);f<<text<<'\n';}catch(...) {}
}
}
