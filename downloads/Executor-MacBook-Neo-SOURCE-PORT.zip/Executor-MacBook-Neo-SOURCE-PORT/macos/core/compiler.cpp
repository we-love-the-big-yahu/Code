#include "compiler.hpp"
#include <Luau/Compiler.h>
#include <zstd.h>
#include <cstring>
namespace fe {
std::string Compiler::compile(std::string_view source,std::string_view chunkName) {
    if(source.size()>16*1024*1024) throw Error("Source exceeds 16 MiB limit");
    std::lock_guard guard(mutex_);
    auto key=std::string(source)+std::string(1,'\0')+std::string(chunkName);
    if(auto entry=cache_.find(key);entry!=cache_.end()) return entry->second;
    auto bytecode=Luau::compile(std::string(source));
    if(bytecode.empty()||bytecode.front()==0) throw Error("Luau compile error: "+(bytecode.size()>1?bytecode.substr(1):"empty output"));
    if(cache_.size()>=32) cache_.clear();
    cache_.emplace(std::move(key),bytecode);return bytecode;
}
std::string Compiler::decrypt(std::string_view encrypted) {
    if(encrypted.size()<8) throw Error("Bytecode too short");
    std::string bytes(encrypted);const unsigned char signature[]={'R','S','B','1'};unsigned char key[4];
    for(size_t i=0;i<4;++i) key[i]=static_cast<unsigned char>((static_cast<unsigned char>(bytes[i])^signature[i])-i*41);
    for(size_t i=0;i<bytes.size();++i) bytes[i]=static_cast<char>(static_cast<unsigned char>(bytes[i])^static_cast<unsigned char>(key[i%4]+i*41));
    uint32_t length=0;std::memcpy(&length,bytes.data()+4,4);
    if(bytes.substr(0,4)!="RSB1"||!length||length>50*1024*1024) throw Error("Invalid encrypted bytecode");
    std::string output(length,0);auto actual=ZSTD_decompress(output.data(),length,bytes.data()+8,bytes.size()-8);
    if(ZSTD_isError(actual)||actual!=length) throw Error("Bytecode decompression failed");return output;
}
}
