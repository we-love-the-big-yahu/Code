#pragma once
#include "util.hpp"
namespace fe {
struct Tab {
    std::string name;
    std::string content;
};
struct Session {
    int nextTab = 1;
    size_t active = 0;
    std::vector<Tab> tabs = {{"Script #1", "print(\"Hello, World!\")"}};
};
struct LoadedSession {
    Session session;
    std::string recovery;
    bool saveAllowed = true;
};
LoadedSession loadSession(const fs::path &path);
void saveSession(const fs::path &path, const Session &session);
} // namespace fe
