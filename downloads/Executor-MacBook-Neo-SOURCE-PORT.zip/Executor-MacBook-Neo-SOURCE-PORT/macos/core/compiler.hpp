#pragma once
#include "util.hpp"
#include <map>
#include <mutex>
namespace fe {
class Compiler {
    fs::path executable_;
    std::mutex mutex_;
    std::map<std::string, std::string> cache_;

  public:
    explicit Compiler(fs::path path) : executable_(std::move(path)) {}
    std::string compile(std::string_view source, std::string_view chunkName = {});
    static std::string decrypt(std::string_view encrypted);
};
} // namespace fe
