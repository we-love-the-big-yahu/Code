#pragma once
#include <string_view>
namespace fe {
// The archive supplies no macOS implementation. Do not equate editor startup,
// compilation or a discovered client PID with a working Roblox connection.
struct BackendStatus {
    bool canAttach=false;
    bool canExecute=false;
    std::string_view detail="Roblox execution unavailable: the source archive supplies only a Windows process/bridge backend. A macOS implementation and live-client validation are still required.";
};
inline BackendStatus macBackendStatus() {return {};}
}
