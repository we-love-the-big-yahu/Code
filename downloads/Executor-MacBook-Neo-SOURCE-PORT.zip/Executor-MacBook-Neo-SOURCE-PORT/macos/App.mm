#import <Cocoa/Cocoa.h>
#import <dispatch/dispatch.h>
#include <cstdlib>
#include <cstdio>
#include "session.hpp"
#include "compiler.hpp"
#include "backend.hpp"
#include <memory>

static NSString* native(std::string_view value) {
    NSString* result=[[NSString alloc] initWithBytes:value.data() length:value.size() encoding:NSUTF8StringEncoding];
    return result ?: @"[invalid UTF-8]";
}
static std::string bytes(NSString* value) {
    NSData* data=[value dataUsingEncoding:NSUTF8StringEncoding];
    return std::string(static_cast<const char*>(data.bytes),data.length);
}

@interface FEApp : NSObject <NSApplicationDelegate,NSWindowDelegate,NSTextViewDelegate,NSTabViewDelegate,NSTableViewDataSource,NSTableViewDelegate> {
    NSWindow* _window;
    NSTabView* _tabs;
    NSMutableArray<NSTextView*>* _editors;
    NSTableView* _browser;
    NSSearchField* _search;
    NSPopUpButton* _folder;
    NSMutableArray<NSString*>* _paths;
    NSTextField* _status;
    NSTextView* _output;
    NSButton* _compile;
    NSTimer* _autosave;
    fe::Session _session;
    fe::fs::path _root;
    std::unique_ptr<fe::Compiler> _compiler;
    BOOL _saveAllowed;
    BOOL _busy;
    BOOL _smoke;
}
@end

@implementation FEApp
- (void)error:(NSString*)message {
    NSAlert* alert=[NSAlert new];alert.messageText=@"Funny Executor Mac";alert.informativeText=message;
    [alert addButtonWithTitle:@"OK"];[alert runModal];
}
- (NSButton*)button:(NSString*)title action:(SEL)action {
    NSButton* b=[NSButton buttonWithTitle:title target:self action:action];b.bezelStyle=NSBezelStyleRounded;return b;
}
- (void)addMenu:(NSMenu*)menu title:(NSString*)title action:(SEL)action key:(NSString*)key {
    NSMenuItem* item=[[NSMenuItem alloc] initWithTitle:title action:action keyEquivalent:key];item.target=self;[menu addItem:item];
}
- (void)createMenus {
    NSMenu* bar=[NSMenu new];NSApp.mainMenu=bar;
    NSMenuItem* root=[NSMenuItem new];[bar addItem:root];NSMenu* application=[NSMenu new];root.submenu=application;
    [self addMenu:application title:@"About This Source Port" action:@selector(about:) key:@""];
    [application addItem:[NSMenuItem separatorItem]];
    [self addMenu:application title:@"Quit Funny Executor Mac" action:@selector(quit:) key:@"q"];
    NSMenuItem* fileRoot=[NSMenuItem new];fileRoot.title=@"File";[bar addItem:fileRoot];NSMenu* file=[NSMenu new];fileRoot.submenu=file;
    [self addMenu:file title:@"New Tab" action:@selector(newTab:) key:@"n"];
    [self addMenu:file title:@"Open Script…" action:@selector(open:) key:@"o"];
    [self addMenu:file title:@"Save Session" action:@selector(save:) key:@"s"];
    [self addMenu:file title:@"Export Current Script…" action:@selector(export:) key:@""];
    [self addMenu:file title:@"Import Windows Session…" action:@selector(importSession:) key:@""];
    [self addMenu:file title:@"Close Tab" action:@selector(closeTab:) key:@"w"];
    [self addMenu:file title:@"Open Data Folder" action:@selector(openData:) key:@""];
    NSMenuItem* editRoot=[NSMenuItem new];editRoot.title=@"Edit";[bar addItem:editRoot];NSMenu* edit=[NSMenu new];editRoot.submenu=edit;
    for(NSArray* entry in @[@[@"Undo",@"undo:",@"z"],@[@"Redo",@"redo:",@"Z"],@[@"Cut",@"cut:",@"x"],@[@"Copy",@"copy:",@"c"],@[@"Paste",@"paste:",@"v"],@[@"Select All",@"selectAll:",@"a"]]) {
        NSMenuItem* item=[[NSMenuItem alloc] initWithTitle:entry[0] action:NSSelectorFromString(entry[1]) keyEquivalent:entry[2]];
        item.target=nil;[edit addItem:item];
    }
    NSMenuItem* runRoot=[NSMenuItem new];runRoot.title=@"Script";[bar addItem:runRoot];NSMenu* run=[NSMenu new];runRoot.submenu=run;
    [self addMenu:run title:@"Check Luau Compilation" action:@selector(compile:) key:@"\r"];
    [self addMenu:run title:@"Roblox Integration Status" action:@selector(about:) key:@""];
}
- (NSTextView*)makeEditor:(NSString*)content {
    NSTextView* editor=[[NSTextView alloc] initWithFrame:NSMakeRect(0,0,700,400)];
    editor.richText=NO;editor.usesFontPanel=NO;editor.allowsUndo=YES;
    editor.automaticQuoteSubstitutionEnabled=NO;editor.automaticDashSubstitutionEnabled=NO;
    editor.automaticTextReplacementEnabled=NO;editor.automaticSpellingCorrectionEnabled=NO;
    editor.font=[NSFont monospacedSystemFontOfSize:13 weight:NSFontWeightRegular];
    editor.backgroundColor=[NSColor colorWithCalibratedWhite:0.09 alpha:1];editor.textColor=NSColor.textColor;
    editor.insertionPointColor=NSColor.whiteColor;editor.string=content;editor.delegate=self;
    editor.verticallyResizable=YES;editor.horizontallyResizable=YES;
    editor.autoresizingMask=NSViewWidthSizable;
    editor.textContainer.containerSize=NSMakeSize(CGFLOAT_MAX,CGFLOAT_MAX);
    editor.textContainer.widthTracksTextView=NO;editor.textContainerInset=NSMakeSize(12,10);
    return editor;
}
- (void)rebuildTabs {
    const size_t selected=_session.active;
    _tabs.delegate=nil;
    while(_tabs.numberOfTabViewItems) [_tabs removeTabViewItem:[_tabs tabViewItemAtIndex:0]];
    [_editors removeAllObjects];
    for(const auto& tab:_session.tabs) {
        NSTabViewItem* item=[[NSTabViewItem alloc] initWithIdentifier:NSUUID.UUID.UUIDString];item.label=native(tab.name);
        NSScrollView* scroll=[[NSScrollView alloc] initWithFrame:_tabs.contentRect];scroll.hasVerticalScroller=YES;scroll.hasHorizontalScroller=YES;
        NSTextView* editor=[self makeEditor:native(tab.content)];scroll.documentView=editor;item.view=scroll;
        [_editors addObject:editor];[_tabs addTabViewItem:item];
    }
    if(_session.tabs.size()) {
        _session.active=std::min(selected,_session.tabs.size()-1);
        [_tabs selectTabViewItemAtIndex:_session.active];
    }
    _tabs.delegate=self;
}
- (void)captureSession {
    NSInteger selected=[_tabs indexOfTabViewItem:_tabs.selectedTabViewItem];
    if(selected!=NSNotFound) _session.active=static_cast<size_t>(selected);
    for(NSUInteger i=0;i<_editors.count&&i<_session.tabs.size();++i) _session.tabs[i].content=bytes(_editors[i].string);
}
- (BOOL)persist:(BOOL)showError {
    if(!_saveAllowed) {if(showError) [self error:@"Session saving is disabled because the damaged session could not be backed up. Export your scripts before closing."];return NO;}
    try {[self captureSession];fe::saveSession(_root/"tabs.json",_session);return YES;}
    catch(const std::exception& e) {if(showError) [self error:native(e.what())];else _status.stringValue=@"Autosave failed — export or save before quitting.";return NO;}
}
- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    _smoke=[NSProcessInfo.processInfo.arguments containsObject:@"--smoke-test"];
    try {
        _root=_smoke?fe::fs::temp_directory_path()/("FunnyExecutorMac-Smoke-"+fe::randomHex(8)):fe::dataDirectory();
        for(auto folder:{"scripts","autoexec","workspace","decompiled"}) fe::fs::create_directories(_root/folder);
        auto loaded=fe::loadSession(_root/"tabs.json");_session=loaded.session;_saveAllowed=loaded.saveAllowed;
        _compiler=std::make_unique<fe::Compiler>(fe::fs::path{});_editors=[NSMutableArray new];_paths=[NSMutableArray new];
        [self createMenus];
        _window=[[NSWindow alloc] initWithContentRect:NSMakeRect(0,0,1120,760) styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable backing:NSBackingStoreBuffered defer:NO];
        _window.title=@"Funny Executor Mac — Source Port";_window.delegate=self;_window.minSize=NSMakeSize(1100,600);
        _window.appearance=[NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
        NSView* content=_window.contentView;
        NSStackView* actions=[NSStackView stackViewWithViews:@[[self button:@"New Tab" action:@selector(newTab:)],[self button:@"Open…" action:@selector(open:)],[self button:@"Export…" action:@selector(export:)],[self button:@"Save Session" action:@selector(save:)]]];
        _compile=[self button:@"Check Luau Compilation" action:@selector(compile:)];[actions addArrangedSubview:_compile];
        NSButton* attach=[self button:@"Attach — unavailable" action:@selector(about:)];attach.enabled=NO;
        NSButton* execute=[self button:@"Execute in Roblox — unavailable" action:@selector(about:)];execute.enabled=NO;
        [actions addArrangedSubview:attach];[actions addArrangedSubview:execute];actions.spacing=6;
        NSTextField* warning=[NSTextField wrappingLabelWithString:@"Partial macOS source port. Roblox attachment and in-game execution are NOT implemented. Compilation only checks Luau syntax; it does not run the script."];
        warning.textColor=NSColor.systemOrangeColor;warning.font=[NSFont systemFontOfSize:12];
        _folder=[NSPopUpButton new];[_folder addItemsWithTitles:@[@"scripts",@"autoexec",@"workspace",@"decompiled"]];_folder.target=self;_folder.action=@selector(refresh:);
        _search=[NSSearchField new];_search.placeholderString=@"Filter local scripts";_search.target=self;_search.action=@selector(refresh:);_search.sendsSearchStringImmediately=YES;
        _browser=[NSTableView new];NSTableColumn* column=[[NSTableColumn alloc] initWithIdentifier:@"path"];column.title=@"Local files";column.width=230;[_browser addTableColumn:column];_browser.headerView=nil;_browser.dataSource=self;_browser.delegate=self;_browser.target=self;_browser.doubleAction=@selector(openSelected:);
        NSScrollView* browserScroll=[NSScrollView new];browserScroll.documentView=_browser;browserScroll.hasVerticalScroller=YES;
        NSButton* refresh=[self button:@"Refresh files" action:@selector(refresh:)];
        NSStackView* sideStack=[NSStackView stackViewWithViews:@[_folder,_search,browserScroll,refresh]];sideStack.orientation=NSUserInterfaceLayoutOrientationVertical;sideStack.alignment=NSLayoutAttributeLeading;sideStack.spacing=8;
        _tabs=[NSTabView new];_tabs.delegate=self;
        _output=[NSTextView new];_output.editable=NO;_output.richText=NO;_output.font=[NSFont monospacedSystemFontOfSize:12 weight:NSFontWeightRegular];
        NSScrollView* outputScroll=[NSScrollView new];outputScroll.documentView=_output;outputScroll.hasVerticalScroller=YES;
        _status=[NSTextField labelWithString:@"Roblox backend unavailable. Edit and check compilation here."];
        NSStackView* body=[NSStackView stackViewWithViews:@[sideStack,_tabs]];body.orientation=NSUserInterfaceLayoutOrientationHorizontal;body.spacing=10;
        NSStackView* layout=[NSStackView stackViewWithViews:@[actions,warning,body,outputScroll,_status]];layout.orientation=NSUserInterfaceLayoutOrientationVertical;layout.alignment=NSLayoutAttributeLeading;layout.spacing=10;layout.translatesAutoresizingMaskIntoConstraints=NO;[content addSubview:layout];
        for(NSView* view in @[actions,warning,body,outputScroll,_status]) [view.widthAnchor constraintEqualToAnchor:layout.widthAnchor].active=YES;
        for(NSView* view in @[_folder,_search,browserScroll,refresh]) [view.widthAnchor constraintEqualToAnchor:sideStack.widthAnchor].active=YES;
        [NSLayoutConstraint activateConstraints:@[
            [layout.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:12],[layout.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-12],
            [layout.topAnchor constraintEqualToAnchor:content.topAnchor constant:12],[layout.bottomAnchor constraintEqualToAnchor:content.bottomAnchor constant:-12],
            [sideStack.widthAnchor constraintEqualToConstant:235],[sideStack.heightAnchor constraintEqualToAnchor:body.heightAnchor],[_tabs.heightAnchor constraintEqualToAnchor:body.heightAnchor],
            [body.heightAnchor constraintGreaterThanOrEqualToConstant:280],[outputScroll.heightAnchor constraintEqualToConstant:105]
        ]];
        [self rebuildTabs];[self refresh:nil];[_window center];
        if(!_smoke) {[_window makeKeyAndOrderFront:nil];[NSApp activateIgnoringOtherApps:YES];}
        if(!loaded.recovery.empty()&&!_smoke) [self error:native(loaded.recovery)];
        _autosave=[NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(autosave:) userInfo:nil repeats:YES];
        if(_smoke) dispatch_async(dispatch_get_main_queue(),^{[self smokeChecks];});
    }catch(const std::exception& error) {
        if(_smoke) {fprintf(stderr,"Startup failed: %s\n",error.what());std::exit(1);}
        [self error:native(error.what())];[NSApp terminate:nil];
    }
}
- (void)newTab:(id)sender {
    (void)sender;[self captureSession];
    if(_session.tabs.size()>=256) {[self error:@"The session is limited to 256 tabs."];return;}
    _session.tabs.push_back({"Script #"+std::to_string(++_session.nextTab),"print(\"Hello, World!\")"});_session.active=_session.tabs.size()-1;[self rebuildTabs];
}
- (void)closeTab:(id)sender {
    (void)sender;[self captureSession];if(_session.tabs.empty()) return;
    _session.tabs.erase(_session.tabs.begin()+_session.active);
    if(_session.tabs.empty()) {_session.tabs.push_back({"Script #"+std::to_string(++_session.nextTab),""});}
    _session.active=std::min(_session.active,_session.tabs.size()-1);[self rebuildTabs];[self persist:YES];
}
- (void)openPath:(NSString*)path {
    try {
        auto text=fe::readFile(fe::fs::path(bytes(path)),16*1024*1024);
        if(![[NSString alloc] initWithBytes:text.data() length:text.size() encoding:NSUTF8StringEncoding])
            throw fe::Error("The selected script is not valid UTF-8; its contents were left unchanged.");
        [self captureSession];
        if(_session.tabs.size()>=256) throw fe::Error("Close a tab before opening another script");
        _session.tabs.push_back({bytes(path.lastPathComponent),std::move(text)});_session.active=_session.tabs.size()-1;[self rebuildTabs];
    }catch(const std::exception& e) {[self error:native(e.what())];}
}
- (void)open:(id)sender {
    (void)sender;NSOpenPanel* panel=[NSOpenPanel openPanel];panel.canChooseDirectories=NO;panel.allowsMultipleSelection=YES;panel.allowedFileTypes=@[@"lua",@"luau",@"txt"];
    if([panel runModal]==NSModalResponseOK) for(NSURL* url in panel.URLs) [self openPath:url.path];
}
- (void)export:(id)sender {
    (void)sender;[self captureSession];if(_session.tabs.empty()) return;
    NSSavePanel* panel=[NSSavePanel savePanel];NSString* name=native(_session.tabs[_session.active].name);
    panel.nameFieldStringValue=[name.pathExtension length]?name:[name stringByAppendingPathExtension:@"luau"];
    if([panel runModal]!=NSModalResponseOK) return;
    try {fe::atomicWrite(fe::fs::path(bytes(panel.URL.path)),_session.tabs[_session.active].content);[self refresh:nil];}
    catch(const std::exception& e) {[self error:native(e.what())];}
}
- (void)save:(id)sender {(void)sender;if([self persist:YES]) _status.stringValue=@"Session saved.";}
- (void)autosave:(NSTimer*)timer {(void)timer;[self persist:NO];}
- (void)openData:(id)sender {(void)sender;[NSWorkspace.sharedWorkspace openURL:[NSURL fileURLWithPath:native(_root.string())]];}
- (void)importSession:(id)sender {
    (void)sender;NSOpenPanel* panel=[NSOpenPanel openPanel];panel.allowedFileTypes=@[@"json"];if([panel runModal]!=NSModalResponseOK) return;
    try {
        auto path=fe::fs::path(bytes(panel.URL.path));auto raw=fe::readFile(path,16*1024*1024);
        auto copy=_root/("import-"+fe::randomHex(8)+".json");fe::atomicWrite(copy,raw);
        auto loaded=fe::loadSession(copy);if(!loaded.recovery.empty()) throw fe::Error("The selected session is invalid; your existing tabs were kept.");
        if(![self persist:YES]) return;
        NSAlert* confirm=[NSAlert new];confirm.messageText=@"Replace open tabs with imported tabs?";confirm.informativeText=@"Your current session will be saved to a separate backup first.";[confirm addButtonWithTitle:@"Import"];[confirm addButtonWithTitle:@"Cancel"];
        if([confirm runModal]!=NSAlertFirstButtonReturn) return;
        fe::saveSession(_root/("tabs.before-import-"+fe::randomHex(8)+".json"),_session);
        _session=loaded.session;[self rebuildTabs];[self persist:YES];
    }catch(const std::exception& e) {[self error:native(e.what())];}
}
- (void)compile:(id)sender {
    (void)sender;if(_busy) return;[self captureSession];
    auto source=_session.tabs[_session.active].content;_busy=YES;_compile.enabled=NO;_status.stringValue=@"Checking compilation…";
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
        std::string result;
        try {auto compiled=self->_compiler->compile(source);result="Compilation passed ("+std::to_string(compiled.size())+" bytes).\nThis does not execute in Roblox. Game/runtime compatibility has not been validated.";}
        catch(const std::exception& e) {result=e.what();}
        NSString* message=native(result);
        dispatch_async(dispatch_get_main_queue(),^{self->_busy=NO;self->_compile.enabled=YES;self->_output.string=message;self->_status.stringValue=@"Compilation finished. Roblox backend remains unavailable.";});
    });
}
- (void)refresh:(id)sender {
    (void)sender;[_paths removeAllObjects];
    try {
        auto folder=_root/bytes(_folder.titleOfSelectedItem);auto query=fe::lower(bytes(_search.stringValue));
        for(const auto& entry:fe::fs::recursive_directory_iterator(folder,fe::fs::directory_options::skip_permission_denied)) {
            if(_paths.count>=5000) break;
            if(!entry.is_regular_file()||entry.is_symlink()) continue;
            auto ext=fe::lower(entry.path().extension().string());
            if(ext!=".lua"&&ext!=".luau"&&ext!=".txt") continue;
            auto display=fe::fs::relative(entry.path(),folder).string();
            if(!query.empty()&&fe::lower(display).find(query)==std::string::npos) continue;
            [_paths addObject:native(entry.path().string())];
        }
        [_paths sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    }catch(const std::exception& e) {_status.stringValue=native(e.what());}
    [_browser reloadData];
}
- (NSInteger)numberOfRowsInTableView:(NSTableView*)view {(void)view;return _paths.count;}
- (id)tableView:(NSTableView*)view objectValueForTableColumn:(NSTableColumn*)column row:(NSInteger)row {
    (void)view;(void)column;return _paths[row].lastPathComponent;
}
- (void)openSelected:(id)sender {(void)sender;NSInteger row=_browser.clickedRow;if(row>=0&&row<static_cast<NSInteger>(_paths.count)) [self openPath:_paths[row]];}
- (void)tabView:(NSTabView*)view didSelectTabViewItem:(NSTabViewItem*)item {
    NSInteger index=[view indexOfTabViewItem:item];if(index!=NSNotFound) _session.active=static_cast<size_t>(index);
}
- (void)textDidChange:(NSNotification*)notification {(void)notification;_status.stringValue=@"Edited — session autosaves every 10 seconds.";}
- (void)about:(id)sender {(void)sender;[self error:native(fe::macBackendStatus().detail)];}
- (void)quit:(id)sender {(void)sender;[NSApp terminate:nil];}
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {(void)sender;return YES;}
- (BOOL)windowShouldClose:(NSWindow*)window {(void)window;return [self persist:YES];}
- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)sender {
    (void)sender;if(_busy) {[self error:@"Wait for the current compilation check to finish before quitting."];return NSTerminateCancel;}
    return [self persist:YES]?NSTerminateNow:NSTerminateCancel;
}
- (void)applicationWillTerminate:(NSNotification*)notification {(void)notification;[_autosave invalidate];}
- (void)smokeChecks {
    try {
        auto fail=[](BOOL ok,const char* label) {if(!ok) throw fe::Error(label);};
        [self newTab:nil];fail(_editors.count==2&&_session.active==1,"new tab selection");_editors[1].string=@"return 42";
        [self captureSession];fail(_session.tabs[1].content=="return 42","editor capture");
        fail([self persist:NO],"session save");auto restored=fe::loadSession(_root/"tabs.json");fail(restored.session.tabs.size()==2,"session restore");
        [self closeTab:nil];fail(_editors.count==1,"close tab");
        fe::atomicWrite(_root/"scripts"/"fixture.luau","return 42");[self refresh:nil];fail(_paths.count==1,"local browser");
        fail(!_compiler->compile("return 42").empty(),"native compilation");
        fail(!fe::macBackendStatus().canExecute,"backend status");
        [_autosave invalidate];fe::fs::remove_all(_root);fprintf(stdout,"PASS macOS desktop smoke checks\n");std::exit(0);
    }catch(const std::exception& e) {fprintf(stderr,"FAIL smoke: %s\n",e.what());std::exit(1);}
}
@end
int main(int argc,const char* argv[]) {
    (void)argc;(void)argv;
    @autoreleasepool {
        NSApplication* app=NSApplication.sharedApplication;[app setActivationPolicy:NSApplicationActivationPolicyRegular];
        __attribute__((objc_precise_lifetime)) FEApp* delegate=[FEApp new];app.delegate=delegate;[app run];
    }return 0;
}
