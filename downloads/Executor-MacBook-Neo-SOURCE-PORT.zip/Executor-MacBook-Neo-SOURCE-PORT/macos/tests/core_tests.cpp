#include "util.hpp"
#include "session.hpp"
#include "compiler.hpp"
#include "scripts.hpp"
#include "backend.hpp"
#include <lua.h>
#include <lualib.h>
#include <nlohmann/json.hpp>
#include <iostream>
#include <functional>
using namespace fe;
int main(int argc,char** argv) {
    auto root=fs::temp_directory_path()/("executor-mac-tests-"+randomHex(16));int passed=0;
    auto check=[&](bool ok,const char* label) {if(!ok) throw Error(label);++passed;std::cout<<"PASS "<<label<<'\n';};
    auto rejects=[&](auto fn) {try {fn();return false;}catch(...) {return true;}};
    try {
        fs::create_directories(root);
        std::string text="Lua 😀 Māori 中文";
        check(utf8(wide(text))==text,"Unicode conversion");
        auto unicodePath=root/fs::path("Māori 中文.luau");
        atomicWrite(unicodePath,text);check(readFile(unicodePath)==text,"Unicode paths and atomic saves");
        atomicWrite(unicodePath,"updated");check(readFile(unicodePath)=="updated","atomic replacement");
        check(rejects([&]{readFile(unicodePath,2);}),"bounded file reads");
        fs::create_directory(root/"directory");
        check(rejects([&]{atomicWrite(root/"directory","bad");})&&fs::is_directory(root/"directory"),"failed replacement preserves destination");
        for(auto& entry:fs::directory_iterator(root)) check(entry.path().filename().string().find(".tmp-")==std::string::npos,"temporary files cleaned");
        std::string binary("a\0b\xff",4);
        check(base64Decode(base64Encode(binary))==binary,"binary base64");
        for(auto invalid:{"abc","a===","====","AA=A","AB==","AAB="}) check(rejects([&]{base64Decode(invalid);}),"invalid base64 rejected");
        check(digest("abc")=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad","SHA256 vector");
        check(digest("The quick brown fox jumps over the lazy dog","sha256","key",true)=="97yD9DBThCSxMpjmqm+xQ+9NWaFJRhdZl0edvC0aPNg=","HMAC vector");
        check(randomHex(16).size()==32&&randomHex(16)!=randomHex(16),"secure random identifiers");
        auto workspace=root/"workspace";fs::create_directories(workspace);
        check(workspacePath(workspace,"test.luau")==workspace/"test.luau","workspace resolution");
        for(auto invalid:{"../escape","/tmp/escape","a/../../escape","a\\b","a:b"}) check(rejects([&]{workspacePath(workspace,invalid);}),"workspace traversal rejected");
        fs::create_directory_symlink(root,workspace/"escape");
        check(rejects([&]{workspacePath(workspace,"escape/outside.txt");}),"symlink escape rejected");
        check(blockedExtension("tool.COMMAND")&&blockedExtension("test.dylib")&&!blockedExtension("test.luau"),"Mac executable extensions recognized");
        Session session;session.tabs={{"Unicode 😀",text},{"second","return 42"}};session.active=1;session.nextTab=3;
        auto sessionFile=root/"tabs.json";saveSession(sessionFile,session);auto loaded=loadSession(sessionFile);
        check(loaded.saveAllowed&&loaded.session.active==1&&loaded.session.tabs[0].content==text,"session roundtrip");
        atomicWrite(sessionFile,"[4,[\"legacy\",\"print(1)\"]]");loaded=loadSession(sessionFile);
        check(loaded.session.tabs[0].name=="legacy"&&loaded.session.nextTab==4,"legacy session import");
        atomicWrite(sessionFile,"broken JSON");loaded=loadSession(sessionFile);
        bool backup=false;for(auto& entry:fs::directory_iterator(root)) if(entry.path().filename().string().starts_with("tabs.json.corrupt-")) backup=readFile(entry.path())=="broken JSON";
        check(loaded.saveAllowed&&backup&&!loaded.recovery.empty(),"corrupt session retained before recovery");
        check(readFile(sessionFile)=="broken JSON","recovery does not overwrite original");
        Compiler compiler({});auto bytes=compiler.compile("return 6*7","fixture.luau");
        auto state=luaL_newstate();if(!state) throw Error("VM allocation failed");luaL_openlibs(state);luaL_sandbox(state);
        int load=luau_load(state,"fixture",bytes.data(),bytes.size(),0);
        int result=load==0?lua_pcall(state,0,1,0):-1;
        check(load==0&&result==0&&lua_tonumber(state,-1)==42,"compiled bytecode executes in Luau VM");lua_close(state);
        check(rejects([&]{compiler.compile("local = broken");}),"compiler diagnostics");
        check(rejects([&]{Compiler::decrypt("bad");}),"invalid bytecode rejected");
        ScriptReader reader{[](uint64_t id){return id==1?"Root":"Māori/Module";},[](uint64_t id){return id==2?"ModuleScript":"Folder";},[](uint64_t id){return id==1?std::vector<uint64_t>{2}:std::vector<uint64_t>{1};}};
        auto scan=scanClientScripts(1,123,reader);check(scan.scripts.size()==1&&scan.visited==2,"script traversal retains cycle detection");
        auto filename=scriptExportName(scan.scripts[0],0).string();check(filename.find('/')==std::string::npos&&filename.find("Māori")!=std::string::npos,"Unicode export filename sanitized");
        int calls=0;Decompiler decompiler(root/"cache",[&](std::string_view){++calls;return "return 42";});
        check(decompiler.decompile(bytes)=="return 42"&&decompiler.decompile(bytes)=="return 42"&&calls==1,"decompiler cache with fixture transport");
        auto exportFolder=root/"exports";
        auto exportOnce=[&]{return exportClientScripts(scan.scripts,exportFolder,decompiler,[&](const ClientScript&){return bytes;},[](const ClientScript&){return true;},[]{return false;});};
        check(exportOnce().saved==1&&exportOnce().saved==1,"repeat exports succeed");
        int exports=0;for(auto& entry:fs::directory_iterator(exportFolder)) if(entry.path().extension()==".luau") ++exports;
        check(exports==2,"repeated exports retain previous files");
        auto cancelled=exportClientScripts(scan.scripts,root/"cancel",decompiler,[&](const ClientScript&){return bytes;},[](const ClientScript&){return true;},[]{return true;});
        check(cancelled.saved==0&&cancelled.stopReason=="Cancelled","export cancellation");
        auto status=macBackendStatus();check(!status.canAttach&&!status.canExecute&&!status.detail.empty(),"unsupported game backend reports unavailable");
        if(argc==2) {
            auto url=wide(argv[1]);
            check(httpRequest(url+L"/ok")=="fixture","native HTTP GET");
            check(httpRequest(url+L"/post","POST","request-body",L"Content-Type: text/plain\r\n")=="request-body","native HTTP POST");
            check(rejects([&]{httpRequest(url+L"/large","GET",{},L"",8);}),"HTTP response-size limit");
            check(rejects([&]{httpRequest(url+L"/error");}),"HTTP error status rejected");
        }
        fs::remove_all(root);std::cout<<passed<<" checks passed; no live Roblox or macOS GUI test performed by this suite.\n";return 0;
    }catch(const std::exception& error) {std::cerr<<"FAIL "<<error.what()<<"\nFixture retained: "<<root<<'\n';return 1;}
}
