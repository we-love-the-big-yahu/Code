"""Run optional local-only HTTP checks; never contacts an external service."""
import http.server
import subprocess
import sys
import threading

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/error':
            self.send_error(503)
            return
        value = b'x' * 128 if self.path == '/large' else b'fixture'
        self.send_response(200)
        self.send_header('Content-Length', str(len(value)))
        self.end_headers()
        self.wfile.write(value)

    def do_POST(self):
        value = self.rfile.read(int(self.headers.get('Content-Length', '0')))
        self.send_response(200)
        self.send_header('Content-Length', str(len(value)))
        self.end_headers()
        self.wfile.write(value)

    def log_message(self, *_):
        pass

if __name__ == '__main__':
    with http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            result = subprocess.run([sys.argv[1], f'http://127.0.0.1:{server.server_port}'], check=False)
        finally:
            server.shutdown()
            thread.join()
        raise SystemExit(result.returncode)
