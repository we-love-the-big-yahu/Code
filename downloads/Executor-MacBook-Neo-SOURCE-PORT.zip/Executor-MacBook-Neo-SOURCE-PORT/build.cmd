@echo off
setlocal
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo Visual Studio Build Tools with Desktop development with C++ is required.
  exit /b 1
)
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%i"
if not defined VSROOT (
  echo Install the Visual Studio Desktop development with C++ workload.
  exit /b 1
)
call "%VSROOT%\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
pushd "%~dp0"
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 goto fail
cmake --build build --parallel 4
if errorlevel 1 goto fail
ctest --test-dir build --output-on-failure
if errorlevel 1 goto fail
cmake --install build --prefix dist
if errorlevel 1 goto fail
echo Built dist\FunnyExecutor.exe
popd
exit /b 0
:fail
popd
exit /b 1
