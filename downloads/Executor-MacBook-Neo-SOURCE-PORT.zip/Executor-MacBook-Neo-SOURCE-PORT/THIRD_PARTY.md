# Third-party components

- Original FunnyExecutor: MIT, copyright 2026 funnyfreak228. `LICENSE` is retained. The Lua initializer, runtime bytecode and Luau compiler executable are reused from the user's existing repository.
- FunnyVM/Fiu runtime: MIT. Its original license is retained in `assets/fvm/LICENSE`.
- nlohmann/json 3.12.0: MIT. Vendored from https://github.com/nlohmann/json/tree/v3.12.0, license at `third_party/nlohmann/LICENSE.MIT`. Header SHA-256: `aaf127c04cb31c406e5b04a63f1ae89369fccde6d8fa7cdda1ed4f32dfc5de63`.
- Zstandard 1.5.7: BSD or GPLv2. Used under its BSD license (`third_party/zstd/LICENSE`). Only its decoder/common sources are compiled. Official archive: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz. Archive SHA-256: `eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3`.
- Windows APIs: Win32, Rich Edit, Winsock, WinHTTP, BCrypt and Common Controls supplied by Windows.

There is no Python or Qt runtime dependency. The bundled `compile.exe` remains an external native compiler process, with a 15-second timeout.

## macOS source-port additions

- Official Luau source: MIT, retained at `third_party/luau/LICENSE.txt`; upstream commit `8387cfb461b38ce09e37c1e4c2811538ef1bf5cb` is recorded in `third_party/luau/UPSTREAM_COMMIT.txt`. This replaces the external Windows compiler for the Mac source target.
- macOS SDK frameworks: AppKit/Foundation, CommonCrypto and Security, supplied by Apple's developer tools.
- System libcurl: used through the OS/toolchain library; TLS verification remains enabled.
- OpenSSL: used only by the Linux core-test build; Mac code uses CommonCrypto and Security.
